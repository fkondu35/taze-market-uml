// 🔧 TAZE MARKET YAPILANDIRMASI
// Bu dosyayı düzenleyerek kendi URL'nizi ayarlayabilirsiniz

const CONFIG = {
  // Backend API URL'i
  // Kendi sunucunuzda: 'https://api.tazemarket.com/api' veya 'http://localhost:8001/api'
  API_URL: '/api',
  
  // Site Bilgileri
  SITE_NAME: 'Taze Market',
  SITE_DOMAIN: 'TazeMarket.com',
  
  // Destek/İletişim
  SUPPORT_EMAIL: 'destek@tazemarket.com',
  GITHUB_URL: 'https://github.com/tazemarket',
  
  // Banka Bilgileri (Admin panelinden de değiştirilebilir)
  BANK_INFO: {
    iban: 'TR91 0001 0090 1008 0885 5050 02',
    accountHolder: 'Muhammet Ali Aslan',
    bankName: 'Ziraat Bankası'
  }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = CONFIG;
}
