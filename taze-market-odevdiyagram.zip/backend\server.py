from fastapi import FastAPI, APIRouter, HTTPException, Depends, Header, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import asyncio
import json
import jwt
import stripe
from passlib.context import CryptContext

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT and password hashing
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_DAYS = 30
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Stripe
STRIPE_API_KEY = os.environ.get('STRIPE_API_KEY')
STRIPE_WEBHOOK_SECRET = os.environ.get('STRIPE_WEBHOOK_SECRET', '')


class CheckoutSessionRequest(BaseModel):
    amount: float
    currency: str
    success_url: str
    cancel_url: str
    metadata: Dict[str, str] = Field(default_factory=dict)


class CheckoutSessionResponse(BaseModel):
    session_id: str
    url: str


class CheckoutStatusResponse(BaseModel):
    payment_status: str


class WebhookCheckoutResponse(BaseModel):
    event_type: str
    session_id: str
    payment_status: str


class StripeCheckout:
    def __init__(self, api_key: Optional[str], webhook_url: str):
        self.api_key = api_key
        self.webhook_url = webhook_url
        if self.api_key:
            stripe.api_key = self.api_key

    async def create_checkout_session(self, checkout_request: CheckoutSessionRequest) -> CheckoutSessionResponse:
        if not self.api_key:
            raise HTTPException(status_code=500, detail="Stripe API key is not configured")

        session = await asyncio.to_thread(
            stripe.checkout.Session.create,
            mode="payment",
            line_items=[
                {
                    "price_data": {
                        "currency": checkout_request.currency,
                        "product_data": {"name": "TazeMarket Siparişi"},
                        "unit_amount": int(round(checkout_request.amount * 100)),
                    },
                    "quantity": 1,
                }
            ],
            success_url=checkout_request.success_url,
            cancel_url=checkout_request.cancel_url,
            metadata=checkout_request.metadata,
        )
        return CheckoutSessionResponse(session_id=session.id, url=session.url)

    async def get_checkout_status(self, session_id: str) -> CheckoutStatusResponse:
        if not self.api_key:
            raise HTTPException(status_code=500, detail="Stripe API key is not configured")
        session = await asyncio.to_thread(stripe.checkout.Session.retrieve, session_id)
        payment_status = "paid" if getattr(session, "payment_status", "") == "paid" else "pending"
        return CheckoutStatusResponse(payment_status=payment_status)

    async def handle_webhook(self, body: bytes, signature: Optional[str]) -> WebhookCheckoutResponse:
        if self.api_key and STRIPE_WEBHOOK_SECRET and signature:
            event = await asyncio.to_thread(
                stripe.Webhook.construct_event,
                payload=body,
                sig_header=signature,
                secret=STRIPE_WEBHOOK_SECRET,
            )
            event_type = event.get("type", "")
            event_object = event.get("data", {}).get("object", {})
            return WebhookCheckoutResponse(
                event_type=event_type,
                session_id=event_object.get("id", ""),
                payment_status=event_object.get("payment_status", "pending"),
            )

        # Local/dev fallback: parse webhook payload without signature verification.
        payload = json.loads(body.decode("utf-8"))
        event_type = payload.get("type", "")
        event_object = payload.get("data", {}).get("object", {})
        return WebhookCheckoutResponse(
            event_type=event_type,
            session_id=event_object.get("id", ""),
            payment_status=event_object.get("payment_status", "pending"),
        )

app = FastAPI()
api_router = APIRouter(prefix="/api")

# Models
class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    email: EmailStr
    name: str
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Product(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    price: float
    unit: str
    image: str
    category: str  # "fruit" or "vegetable"
    description: Optional[str] = None
    in_stock: bool = True

class CartItem(BaseModel):
    product_id: str
    quantity: int

class Cart(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    items: List[CartItem] = []
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Favorite(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    product_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Order(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    items: List[Dict[str, Any]]
    total: float
    status: str  # "pending", "paid", "cancelled"
    payment_session_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PaymentTransaction(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    session_id: str
    user_id: Optional[str] = None
    amount: float
    currency: str
    payment_status: str  # "pending", "paid", "failed", "expired"
    metadata: Optional[Dict[str, str]] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Helper functions
def create_access_token(user_id: str, email: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(days=JWT_EXPIRATION_DAYS)
    payload = {
        "user_id": user_id,
        "email": email,
        "exp": expire
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def get_current_user(authorization: Optional[str] = Header(None)) -> Optional[dict]:
    if not authorization or not authorization.startswith("Bearer "):
        return None
    token = authorization.replace("Bearer ", "")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def require_auth(authorization: Optional[str] = Header(None)) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    token = authorization.replace("Bearer ", "")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def require_admin(authorization: Optional[str] = Header(None)) -> dict:
    user = await require_auth(authorization)
    # Check if user is admin
    user_doc = await db.users.find_one({"id": user['user_id']}, {"_id": 0})
    if not user_doc or not user_doc.get('is_admin', False):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user

# Auth endpoints
@api_router.post("/auth/register")
async def register(user_data: UserCreate):
    # Check if user exists
    existing = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Hash password
    hashed_password = pwd_context.hash(user_data.password)
    
    # Create user
    user = User(email=user_data.email, name=user_data.name)
    user_dict = user.model_dump()
    user_dict['timestamp'] = user_dict['created_at'].isoformat()
    user_dict['password'] = hashed_password
    user_dict['is_admin'] = False  # Normal user
    del user_dict['created_at']
    
    await db.users.insert_one(user_dict)
    
    # Create token
    token = create_access_token(user.id, user.email)
    
    return {"user": user.model_dump(), "token": token}

@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    # Find user
    user_doc = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Verify password
    if not pwd_context.verify(credentials.password, user_doc['password']):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Create token
    token = create_access_token(user_doc['id'], user_doc['email'])
    
    # Return user without password
    user_data = {k: v for k, v in user_doc.items() if k != 'password'}
    
    return {"user": user_data, "token": token}

@api_router.post("/auth/admin-login")
async def admin_login(request: Request):
    # Get JSON body
    body = await request.json()
    username = body.get('username')
    password = body.get('password')
    
    # Find admin user
    admin_doc = await db.users.find_one({"username": username, "is_admin": True}, {"_id": 0})
    if not admin_doc:
        raise HTTPException(status_code=401, detail="Invalid admin credentials")
    
    # Verify password
    if not pwd_context.verify(password, admin_doc['password']):
        raise HTTPException(status_code=401, detail="Invalid admin credentials")
    
    # Create token
    token = create_access_token(admin_doc['id'], admin_doc.get('email', username))
    
    # Return admin without password
    admin_data = {k: v for k, v in admin_doc.items() if k != 'password'}
    
    return {"user": admin_data, "token": token}

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(require_auth)):
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0, "password": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")
    return user_doc

# Product endpoints
@api_router.get("/products")
async def get_products(category: Optional[str] = None, search: Optional[str] = None):
    query = {}
    if category:
        query['category'] = category
    if search:
        query['name'] = {"$regex": search, "$options": "i"}
    
    products = await db.products.find(query, {"_id": 0}).to_list(1000)
    return products

@api_router.get("/products/{product_id}")
async def get_product(product_id: str):
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

# Cart endpoints
@api_router.get("/cart")
async def get_cart(current_user: dict = Depends(require_auth)):
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart:
        return {"user_id": current_user['user_id'], "items": []}
    
    # Populate product details
    cart_items = []
    for item in cart.get('items', []):
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            cart_items.append({
                "product": product,
                "quantity": item['quantity']
            })
    
    return {"user_id": cart['user_id'], "items": cart_items}

@api_router.post("/cart/add")
async def add_to_cart(item: CartItem, current_user: dict = Depends(require_auth)):
    # Check if product exists
    product = await db.products.find_one({"id": item.product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Get or create cart
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    
    if not cart:
        cart = {"user_id": current_user['user_id'], "items": []}
    
    # Check if item already in cart
    existing_item = None
    for i, cart_item in enumerate(cart['items']):
        if cart_item['product_id'] == item.product_id:
            existing_item = i
            break
    
    if existing_item is not None:
        cart['items'][existing_item]['quantity'] += item.quantity
    else:
        cart['items'].append({"product_id": item.product_id, "quantity": item.quantity})
    
    cart['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": cart},
        upsert=True
    )
    
    return {"message": "Item added to cart"}

@api_router.post("/cart/update")
async def update_cart_item(item: CartItem, current_user: dict = Depends(require_auth)):
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart:
        raise HTTPException(status_code=404, detail="Cart not found")
    
    # Find and update item
    for i, cart_item in enumerate(cart['items']):
        if cart_item['product_id'] == item.product_id:
            if item.quantity <= 0:
                cart['items'].pop(i)
            else:
                cart['items'][i]['quantity'] = item.quantity
            break
    
    cart['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": cart}
    )
    
    return {"message": "Cart updated"}

@api_router.delete("/cart/clear")
async def clear_cart(current_user: dict = Depends(require_auth)):
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": {"items": [], "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    return {"message": "Cart cleared"}

# Favorites endpoints
@api_router.get("/favorites")
async def get_favorites(current_user: dict = Depends(require_auth)):
    favorites = await db.favorites.find({"user_id": current_user['user_id']}, {"_id": 0}).to_list(1000)
    
    # Populate product details
    favorite_products = []
    for fav in favorites:
        product = await db.products.find_one({"id": fav['product_id']}, {"_id": 0})
        if product:
            favorite_products.append(product)
    
    return favorite_products

@api_router.post("/favorites/{product_id}")
async def add_favorite(product_id: str, current_user: dict = Depends(require_auth)):
    # Check if product exists
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Check if already favorited
    existing = await db.favorites.find_one({"user_id": current_user['user_id'], "product_id": product_id})
    if existing:
        return {"message": "Already in favorites"}
    
    favorite = Favorite(user_id=current_user['user_id'], product_id=product_id)
    fav_dict = favorite.model_dump()
    fav_dict['timestamp'] = fav_dict['created_at'].isoformat()
    del fav_dict['created_at']
    
    await db.favorites.insert_one(fav_dict)
    return {"message": "Added to favorites"}

@api_router.delete("/favorites/{product_id}")
async def remove_favorite(product_id: str, current_user: dict = Depends(require_auth)):
    await db.favorites.delete_one({"user_id": current_user['user_id'], "product_id": product_id})
    return {"message": "Removed from favorites"}

# Payment endpoints
@api_router.post("/checkout/bank-transfer")
async def create_bank_transfer_order(current_user: dict = Depends(require_auth)):
    # Get cart
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart or not cart.get('items'):
        raise HTTPException(status_code=400, detail="Cart is empty")
    
    # Calculate total
    total = 0.0
    items = []
    for item in cart['items']:
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({
                "product_id": product['id'],
                "name": product['name'],
                "price": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })
    
    # Create order with bank transfer
    order = Order(
        user_id=current_user['user_id'],
        items=items,
        total=total,
        status="pending",
        payment_session_id="BANK_TRANSFER"
    )
    order_dict = order.model_dump()
    order_dict['timestamp'] = order_dict['created_at'].isoformat()
    order_dict['payment_method'] = 'bank_transfer'
    del order_dict['created_at']
    
    await db.orders.insert_one(order_dict)
    
    # Create payment transaction
    payment = PaymentTransaction(
        session_id=f"BANK_{order.id}",
        user_id=current_user['user_id'],
        amount=total,
        currency="TRY",
        payment_status="pending",
        metadata={"order_id": order.id, "payment_method": "bank_transfer"}
    )
    payment_dict = payment.model_dump()
    payment_dict['timestamp'] = payment_dict['created_at'].isoformat()
    payment_dict['updated_timestamp'] = payment_dict['updated_at'].isoformat()
    del payment_dict['created_at']
    del payment_dict['updated_at']
    
    await db.payment_transactions.insert_one(payment_dict)
    
    # Clear cart
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": {"items": []}}
    )
    
    return {
        "order_id": order.id,
        "total": total,
        "iban": "TR91 0001 0090 1008 0885 5050 02",
        "account_holder": "Muhammet Ali Aslan",
        "bank_name": "Ziraat Bankası",
        "description": f"Sipariş No: {order.id[:8]}"
    }

@api_router.post("/checkout/create")
async def create_checkout(request: Request, origin_url: str, current_user: dict = Depends(require_auth)):
    # Get cart
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart or not cart.get('items'):
        raise HTTPException(status_code=400, detail="Cart is empty")
    
    # Calculate total
    total = 0.0
    items = []
    for item in cart['items']:
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({
                "product_id": product['id'],
                "name": product['name'],
                "price": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })
    
    # Create order
    order = Order(
        user_id=current_user['user_id'],
        items=items,
        total=total,
        status="pending"
    )
    order_dict = order.model_dump()
    order_dict['timestamp'] = order_dict['created_at'].isoformat()
    del order_dict['created_at']
    
    await db.orders.insert_one(order_dict)
    
    # Create Stripe checkout session
    host_url = origin_url
    webhook_url = f"{host_url}/api/webhook/stripe"
    stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=webhook_url)
    
    success_url = f"{origin_url}/checkout/success?session_id={{{{CHECKOUT_SESSION_ID}}}}"
    cancel_url = f"{origin_url}/cart"
    
    checkout_request = CheckoutSessionRequest(
        amount=total,
        currency="usd",
        success_url=success_url,
        cancel_url=cancel_url,
        metadata={
            "user_id": current_user['user_id'],
            "order_id": order.id
        }
    )
    
    session = await stripe_checkout.create_checkout_session(checkout_request)
    
    # Create payment transaction
    payment = PaymentTransaction(
        session_id=session.session_id,
        user_id=current_user['user_id'],
        amount=total,
        currency="usd",
        payment_status="pending",
        metadata={"order_id": order.id}
    )
    payment_dict = payment.model_dump()
    payment_dict['timestamp'] = payment_dict['created_at'].isoformat()
    payment_dict['updated_timestamp'] = payment_dict['updated_at'].isoformat()
    del payment_dict['created_at']
    del payment_dict['updated_at']
    
    await db.payment_transactions.insert_one(payment_dict)
    
    # Update order with session_id
    await db.orders.update_one(
        {"id": order.id},
        {"$set": {"payment_session_id": session.session_id}}
    )
    
    return {"url": session.url, "session_id": session.session_id}

@api_router.get("/checkout/status/{session_id}")
async def get_checkout_status(session_id: str, current_user: dict = Depends(require_auth)):
    # Check if already processed
    payment = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    # If already paid, return immediately
    if payment['payment_status'] == 'paid':
        return payment
    
    # Check with Stripe
    webhook_url = "http://localhost/api/webhook/stripe"
    stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=webhook_url)
    
    status: CheckoutStatusResponse = await stripe_checkout.get_checkout_status(session_id)
    
    # Update payment transaction
    if status.payment_status == 'paid' and payment['payment_status'] != 'paid':
        await db.payment_transactions.update_one(
            {"session_id": session_id},
            {"$set": {
                "payment_status": "paid",
                "updated_timestamp": datetime.now(timezone.utc).isoformat()
            }}
        )
        
        # Update order status
        order_id = payment['metadata'].get('order_id')
        if order_id:
            await db.orders.update_one(
                {"id": order_id},
                {"$set": {"status": "paid"}}
            )
        
        # Clear cart
        await db.carts.update_one(
            {"user_id": payment['user_id']},
            {"$set": {"items": []}}
        )
    
    # Get updated payment
    updated_payment = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
    return updated_payment

@api_router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    body = await request.body()
    signature = request.headers.get("Stripe-Signature")
    
    host_url = str(request.base_url).rstrip('/')
    webhook_url = f"{host_url}/api/webhook/stripe"
    stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=webhook_url)
    
    try:
        webhook_response = await stripe_checkout.handle_webhook(body, signature)
        
        if webhook_response.event_type == "checkout.session.completed":
            # Update payment status
            await db.payment_transactions.update_one(
                {"session_id": webhook_response.session_id},
                {"$set": {
                    "payment_status": webhook_response.payment_status,
                    "updated_timestamp": datetime.now(timezone.utc).isoformat()
                }}
            )
        
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Orders endpoints
@api_router.get("/orders")
async def get_orders(current_user: dict = Depends(require_auth)):
    orders = await db.orders.find({"user_id": current_user['user_id']}, {"_id": 0}).to_list(1000)
    return orders

@api_router.get("/orders/{order_id}")
async def get_order(order_id: str, current_user: dict = Depends(require_auth)):
    order = await db.orders.find_one({"id": order_id, "user_id": current_user['user_id']}, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

# ADMIN ENDPOINTS
@api_router.get("/admin/products")
async def admin_get_products(current_user: dict = Depends(require_admin)):
    """Admin: Get all products"""
    products = await db.products.find({}, {"_id": 0}).to_list(1000)
    return products

@api_router.post("/admin/products")
async def admin_create_product(product: Product, current_user: dict = Depends(require_admin)):
    """Admin: Create new product"""
    product_dict = product.model_dump()
    await db.products.insert_one(product_dict)
    # Remove MongoDB _id before returning
    product_dict.pop('_id', None)
    return {"message": "Product created", "product": product_dict}

@api_router.put("/admin/products/{product_id}")
async def admin_update_product(product_id: str, product: Product, current_user: dict = Depends(require_admin)):
    """Admin: Update product"""
    product_dict = product.model_dump()
    result = await db.products.update_one(
        {"id": product_id},
        {"$set": product_dict}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"message": "Product updated", "product": product_dict}

@api_router.delete("/admin/products/{product_id}")
async def admin_delete_product(product_id: str, current_user: dict = Depends(require_admin)):
    """Admin: Delete product"""
    result = await db.products.delete_one({"id": product_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"message": "Product deleted"}

@api_router.get("/admin/stats")
async def admin_get_stats(current_user: dict = Depends(require_admin)):
    """Admin: Get statistics"""
    total_products = await db.products.count_documents({})
    total_users = await db.users.count_documents({})
    total_orders = await db.orders.count_documents({})
    
    # Revenue
    orders = await db.orders.find({"status": "paid"}, {"_id": 0}).to_list(1000)
    total_revenue = sum(order.get('total', 0) for order in orders)
    
    return {
        "total_products": total_products,
        "total_users": total_users,
        "total_orders": total_orders,
        "total_revenue": total_revenue
    }

app.include_router(api_router)

raw_origins = os.environ.get(
    'CORS_ORIGINS',
    'https://tazemarket.it.com,http://localhost:3000,http://127.0.0.1:3000'
)
allowed_origins = [origin.strip() for origin in raw_origins.split(',') if origin.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=allowed_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
