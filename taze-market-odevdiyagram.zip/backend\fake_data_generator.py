import random
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List


class MarketFakeDataGenerator:
    """Generate coherent fake data for TazeMarket collections."""

    def __init__(self, seed: int = 42):
        self._rng = random.Random(seed)

    def generate_users(self, count: int = 10) -> List[Dict[str, Any]]:
        first_names = [
            "Ahmet", "Ayse", "Mehmet", "Fatma", "Can", "Elif", "Mert", "Zeynep", "Deniz", "Selin",
            "Kerem", "Ece", "Yusuf", "Defne", "Arda",
        ]
        last_names = [
            "Yilmaz", "Kaya", "Demir", "Sahin", "Celik", "Aydin", "Arslan", "Turan", "Aslan", "Polat",
        ]
        users: List[Dict[str, Any]] = []

        for idx in range(count):
            first = self._rng.choice(first_names)
            last = self._rng.choice(last_names)
            full_name = f"{first} {last}"
            created = datetime.now(timezone.utc) - timedelta(days=self._rng.randint(1, 120))
            users.append(
                {
                    "id": f"user_{idx + 1}",
                    "name": full_name,
                    "email": f"{first.lower()}.{last.lower()}{idx + 1}@mail.com",
                    "password": "TEMP_HASHED_PASSWORD",
                    "is_admin": False,
                    "timestamp": created.isoformat(),
                }
            )
        return users

    def generate_carts(self, user_ids: List[str], product_ids: List[str], count: int = 10) -> List[Dict[str, Any]]:
        carts: List[Dict[str, Any]] = []
        for idx in range(count):
            uid = user_ids[idx % len(user_ids)]
            item_count = self._rng.randint(1, 4)
            selected = self._rng.sample(product_ids, k=item_count)
            items = [{"product_id": pid, "quantity": self._rng.randint(1, 5)} for pid in selected]
            carts.append(
                {
                    "user_id": uid,
                    "items": items,
                    "updated_at": (datetime.now(timezone.utc) - timedelta(days=self._rng.randint(0, 15))).isoformat(),
                }
            )
        return carts

    def generate_favorites(
        self, user_ids: List[str], product_ids: List[str], count: int = 20
    ) -> List[Dict[str, Any]]:
        favorites: List[Dict[str, Any]] = []
        for _ in range(count):
            favorites.append(
                {
                    "user_id": self._rng.choice(user_ids),
                    "product_id": self._rng.choice(product_ids),
                    "timestamp": (datetime.now(timezone.utc) - timedelta(days=self._rng.randint(1, 60))).isoformat(),
                }
            )
        return favorites

    def generate_orders_and_payments(
        self, user_ids: List[str], products: List[Dict[str, Any]], count: int = 10
    ) -> Dict[str, List[Dict[str, Any]]]:
        orders: List[Dict[str, Any]] = []
        payments: List[Dict[str, Any]] = []

        for _ in range(count):
            user_id = self._rng.choice(user_ids)
            selected_products = self._rng.sample(products, k=self._rng.randint(1, 3))
            items = []
            total = 0.0
            for product in selected_products:
                quantity = self._rng.randint(1, 3)
                subtotal = round(product["price"] * quantity, 2)
                total += subtotal
                items.append(
                    {
                        "product_id": product["id"],
                        "name": product["name"],
                        "price": product["price"],
                        "quantity": quantity,
                        "subtotal": subtotal,
                    }
                )

            order_id = str(uuid.uuid4())
            status = self._rng.choice(["pending", "paid", "paid", "cancelled"])
            created_at = (datetime.now(timezone.utc) - timedelta(days=self._rng.randint(1, 45))).isoformat()
            payment_session_id = f"BANK_{order_id}"

            orders.append(
                {
                    "id": order_id,
                    "user_id": user_id,
                    "items": items,
                    "total": round(total, 2),
                    "status": status,
                    "payment_session_id": payment_session_id,
                    "payment_method": "bank_transfer",
                    "timestamp": created_at,
                }
            )

            payment_status = "paid" if status == "paid" else ("failed" if status == "cancelled" else "pending")
            now_ts = datetime.now(timezone.utc).isoformat()
            payments.append(
                {
                    "id": str(uuid.uuid4()),
                    "session_id": payment_session_id,
                    "user_id": user_id,
                    "amount": round(total, 2),
                    "currency": "TRY",
                    "payment_status": payment_status,
                    "metadata": {"order_id": order_id, "payment_method": "bank_transfer"},
                    "timestamp": now_ts,
                    "updated_timestamp": now_ts,
                }
            )

        return {"orders": orders, "payments": payments}
