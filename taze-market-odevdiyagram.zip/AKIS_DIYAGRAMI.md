# TazeMarket Siparis ve Veritabani Akis Diyagrami

## Diyagram Adi
`TazeMarket_Siparis_Veritabani_Akis_Diyagrami`

## Mermaid Akis Diyagrami
```mermaid
flowchart TD
    A[Kullanici Kayit Giris] --> B[JWT Token Uretimi]
    B --> C[Urunleri Listele]
    C --> D[Sepete Urun Ekle]
    D --> E[Sepeti Guncelle]
    E --> F{Odeme Yontemi}
    F -->|Stripe| G[Checkout Session Olustur]
    F -->|Banka Havalesi| H[Havale Siparisi Olustur]
    G --> I[orders Kaydi]
    H --> I
    I --> J[payment_transactions Kaydi]
    J --> K[Sepeti Temizle]

    U[(users)] --> B
    P[(products)] --> C
    CA[(carts)] --> D
    O[(orders)] --> I
    PT[(payment_transactions)] --> J
```
