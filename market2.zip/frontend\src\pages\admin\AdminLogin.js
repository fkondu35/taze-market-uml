import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'sonner';
import { Shield } from 'lucide-react';

const AdminLogin = () => {
  const [formData, setFormData] = useState({ username: '', password: '' });
  const [loading, setLoading] = useState(false);
  const { adminLogin, user } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (user?.is_admin) {
      navigate('/admin');
    }
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await adminLogin(formData.username, formData.password);
      toast.success('Admin girişi başarılı');
      navigate('/admin');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Giriş başarısız');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 bg-[#F9F7F2]">
      <div className="max-w-md w-full">
        <div className="card p-8">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 rounded-full bg-[#1A4D2E] flex items-center justify-center mb-4">
              <Shield className="text-white" size={32} />
            </div>
            <h1 className="text-3xl font-bold text-[#1A4D2E]" style={{ fontFamily: 'Playfair Display' }}>
              Admin Paneli
            </h1>
            <p className="text-[#4A6B5A] mt-2 text-center">Yönetici hesabınızla giriş yapın</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-[#1A4D2E] mb-2">
                Kullanıcı Adı
              </label>
              <input
                id="username"
                type="text"
                required
                value={formData.username}
                onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00]"
                placeholder="Admin kullanıcı adı"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-[#1A4D2E] mb-2">
                Şifre
              </label>
              <input
                id="password"
                type="password"
                required
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00]"
                placeholder="********"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Giriş yapılıyor...' : 'Admin Girişi'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <Link to="/" className="text-[#FF6B00] hover:text-[#E65100] font-medium">
              ← Siteye Dön
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
