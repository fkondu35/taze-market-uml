import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-[#1A4D2E] text-white py-12 mt-24" data-testid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4" style={{fontFamily: 'Playfair Display'}}>Taze Market</h3>
            <p className="text-white/80">
              İki üniversite öğrencisinin girişimiyle kurulmuş online taze gıda marketi.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Kategoriler</h4>
            <ul className="space-y-2 text-white/80">
              <li><Link to="/products?category=fruit" className="hover:text-[#FF6B00] transition">Meyveler</Link></li>
              <li><Link to="/products?category=vegetable" className="hover:text-[#FF6B00] transition">Sebzeler</Link></li>
              <li><Link to="/yorumlar" className="hover:text-[#FF6B00] transition">Müşteri Yorumları</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Hakkımızda</h4>
            <ul className="space-y-2 text-white/80">
              <li><Link to="/hikayemiz" className="hover:text-[#FF6B00] transition">Bizim Hikayemiz</Link></li>
              <li><Link to="/vizyon-misyon" className="hover:text-[#FF6B00] transition">Vizyon & Misyon</Link></li>
              <li><Link to="/iletisim" className="hover:text-[#FF6B00] transition">İletişim</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-3">Destek</h4>
            <ul className="space-y-2 text-white/80">
              <li><Link to="/iade-kosullari" className="hover:text-[#FF6B00] transition">İade Koşulları</Link></li>
              <li><Link to="/kvkk" className="hover:text-[#FF6B00] transition">KVKK Aydınlatma Metni</Link></li>
              <li>
                <a href="mailto:aliaslann277@gmail.com" className="hover:text-[#FF6B00] transition">
                  aliaslann277@gmail.com
                </a>
              </li>
              <li><Link to="/admin/login" className="hover:text-[#FF6B00] transition">Admin Paneli</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/20 mt-8 pt-8 text-center text-white/60 space-y-2">
          <p className="text-sm text-white/70 max-w-3xl mx-auto leading-relaxed">
            Kişisel verileriniz 6698 sayılı KVKK kapsamında korunmaktadır.
            Detaylı bilgi için{' '}
            <Link to="/kvkk" className="text-[#FF6B00] hover:underline">KVKK Aydınlatma Metni</Link>
            &apos;ni inceleyebilirsiniz.
          </p>
          <p>&copy; 2024 Taze Market. Tüm hakları saklıdır.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
