import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
import os
from dotenv import load_dotenv
from pathlib import Path
from datetime import datetime, timezone
from passlib.context import CryptContext
from fake_data_generator import MarketFakeDataGenerator

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

fruits = [
    {"id": "f1", "name": "Kırmızı Elma", "price": 12.99, "unit": "kg", "category": "fruit", "image": "https://images.unsplash.com/photo-1646794768446-048f9c285c69?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NTZ8MHwxfHNlYXJjaHwxfHxyZWQlMjBhcHBsZSUyMG9uJTIwd2hpdGUlMjBiYWNrZ3JvdW5kfGVufDB8fHx8MTc3MjI4MzEzM3ww&ixlib=rb-4.1.0&q=85", "description": "Taze ve sulu kırmızı elmalar, vitamin deposu", "in_stock": True},
    {"id": "f2", "name": "Muz", "price": 19.99, "unit": "kg", "category": "fruit", "image": "https://images.unsplash.com/photo-1711208224791-2cc390f53744?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODl8MHwxfHNlYXJjaHwxfHxiYW5hbmElMjBidW5jaCUyMG9uJTIwd2hpdGUlMjBiYWNrZ3JvdW5kfGVufDB8fHx8MTc3MjI4MzEzN3ww&ixlib=rb-4.1.0&q=85", "description": "Tatlı ve enerji dolu muzlar", "in_stock": True},
    {"id": "f3", "name": "Taze Portakal", "price": 15.49, "unit": "kg", "category": "fruit", "image": "https://images.unsplash.com/photo-1645378193840-f4a90003285d?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NzR8MHwxfHNlYXJjaHwxfHxvcmFuZ2UlMjBmcnVpdCUyMG9uJTIwd2hpdGUlMjBiYWNrZ3JvdW5kfGVufDB8fHx8MTc3MjI4MzE0Mnww&ixlib=rb-4.1.0&q=85", "description": "C vitamini kaynağı taze portakallar", "in_stock": True},
    {"id": "f4", "name": "Yeşil Üzüm", "price": 24.99, "unit": "kg", "category": "fruit", "image": "https://images.unsplash.com/photo-1764436404619-bba79cdf2165?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1ODF8MHwxfHNlYXJjaHwxfHxncmVlbiUyMGdyYXBlcyUyMG9uJTIwd2hpdGUlMjBiYWNrZ3JvdW5kfGVufDB8fHx8MTc3MjI4MzE0Nnww&ixlib=rb-4.1.0&q=85", "description": "Çekirdeksiz yeşil üzümler", "in_stock": True},
    {"id": "f5", "name": "Ananas", "price": 35.99, "unit": "adet", "category": "fruit", "image": "https://images.unsplash.com/photo-1496637721836-f46d116e6d34?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1NzZ8MHwxfHNlYXJjaHwxfHxwaW5lYXBwbGUlMjBvbiUyMHdoaXRlJTIwYmFja2dyb3VuZHxlbnwwfHx8fDE3NzIyODMxNTF8MA&ixlib=rb-4.1.0&q=85", "description": "Tropik lezzet, taze ananas", "in_stock": True},
    {"id": "f6", "name": "Mango", "price": 28.49, "unit": "adet", "category": "fruit", "image": "https://images.unsplash.com/photo-1587131808575-655697d61a4e?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1MDV8MHwxfHNlYXJjaHwxfHxtYW5nbyUyMG9uJTIwd2hpdGUlMjBiYWNrZ3JvdW5kfGVufDB8fHx8MTc3MjI4MzE2MXww&ixlib=rb-4.1.0&q=85", "description": "Egzotik ve lezzetli mango", "in_stock": True},
    {"id": "f7", "name": "Karpuz", "price": 8.99, "unit": "kg", "category": "fruit", "image": "https://images.unsplash.com/photo-1582281298055-e25b84a30b0b?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NzB8MHwxfHNlYXJjaHwxfHx3YXRlcm1lbG9uJTIwb24lMjB3aGl0ZSUyMGJhY2tncm91bmR8ZW58MHx8fHwxNzcyMjgzMTY1fDA&ixlib=rb-4.1.0&q=85", "description": "Serinleten tatlı karpuz", "in_stock": True},
    {"id": "f8", "name": "Limon", "price": 14.99, "unit": "kg", "category": "fruit", "image": "https://images.unsplash.com/photo-1587486937303-32eaa2134b78?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2NzR8MHwxfHNlYXJjaHwxfHx5ZWxsb3clMjBsZW1vbiUyMGZydWl0JTIwaXNvbGF0ZWQlMjB3aGl0ZSUyMGJhY2tncm91bmR8ZW58MHx8fHwxNzcyMjgzMTkxfDA&ixlib=rb-4.1.0&q=85", "description": "Ekşi ve ferahlatıcı limon", "in_stock": True},
    {"id": "f9", "name": "Çilek", "price": 49.99, "unit": "paket", "category": "fruit", "image": "https://images.unsplash.com/photo-1703925152940-b1166ec887b7?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2NzV8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGZydWl0cyUyMG9uJTIwd2hpdGUlMjBiYWNrZ3JvdW5kfGVufDB8fHx8MTc3MjI4MzA5NHww&ixlib=rb-4.1.0&q=85", "description": "Tatlı ve lezzetli çilekler", "in_stock": True},
    {"id": "f10", "name": "Şeftali", "price": 32.99, "unit": "kg", "category": "fruit", "image": "/urunler/seftali.png", "description": "Sulu ve yumuşak şeftaliler", "in_stock": True},
    {"id": "f11", "name": "Kiraz", "price": 54.99, "unit": "kg", "category": "fruit", "image": "/urunler/kiraz.png", "description": "Tatlı ve sulu taze kirazlar", "in_stock": True},
    {"id": "f12", "name": "Armut", "price": 18.99, "unit": "kg", "category": "fruit", "image": "/urunler/armut.png", "description": "Olgunlaşmış sulu armutlar", "in_stock": True},
    {"id": "f13", "name": "Kavun", "price": 12.99, "unit": "kg", "category": "fruit", "image": "/urunler/kavun.jpg", "description": "Tatlı ve aromatik kavun", "in_stock": True},
]

vegetables = [
    {"id": "v1", "name": "Domates", "price": 9.99, "unit": "kg", "category": "vegetable", "image": "https://images.unsplash.com/photo-1625494188687-7ee542a77d7c?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzMjV8MHwxfHNlYXJjaHwxfHx0b21hdG8lMjBvbiUyMHdoaXRlJTIwYmFja2dyb3VuZHxlbnwwfHx8fDE3NzIyODMxNzJ8MA&ixlib=rb-4.1.0&q=85", "description": "Taze ve kırmızı domatesler", "in_stock": True},
    {"id": "v2", "name": "Patates", "price": 7.49, "unit": "kg", "category": "vegetable", "image": "https://images.unsplash.com/photo-1744659751904-3b2e5c095323?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTY2Njd8MHwxfHNlYXJjaHwxfHxyYXclMjBwb3RhdG98ZW58MHx8fHwxNzcyMjgzMjE0fDA&ixlib=rb-4.1.0&q=85", "description": "Kaliteli ve organik patatesler", "in_stock": True},
    {"id": "v3", "name": "Kırmızı Soğan", "price": 8.29, "unit": "kg", "category": "vegetable", "image": "https://images.unsplash.com/photo-1585849834908-3481231155e8?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjAzNDR8MHwxfHNlYXJjaHwxfHxyZWQlMjBvbmlvbnxlbnwwfHx8fDE3NzIyODMyMTh8MA&ixlib=rb-4.1.0&q=85", "description": "Taze kırmızı soğanlar", "in_stock": True},
    {"id": "v4", "name": "Havuç", "price": 6.19, "unit": "kg", "category": "vegetable", "image": "https://images.unsplash.com/photo-1717959159782-98c42b1d4f37?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODF8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGNhcnJvdHxlbnwwfHx8fDE3NzIyODMyMjB8MA&ixlib=rb-4.1.0&q=85", "description": "Vitamin A deposu havuçlar", "in_stock": True},
    {"id": "v5", "name": "Brokoli", "price": 14.49, "unit": "adet", "category": "vegetable", "image": "https://images.unsplash.com/photo-1757332334626-8dadb145540d?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1MDZ8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGJyb2Njb2xpfGVufDB8fHx8MTc3MjI4MzIyNXww&ixlib=rb-4.1.0&q=85", "description": "Besleyici ve lezzetli brokoli", "in_stock": True},
    {"id": "v6", "name": "Salatalık", "price": 4.99, "unit": "kg", "category": "vegetable", "image": "https://images.unsplash.com/photo-1759147876638-9f4721769152?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA3MDR8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGN1Y3VtYmVyfGVufDB8fHx8MTc3MjI4MzIzMHww&ixlib=rb-4.1.0&q=85", "description": "Ferahlatıcı ve taze salatalık", "in_stock": True},
    {"id": "v7", "name": "Kırmızı Biber", "price": 19.99, "unit": "kg", "category": "vegetable", "image": "https://images.unsplash.com/photo-1608737637507-9aaeb9f4bf30?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1NTJ8MHwxfHNlYXJjaHwxfHxyZWQlMjBiZWxsJTIwcGVwcGVyfGVufDB8fHx8MTc3MjI4MzI0MHww&ixlib=rb-4.1.0&q=85", "description": "Tatlı kırmızı biberler", "in_stock": True},
    {"id": "v8", "name": "Ispanak", "price": 12.99, "unit": "demet", "category": "vegetable", "image": "https://images.unsplash.com/photo-1683536905403-ea18a3176d29?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjA1Mjh8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMHNwaW5hY2h8ZW58MHx8fHwxNzcyMjgzMjUyfDA&ixlib=rb-4.1.0&q=85", "description": "Demir deposu taze ıspanak", "in_stock": True},
    {"id": "v9", "name": "Patlıcan", "price": 11.79, "unit": "kg", "category": "vegetable", "image": "https://images.unsplash.com/photo-1615484477201-9f4953340fab?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NTYxODd8MHwxfHNlYXJjaHwxfHxlZ2dwbGFudHxlbnwwfHx8fDE3NzIyODMyNTN8MA&ixlib=rb-4.1.0&q=85", "description": "Mor ve parlak patlıcanlar", "in_stock": True},
    {"id": "v10", "name": "Avokado", "price": 29.99, "unit": "adet", "category": "vegetable", "image": "https://images.unsplash.com/photo-1519162808019-7de1683fa2ad?crop=entropy&cs=srgb&fm=jpg&ixid=M3w4NjY2NzV8MHwxfHNlYXJjaHwxfHxhdm9jYWRvfGVufDB8fHx8MTc3MjI4MzI1N3ww&ixlib=rb-4.1.0&q=85", "description": "Kremalı ve besleyici avokado", "in_stock": True},
    {"id": "v11", "name": "Kabak", "price": 10.49, "unit": "kg", "category": "vegetable", "image": "/urunler/kabak.png", "description": "Taze yeşil kabak", "in_stock": True},
    {"id": "v12", "name": "Marul", "price": 8.99, "unit": "adet", "category": "vegetable", "image": "/urunler/marul.png", "description": "Çıtır çıtır taze marul", "in_stock": True},
    {"id": "v13", "name": "Sarımsak", "price": 39.99, "unit": "kg", "category": "vegetable", "image": "/urunler/sarimsak.png", "description": "Kokulu ve taze sarımsak", "in_stock": True},
    {"id": "v14", "name": "Soğan", "price": 6.99, "unit": "kg", "category": "vegetable", "image": "/urunler/sogan.png", "description": "Günlük kullanım için taze soğan", "in_stock": True},
]

async def seed_database():
    # Clear collections before re-seeding
    await db.products.delete_many({})
    await db.users.delete_many({})
    await db.carts.delete_many({})
    await db.favorites.delete_many({})
    await db.orders.delete_many({})
    await db.payment_transactions.delete_many({})
    await db.surveys.delete_many({})
    await db.reviews.delete_many({})

    # Insert fruits and vegetables (27 products)
    all_products = fruits + vegetables
    stock_levels = [85, 120, 60, 45, 30, 55, 90, 70, 25, 40, 100, 150, 80, 65, 35, 95, 110, 50, 75, 42, 88, 52, 67, 73, 58, 48, 130]
    for idx, product in enumerate(all_products):
        product["stock_quantity"] = stock_levels[idx % len(stock_levels)]
    await db.products.insert_many(all_products)
    print(f"[OK] products: {len(all_products)} records inserted")

    # Fake data generation class
    generator = MarketFakeDataGenerator(seed=2026)
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

    # Users (>= 10)
    fake_users = generator.generate_users(count=10)
    for user in fake_users:
        user["password"] = pwd_context.hash("test12345")
    await db.users.insert_many(fake_users)

    # Admin user
    admin_user = {
        "id": "admin_taze_market",
        "username": "mku123456",
        "name": "Admin",
        "email": "admin@tazemarket.com",
        "password": pwd_context.hash("1234567a"),
        "is_admin": True,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    await db.users.insert_one(admin_user)
    print("[OK] users: 11 records inserted (10 fake + 1 admin)")

    user_ids = [u["id"] for u in fake_users]
    product_ids = [p["id"] for p in all_products]

    # Carts (>= 10)
    carts = generator.generate_carts(user_ids, product_ids, count=10)
    await db.carts.insert_many(carts)
    print("[OK] carts: 10 records inserted")

    # Favorites (>= 10)
    favorites = generator.generate_favorites(user_ids, product_ids, count=20)
    await db.favorites.insert_many(favorites)
    print("[OK] favorites: 20 records inserted")

    # Orders + Payment Transactions (>= 10 each)
    order_payment_bundle = generator.generate_orders_and_payments(user_ids, all_products, count=12)
    await db.orders.insert_many(order_payment_bundle["orders"])
    await db.payment_transactions.insert_many(order_payment_bundle["payments"])
    print("[OK] orders: 12 records inserted")
    print("[OK] payment_transactions: 12 records inserted")

    paid_orders = [o for o in order_payment_bundle["orders"] if o["status"] == "paid"][:3]
    sample_surveys = [
        {
            "id": "survey_1",
            "order_id": paid_orders[0]["id"],
            "user_id": paid_orders[0]["user_id"],
            "overall_rating": 5,
            "delivery_rating": 5,
            "product_quality_rating": 5,
            "would_recommend": True,
            "feedback": "Her sey mukemmeldi, cok memnun kaldim!",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
        {
            "id": "survey_2",
            "order_id": paid_orders[1]["id"],
            "user_id": paid_orders[1]["user_id"],
            "overall_rating": 4,
            "delivery_rating": 4,
            "product_quality_rating": 5,
            "would_recommend": True,
            "feedback": "Urunler taze, teslimat biraz gecikti ama sorun degil.",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
        {
            "id": "survey_3",
            "order_id": paid_orders[2]["id"],
            "user_id": paid_orders[2]["user_id"],
            "overall_rating": 3,
            "delivery_rating": 3,
            "product_quality_rating": 4,
            "would_recommend": False,
            "feedback": "Fiyatlar biraz yuksek buldum.",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
    ]
    if paid_orders:
        await db.surveys.insert_many(sample_surveys[:len(paid_orders)])
        print(f"[OK] surveys: {min(3, len(paid_orders))} sample records inserted")

    sample_reviews = [
        {
            "id": "rev_1",
            "user_id": "user_1",
            "user_name": "Ahmet Yilmaz",
            "rating": 5,
            "comment": "Urunler cok taze geldi, teslimat hizliydi. Kesinlikle tavsiye ederim!",
            "product_id": None,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
        {
            "id": "rev_2",
            "user_id": "user_2",
            "user_name": "Ayse Kaya",
            "rating": 4,
            "comment": "Sebzeler harika kalitede. Fiyatlar da makul.",
            "product_id": "f1",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
        {
            "id": "rev_3",
            "user_id": "user_3",
            "user_name": "Mehmet Demir",
            "rating": 5,
            "comment": "Her hafta siparis veriyorum, hic hayal kirikligi yasamadim.",
            "product_id": None,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        },
    ]
    await db.reviews.insert_many(sample_reviews)
    print("[OK] reviews: 3 sample records inserted")

    print("Admin user:")
    print("  Username: mku123456")
    print("  Password: 1234567a")

    client.close()

if __name__ == "__main__":
    asyncio.run(seed_database())
