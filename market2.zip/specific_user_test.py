import requests
import sys
import json

class SpecificUserTester:
    def __init__(self, base_url="https://taze-market-shop.preview.tazemarket.sh/api"):
        self.base_url = base_url
        self.token = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        
        if self.token:
            headers['Authorization'] = f'Bearer {self.token}'

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)

            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    return success, response.json() if response.text else {}
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_detail = response.json()
                    print(f"   Error: {error_detail}")
                except:
                    print(f"   Response: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

def main():
    print("🚀 Testing with Specific User Credentials")
    print("=" * 50)
    
    tester = SpecificUserTester()
    
    # Test user credentials from review request
    test_user_data = {
        "name": "Test Kullanıcı",
        "email": "test@taze.com",
        "password": "Test123!"
    }
    
    # Try to register the test user
    print("\n=== Testing Registration ===")
    success, response = tester.run_test(
        "Register Test User",
        "POST",
        "auth/register",
        200,
        data=test_user_data
    )
    
    if not success:
        # If registration fails (user exists), try login
        print("\n=== User exists, trying login ===")
        login_data = {
            "email": test_user_data["email"],
            "password": test_user_data["password"]
        }
        
        success, response = tester.run_test(
            "Login Test User",
            "POST",
            "auth/login",
            200,
            data=login_data
        )
    
    if success and 'token' in response:
        tester.token = response['token']
        print(f"✅ Authentication successful for: {response['user']['name']}")
        
        # Test getting user info
        tester.run_test(
            "Get User Info",
            "GET",
            "auth/me",
            200
        )
        
        # Test products endpoint
        success, products = tester.run_test(
            "Get Products",
            "GET",
            "products",
            200
        )
        
        if success:
            print(f"   Found {len(products)} products total")
            
            # Test fruit category
            success, fruits = tester.run_test(
                "Get Fruit Products",
                "GET",
                "products?category=fruit",
                200
            )
            
            if success:
                print(f"   Found {len(fruits)} fruit products")
                
            # Test vegetable category  
            success, vegetables = tester.run_test(
                "Get Vegetable Products",
                "GET",
                "products?category=vegetable",
                200
            )
            
            if success:
                print(f"   Found {len(vegetables)} vegetable products")
    
    # Print results
    print(f"\n{'='*50}")
    print(f"📊 Tests passed: {tester.tests_passed}/{tester.tests_run}")
    return 0 if tester.tests_passed == tester.tests_run else 1

if __name__ == "__main__":
    sys.exit(main())