# Taze Market

Meyve ve sebze satışı için geliştirilmiş full-stack e-ticaret projesi. Müşteri arayüzü, sepet, ödeme, sipariş takibi, yorumlar, destek asistanı ve admin paneli içerir.

## Kullanılan teknolojiler

| Katman | Teknoloji |
|--------|-----------|
| **Frontend** | React 19, JavaScript, Tailwind CSS, React Router, Axios |
| **Backend** | Python 3, FastAPI, Uvicorn |
| **Veritabanı** | MongoDB |
| **Kimlik doğrulama** | JWT + bcrypt |
| **Ödeme** | Yerel kart/havale + opsiyonel Stripe |

### Önemli kütüphaneler

**Frontend:** `react`, `react-router-dom`, `axios`, `tailwindcss`, `lucide-react`, `sonner`, Radix UI bileşenleri

**Backend:** `fastapi`, `uvicorn`, `motor`, `pymongo`, `pydantic`, `PyJWT`, `passlib`, `stripe`, `python-dotenv`

## Gerekli programlar (Windows)

Kurulumdan önce bilgisayarınızda şunlar olmalı:

1. **Node.js** (LTS) — https://nodejs.org  
2. **Python 3.11+** — https://python.org (kurulumda “Add to PATH” işaretleyin)  
3. **MongoDB Community Server** — https://www.mongodb.com/try/download/community  
   - veya: `winget install MongoDB.Server`

## Hızlı başlangıç (Windows)

### 1. Projeyi indirin

GitHub'dan indirdiyseniz zip'i açın veya:

```bash
git clone <repo-url>
cd market1
```

### 2. Ortam dosyalarını oluşturun

```text
backend\.env.example  →  backend\.env   (kopyalayın)
frontend\.env.example →  frontend\.env  (kopyalayın)
```

`backend\.env` içinde en az şunlar olmalı:

```env
MONGO_URL=mongodb://localhost:27017
DB_NAME=tazemarket
JWT_SECRET=guclu_bir_anahtar
```

`frontend\.env`:

```env
REACT_APP_BACKEND_URL=http://localhost:8001
```

### 3. İlk kurulum (sadece bir kez)

Proje klasöründe **`ilk-kurulum.bat`** dosyasına çift tıklayın.

Bu script:

- MongoDB'yi kontrol eder
- Python sanal ortamı (`venv`) ve paketleri kurar
- Veritabanını örnek ürünlerle doldurur (`seed_products.py`)
- Frontend'i derler ve `build/` klasörüne kopyalar

### 4. Projeyi çalıştırın

**`calistir.bat`** dosyasına çift tıklayın.

| Servis | Adres |
|--------|-------|
| Site (frontend) | http://localhost:4173 |
| API (backend) | http://localhost:8001/api |

Tarayıcı otomatik açılır. Kapatmak için açılan 2 siyah terminal penceresini kapatın.

## Manuel çalıştırma (isteğe bağlı)

**Backend:**

```bash
cd backend
venv\Scripts\uvicorn.exe server:app --host 127.0.0.1 --port 8001 --reload
```

**Frontend (geliştirme):**

```bash
cd frontend
npm install
npm start
```

**Frontend (production build):**

```bash
cd frontend
npm run build
xcopy /E /Y /I build\* ..\build\
npx serve -s ../build -l 4173
```

## Demo hesaplar

Seed script çalıştıktan sonra:

| Rol | Giriş | Şifre |
|-----|-------|-------|
| **Admin** | `mku123456` (admin login) | `1234567a` |
| **Müşteri** | `furkan.kondu@mail.com` | `furkan123` |
| **Test kullanıcıları** | `ahmet.yilmaz1@mail.com` vb. | `test12345` |

Admin panel: http://localhost:4173/admin/login

## Proje yapısı

```text
market1/
├── backend/           # FastAPI API + MongoDB
│   ├── server.py      # Ana API dosyası
│   ├── seed_products.py
│   ├── requirements.txt
│   └── .env           # (siz oluşturursunuz)
├── frontend/          # React uygulaması
│   ├── src/
│   ├── public/urunler/  # Ürün görselleri
│   └── package.json
├── build/             # Derlenmiş site (ilk-kurulum sonrası)
├── ilk-kurulum.bat    # İlk kurulum
├── calistir.bat       # Siteyi başlat
└── README.md
```

## GitHub'a yükleme

1. GitHub'da yeni bir repo oluşturun (ör. `taze-market`)
2. Proje klasöründe:

```bash
git init
git add .
git commit -m "Taze Market ilk sürüm"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADINIZ/taze-market.git
git push -u origin main
```

**Not:** `.gitignore` sayesinde `node_modules/`, `venv/`, `.env` ve büyük zip dosyaları repoya gitmez. `.env.example` dosyalarını repoya ekleyin.

## Sık karşılaşılan sorunlar

| Sorun | Çözüm |
|-------|-------|
| “Build bulunamadı” | `ilk-kurulum.bat` çalıştırın |
| “MongoDB başlatılamadı” | MongoDB servisini başlatın veya kurun |
| Ürünler yüklenmiyor | Backend çalışıyor mu? `http://localhost:8001/api/products` açın |
| Giriş olmuyor | `backend\.env` ve `frontend\.env` dosyalarını kontrol edin |
| Port meşgul | 8001 veya 4173 kullanan programı kapatın |

## Özellikler

- Ürün listeleme, sepet, ödeme (kart / havale)
- Kullanıcı kayıt & giriş
- Sipariş geçmişi, memnuniyet anketi, yorumlar
- AI destek sohbeti (opsiyonel `GEMINI_API_KEY`)
- Admin paneli: ürün, sipariş, kullanıcı, anket yönetimi
- KVKK, iletişim, iade koşulları sayfaları

## Lisans

Eğitim / sunum amaçlı proje. Kendi kullanımınıza göre lisans ekleyebilirsiniz.
