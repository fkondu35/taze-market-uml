import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import { X, Send, User } from 'lucide-react';

const BACKEND_URL = (process.env.REACT_APP_BACKEND_URL || window.location.origin).replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;
const BOT_ICON = `${process.env.PUBLIC_URL}/ai-bot.png`;

const BotAvatar = ({ size = 'md', className = '' }) => {
  const sizes = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-14 h-14',
    xl: 'w-16 h-16',
  };

  return (
    <img
      src={BOT_ICON}
      alt="Taze Market Asistanı"
      className={`${sizes[size] || sizes.md} rounded-full object-cover shadow-md ${className}`}
    />
  );
};

const SupportChat = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Merhaba! Ben Taze Market yapay zeka destek asistanıyım. Sipariş, iade, ürün veya iletişim konularında size yardımcı olabilirim.',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  const sendMessage = async (e) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || loading) return;

    const userMsg = { role: 'user', content: text };
    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');
    setLoading(true);

    try {
      const res = await axios.post(`${API}/support/chat`, {
        message: text,
        history: messages.filter((m) => m.role !== 'system'),
      });
      setMessages([...newHistory, { role: 'assistant', content: res.data.reply }]);
    } catch {
      setMessages([
        ...newHistory,
        {
          role: 'assistant',
          content: 'Bağlantı hatası oluştu. Lütfen aliaslann277@gmail.com adresinden bize ulaşın.',
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const quickQuestions = [
    'Kargo ne kadar sürer?',
    'İade koşulları neler?',
    'İletişim e-postası nedir?',
  ];

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-6 right-6 z-50 rounded-full shadow-2xl transition-all hover:scale-110 ring-4 ring-white/80"
          aria-label="Destek asistanı"
        >
          <BotAvatar size="xl" />
        </button>
      )}

      {open && (
        <div className="fixed bottom-6 right-6 z-50 w-[360px] max-w-[calc(100vw-2rem)] h-[500px] max-h-[calc(100vh-6rem)] flex flex-col bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden">
          <div className="bg-[#1A4D2E] text-white px-4 py-3 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <BotAvatar size="md" className="ring-2 ring-white/30" />
              <div>
                <p className="font-semibold text-sm">Taze Market Asistanı</p>
                <p className="text-xs text-green-100">Yapay zeka destek</p>
              </div>
            </div>
            <button onClick={() => setOpen(false)} className="p-1 hover:bg-white/20 rounded-lg transition">
              <X size={20} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#F9F7F2]">
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-2 items-end ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                {msg.role === 'user' ? (
                  <div className="w-8 h-8 rounded-full bg-[#FF6B00] flex items-center justify-center shrink-0">
                    <User size={16} className="text-white" />
                  </div>
                ) : (
                  <BotAvatar size="sm" />
                )}
                <div className={`max-w-[80%] px-3 py-2 rounded-2xl text-sm whitespace-pre-wrap ${
                  msg.role === 'user'
                    ? 'bg-[#FF6B00] text-white rounded-tr-sm'
                    : 'bg-white text-[#1A4D2E] border border-gray-100 rounded-tl-sm'
                }`}>
                  {msg.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex gap-2 items-end">
                <BotAvatar size="sm" />
                <div className="bg-white px-4 py-2 rounded-2xl rounded-tl-sm border border-gray-100 text-sm text-[#4A6B5A]">
                  Yazıyor...
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {messages.length <= 1 && (
            <div className="px-3 pb-2 flex flex-wrap gap-2 shrink-0 bg-[#F9F7F2]">
              {quickQuestions.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => setInput(q)}
                  className="text-xs px-3 py-1.5 rounded-full bg-white border border-gray-200 text-[#1A4D2E] hover:border-[#FF6B00] transition"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          <form onSubmit={sendMessage} className="p-3 border-t bg-white flex gap-2 shrink-0">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Mesajınızı yazın..."
              className="flex-1 px-3 py-2 rounded-full border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF6B00]"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="w-10 h-10 rounded-full bg-[#FF6B00] hover:bg-[#E65100] text-white flex items-center justify-center disabled:opacity-50 transition"
            >
              <Send size={18} />
            </button>
          </form>
        </div>
      )}
    </>
  );
};

export default SupportChat;
