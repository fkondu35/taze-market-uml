// API Configuration (from config.js)
const API_URL = typeof CONFIG !== 'undefined' ? CONFIG.API_URL : '/api';

// Auth helpers
function getToken() {
  return localStorage.getItem('token');
}

function setToken(token) {
  localStorage.setItem('token', token);
}

function removeToken() {
  localStorage.removeItem('token');
}

function getUser() {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}

function setUser(user) {
  localStorage.setItem('user', JSON.stringify(user));
}

function removeUser() {
  localStorage.removeItem('user');
}

function isLoggedIn() {
  return !!getToken();
}

// Toast notification
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span>${type === 'success' ? '✓' : '✗'}</span>
    <span>${message}</span>
  `;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// API calls
async function apiCall(endpoint, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Bir hata oluştu');
    }
    
    return await response.json();
  } catch (error) {
    throw error;
  }
}

// Update navbar based on auth state
function updateNavbar() {
  const user = getUser();
  const authLinks = document.getElementById('auth-links');
  const cartBadge = document.getElementById('cart-badge');
  
  if (user && authLinks) {
    const adminLink = user.is_admin ? '<li><a href="admin.html" style="color: #FF6B00; font-weight: 600;">🔧 Admin</a></li>' : '';
    authLinks.innerHTML = `
      <li><a href="products.html">Meyveler</a></li>
      <li><a href="products.html?category=vegetable">Sebzeler</a></li>
      ${adminLink}
      <li><a href="favorites.html">❤️</a></li>
      <li class="cart-badge">
        <a href="cart.html">🛒</a>
        <span class="badge" id="cart-count" style="display: none;">0</span>
      </li>
      <li>
        <div class="user-menu" style="position: relative;">
          <button onclick="toggleUserMenu()" style="background: none; border: none; cursor: pointer; font-size: 1.5rem;">👤</button>
          <div id="user-dropdown" style="display: none; position: absolute; right: 0; top: 100%; background: white; border-radius: 0.5rem; box-shadow: 0 4px 6px rgba(0,0,0,0.1); min-width: 150px; margin-top: 0.5rem;">
            <a href="profile.html" style="display: block; padding: 0.75rem 1rem; color: #1A4D2E; text-decoration: none;">Profilim</a>
            <a href="orders.html" style="display: block; padding: 0.75rem 1rem; color: #1A4D2E; text-decoration: none;">Siparişlerim</a>
            <button onclick="logout()" style="width: 100%; text-align: left; padding: 0.75rem 1rem; background: none; border: none; color: #ef4444; cursor: pointer;">Çıkış Yap</button>
          </div>
        </div>
      </li>
    `;
    updateCartBadge();
  } else if (authLinks) {
    authLinks.innerHTML = `
      <li><a href="products.html">Meyveler</a></li>
      <li><a href="products.html?category=vegetable">Sebzeler</a></li>
      <li><a href="auth.html" class="btn-primary">Giriş Yap</a></li>
    `;
  }
}

function toggleUserMenu() {
  const dropdown = document.getElementById('user-dropdown');
  dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
}

// Close dropdown when clicking outside
document.addEventListener('click', (e) => {
  const userMenu = document.querySelector('.user-menu');
  const dropdown = document.getElementById('user-dropdown');
  if (dropdown && userMenu && !userMenu.contains(e.target)) {
    dropdown.style.display = 'none';
  }
});

async function updateCartBadge() {
  if (!isLoggedIn()) return;
  
  try {
    const cart = await apiCall('/cart');
    const count = cart.items.reduce((sum, item) => sum + item.quantity, 0);
    const badge = document.getElementById('cart-count');
    if (badge) {
      if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'flex';
      } else {
        badge.style.display = 'none';
      }
    }
  } catch (error) {
    console.error('Failed to update cart badge:', error);
  }
}

function logout() {
  removeToken();
  removeUser();
  window.location.href = 'index.html';
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  updateNavbar();
});