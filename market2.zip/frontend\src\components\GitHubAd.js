import React from 'react';
import { Github } from 'lucide-react';
import { GITHUB_URL } from '../config/site';

const GitHubAd = () => {
  return (
    <div className="github-ad my-12" data-testid="github-ad">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center space-x-4">
          <Github size={48} className="text-white" />
          <div>
            <a
              href={GITHUB_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xl font-bold text-white mb-1 block hover:underline"
              style={{ fontFamily: 'Playfair Display' }}
              data-testid="github-ad-title"
            >
              Proje Tasarımı
            </a>
            <p className="text-white/90">
              Kaynak kodları GitHub&apos;da inceleyebilirsiniz.
            </p>
          </div>
        </div>
        <a
          href={GITHUB_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-white text-[#1A4D2E] px-6 py-3 rounded-full font-semibold hover:bg-gray-100 transition-all hover:scale-105"
          data-testid="github-link"
        >
          GitHub&apos;da İncele
        </a>
      </div>
    </div>
  );
};

export default GitHubAd;
