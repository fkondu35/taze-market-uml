import React from 'react';
import { Link } from 'react-router-dom';

const InfoPageLayout = ({ title, subtitle, children }) => (
  <div className="min-h-screen py-12">
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <Link to="/" className="text-[#FF6B00] hover:text-[#E65100] text-sm font-medium">
          ← Ana Sayfa
        </Link>
        <h1 className="text-4xl font-bold text-[#1A4D2E] mt-4 mb-2" style={{ fontFamily: 'Playfair Display' }}>
          {title}
        </h1>
        {subtitle && <p className="text-[#4A6B5A] text-lg">{subtitle}</p>}
      </div>
      <div className="card p-8 prose prose-green max-w-none text-[#4A6B5A] leading-relaxed space-y-4">
        {children}
      </div>
    </div>
  </div>
);

export default InfoPageLayout;
