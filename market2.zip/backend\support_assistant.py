import os
from typing import List, Dict, Optional

SUPPORT_EMAIL = os.environ.get("SUPPORT_EMAIL", "aliaslann277@gmail.com")

STORE_CONTEXT = f"""
Taze Market, iki üniversite öğrencisinin girişimiyle kurulmuş online bir meyve ve sebze marketidir.
İletişim e-postası: {SUPPORT_EMAIL}
Vizyon: Türkiye'nin en güvenilir ve erişilebilir online taze gıda platformu olmak.
Misyon: Çiftçiden sofraya, taze ve kaliteli ürünleri uygun fiyatla ulaştırmak.
Kargo: Siparişlerde ücretsiz kargo uygulanır.
İade: Hasarlı, bozuk veya yanlış gelen ürünler 24 saat içinde bildirilmelidir; 7 iş günü içinde iade/değişim yapılır.
Ödeme: Stripe ile güvenli online ödeme ve havale/EFT seçenekleri mevcuttur.
Site adresi: taze meyve ve sebze kategorileri (fruit, vegetable).
"""


def _normalize(text: str) -> str:
    return text.lower().strip()


async def _try_gemini(message: str, history: List[Dict[str, str]]) -> Optional[str]:
    api_key = os.environ.get("GEMINI_API_KEY", "").strip()
    if not api_key:
        return None
    try:
        import google.generativeai as genai

        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-2.0-flash")
        chat_history = []
        for item in history[-6:]:
            role = "user" if item.get("role") == "user" else "model"
            chat_history.append({"role": role, "parts": [item.get("content", "")]})

        prompt = (
            f"{STORE_CONTEXT}\n\n"
            "Sen Taze Market'in Türkçe konuşan destek asistanısın. "
            "Kısa, samimi ve yardımcı ol. Sadece site, sipariş, ürün ve destek konularında cevap ver.\n\n"
            f"Müşteri: {message}"
        )
        response = await __import__("asyncio").to_thread(model.generate_content, prompt)
        return response.text.strip() if response.text else None
    except Exception:
        return None


async def _rule_based_response(message: str, db=None) -> str:
    msg = _normalize(message)

    if any(w in msg for w in ["merhaba", "selam", "hey", "günaydın", "iyi günler"]):
        return (
            "Merhaba! Ben Taze Market yapay zeka destek asistanıyım. "
            "Sipariş, ürün, iade, kargo veya iletişim hakkında sorularınızı yanıtlayabilirim."
        )

    if any(w in msg for w in ["hikaye", "kim", "kurucu", "girişim", "öğrenci", "ogrenci"]):
        return (
            "Taze Market, iki üniversite öğrencisinin girişimiyle kuruldu. "
            "Amacımız çiftçiden sofraya en taze meyve ve sebzeleri ulaştırmak. "
            "Detaylı bilgi için sitemizdeki 'Bizim Hikayemiz' sayfasına göz atabilirsiniz."
        )

    if any(w in msg for w in ["vizyon", "misyon", "amaç", "hedef"]):
        return (
            "Vizyonumuz: Türkiye'nin en güvenilir online taze gıda platformu olmak.\n"
            "Misyonumuz: Kaliteli, taze ve uygun fiyatlı meyve-sebzeleri doğrudan size ulaştırmak."
        )

    if any(w in msg for w in ["iade", "değişim", "degisim", "iptal", "geri"]):
        return (
            "İade koşullarımız:\n"
            "• Hasarlı, bozuk veya yanlış ürünler teslimattan sonra 24 saat içinde bildirilmelidir.\n"
            "• Geçerli iade talepleri 7 iş günü içinde değerlendirilir.\n"
            "• Onaylanan iadelerde ücret iadesi veya ürün değişimi yapılır.\n"
            f"• Destek için: {SUPPORT_EMAIL}"
        )

    if any(w in msg for w in ["kargo", "teslimat", "gönderim", "gonderim", "ne zaman gelir"]):
        return (
            "Siparişlerinizde kargo ücretsizdir. "
            "Teslimat süresi bulunduğunuz bölgeye göre genellikle 1-3 iş günü arasındadır. "
            "Sipariş durumunuzu 'Siparişlerim' sayfasından takip edebilirsiniz."
        )

    if any(w in msg for w in ["ödeme", "odeme", "stripe", "kart", "havale", "eft"]):
        return (
            "Ödeme seçeneklerimiz: Stripe ile güvenli kredi/banka kartı ödemesi. "
            "Sepetinizi onayladıktan sonra ödeme sayfasına yönlendirilirsiniz."
        )

    if any(w in msg for w in ["iletişim", "iletisim", "mail", "e-posta", "eposta", "email", "ulaş", "ulas"]):
        return f"Bize {SUPPORT_EMAIL} adresinden ulaşabilirsiniz. En kısa sürede dönüş yapıyoruz."

    if any(w in msg for w in ["sipariş", "siparis", "order", "takip"]):
        return (
            "Siparişlerinizi giriş yaptıktan sonra 'Siparişlerim' menüsünden görebilirsiniz. "
            "Alışveriş sonrası memnuniyet anketi de doldurabilirsiniz."
        )

    if any(w in msg for w in ["üye", "uye", "kayıt", "kayit", "giriş", "giris", "hesap"]):
        return (
            "Sağ üstten 'Giriş Yap' ile hesabınıza erişebilir veya yeni hesap oluşturabilirsiniz. "
            "Üye olmadan ürünleri görüntüleyebilirsiniz; sepete eklemek için giriş gerekir."
        )

    if any(w in msg for w in ["fiyat", "ucuz", "pahalı", "pahali", "indirim"]):
        return "Güncel fiyatları 'Ürünler' sayfasından inceleyebilirsiniz. Kampanyalar için bizi takip edin!"

    if db and any(w in msg for w in ["ürün", "urun", "meyve", "sebze", "elma", "domates", "muz", "kaç"]):
        products = await db.products.find({}, {"_id": 0, "name": 1, "price": 1, "unit": 1, "category": 1}).to_list(200)
        if not products:
            return "Şu an ürün listemize erişilemiyor. Lütfen biraz sonra tekrar deneyin."

        matched = [p for p in products if any(word in _normalize(p["name"]) for word in msg.split() if len(word) > 2)]
        if matched:
            lines = [f"• {p['name']}: {p['price']:.2f} ₺/{p['unit']}" for p in matched[:5]]
            return "Aradığınız ürünler:\n" + "\n".join(lines)

        fruits = sum(1 for p in products if p.get("category") == "fruit")
        veggies = sum(1 for p in products if p.get("category") == "vegetable")
        return f"Stoklarımızda {len(products)} ürün var ({fruits} meyve, {veggies} sebze). 'Ürünler' sayfasından tümünü görebilirsiniz."

    if any(w in msg for w in ["teşekkür", "tesekkur", "sağol", "sagol"]):
        return "Rica ederiz! Başka bir sorunuz olursa her zaman buradayım."

    return (
        "Size yardımcı olmak isterim! Şunları sorabilirsiniz:\n"
        "• Sipariş ve kargo durumu\n"
        "• İade koşulları\n"
        "• Ürünler ve fiyatlar\n"
        "• İletişim bilgileri\n"
        "• Vizyon ve misyonumuz\n\n"
        f"Daha detaylı destek için: {SUPPORT_EMAIL}"
    )


async def get_support_reply(message: str, history: List[Dict[str, str]], db=None) -> str:
    if not message or not message.strip():
        return "Lütfen bir soru yazın, size yardımcı olayım."

    gemini_reply = await _try_gemini(message, history)
    if gemini_reply:
        return gemini_reply

    return await _rule_based_response(message, db)
