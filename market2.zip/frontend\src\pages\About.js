import React from 'react';
import InfoPageLayout from '../components/InfoPageLayout';

const About = () => (
  <InfoPageLayout
    title="Bizim Hikayemiz"
    subtitle="İki üniversite öğrencisinin girişimiyle doğdu"
  >
    <p>
      Taze Market, iki üniversite öğrencisinin ortak hayaliyle kuruldu: Herkesin sofrasına
      taze, sağlıklı ve uygun fiyatlı meyve ile sebzeleri ulaştırmak.
    </p>
    <p>
      Kampüs hayatında taze ürünlere erişmenin ne kadar zor olduğunu gördük ve
      &quot;Neden daha iyi bir çözüm olmasın?&quot; diye sorduk. Böylece çiftçilerden
      doğrudan tedarik edilen ürünleri online platforma taşıyan Taze Market doğdu.
    </p>
    <p>
      Küçük bir öğrenci girişimi olarak başladık; bugün yüzlerce müşteriye hizmet veren,
      güvenilir bir online market haline geldik. Her siparişte aynı heyecanı ve özeni
      koruyoruz.
    </p>
    <p className="font-semibold text-[#1A4D2E]">
      Biz sadece meyve-sebze satmıyoruz — tazeliği, güveni ve öğrenci ruhunu sofranıza taşıyoruz.
    </p>
  </InfoPageLayout>
);

export default About;
