"""Mevcut siparişlere farklı saatler ata (eski siparişler erken, yeniler geç saat)."""
import asyncio
import os
from datetime import datetime, timezone
from pathlib import Path

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")


def parse_ts(value: str) -> datetime:
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    return datetime.fromisoformat(value)


async def main():
    client = AsyncIOMotorClient(os.environ["MONGO_URL"])
    db = client[os.environ["DB_NAME"]]

    orders = await db.orders.find({}, {"_id": 0, "id": 1, "timestamp": 1}).to_list(1000)
    if not orders:
        print("Sipariş bulunamadı.")
        return

    orders.sort(key=lambda o: o.get("timestamp", ""))
    total = len(orders)
    updated = 0

    for i, order in enumerate(orders):
        dt = parse_ts(order["timestamp"])
        progress = i / max(total - 1, 1)
        minutes_from_8am = int(progress * (14 * 60 + 45))
        hour = min(8 + minutes_from_8am // 60, 22)
        minute = minutes_from_8am % 60
        second = (i * 11 + 5) % 60
        new_dt = dt.replace(hour=hour, minute=minute, second=second, microsecond=0)
        new_ts = new_dt.isoformat()
        await db.orders.update_one({"id": order["id"]}, {"$set": {"timestamp": new_ts}})
        updated += 1
        print(f"  #{order['id'][:8]} -> {new_ts}")

    print(f"\n[OK] {updated} sipariş güncellendi.")


if __name__ == "__main__":
    asyncio.run(main())
