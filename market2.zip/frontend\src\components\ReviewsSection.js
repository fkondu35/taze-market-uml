import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../contexts/AuthContext';
import { useReviews } from '../contexts/ReviewsContext';
import { toast } from 'sonner';
import { MessageSquare, Star } from 'lucide-react';
import StarRating from './StarRating';

const BACKEND_URL = (process.env.REACT_APP_BACKEND_URL || window.location.origin).replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;

const ReviewsSection = ({ showForm = true, compact = false }) => {
  const { token, user } = useAuth();
  const { reviews, averageRating, total, loading, refreshReviews } = useReviews();
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ rating: 0, comment: '' });

  const displayedReviews = compact ? reviews.slice(0, 3) : reviews;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!token) {
      toast.error('Yorum yapmak için giriş yapın');
      return;
    }
    if (form.rating === 0) {
      toast.error('Lütfen puan verin');
      return;
    }
    if (form.comment.trim().length < 3) {
      toast.error('Yorum en az 3 karakter olmalı');
      return;
    }

    setSubmitting(true);
    try {
      await axios.post(
        `${API}/reviews`,
        { rating: form.rating, comment: form.comment.trim() },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Yorumunuz yayınlandı!');
      setForm({ rating: 0, comment: '' });
      await refreshReviews();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Yorum gönderilemedi');
    } finally {
      setSubmitting(false);
    }
  };

  const formatDate = (value) => {
    if (!value) return '';
    return new Date(value).toLocaleDateString('tr-TR', {
      year: 'numeric', month: 'long', day: 'numeric',
    });
  };

  if (loading) {
    return (
      <div className="text-center py-12 text-[#4A6B5A]">Yorumlar yükleniyor...</div>
    );
  }

  return (
    <section className={compact ? 'py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8' : 'py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8'}>
      <div className={`${compact ? 'mb-8' : 'text-center mb-12'}`}>
        <h2 className={`font-bold text-[#1A4D2E] mb-4 ${compact ? 'text-3xl' : 'text-3xl sm:text-4xl text-center'}`} style={{ fontFamily: 'Playfair Display' }}>
          Müşteri Yorumları
        </h2>
        {total > 0 && (
          <div className={`flex items-center gap-2 text-[#4A6B5A] ${compact ? '' : 'justify-center'}`}>
            <Star className="text-[#FF6B00] fill-[#FF6B00]" size={24} />
            <span className="text-2xl font-bold text-[#1A4D2E]">{averageRating}</span>
            <span>/ 5 — {total} yorum</span>
          </div>
        )}
      </div>

      <div className={`grid gap-8 ${showForm ? 'lg:grid-cols-3' : ''}`}>
        {showForm && (
          <div className="lg:col-span-1">
            <div className="card p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-4">
                <MessageSquare className="text-[#FF6B00]" size={22} />
                <h3 className="text-xl font-bold text-[#1A4D2E]" style={{ fontFamily: 'Playfair Display' }}>
                  Yorum Yap
                </h3>
              </div>

              {user ? (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-[#1A4D2E] mb-2">Puanınız</label>
                    <StarRating
                      value={form.rating}
                      onChange={(val) => setForm({ ...form, rating: val })}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#1A4D2E] mb-2">Yorumunuz</label>
                    <textarea
                      rows={4}
                      required
                      minLength={3}
                      value={form.comment}
                      onChange={(e) => setForm({ ...form, comment: e.target.value })}
                      placeholder="Deneyiminizi paylaşın..."
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00]"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="w-full btn-primary disabled:opacity-50"
                  >
                    {submitting ? 'Gönderiliyor...' : 'Yorumu Gönder'}
                  </button>
                </form>
              ) : (
                <div className="text-center py-4">
                  <p className="text-[#4A6B5A] mb-4">Yorum yapmak için giriş yapmalısınız.</p>
                  <Link to="/auth" className="btn-primary inline-block">Giriş Yap</Link>
                </div>
              )}
            </div>
          </div>
        )}

        <div className={showForm ? 'lg:col-span-2' : ''}>
          {displayedReviews.length === 0 ? (
            <div className="card p-12 text-center text-[#4A6B5A]">
              Henüz yorum yok. İlk yorumu siz yapın!
            </div>
          ) : (
            <div className="space-y-4">
              {displayedReviews.map((review) => (
                <div key={review.id} className="card p-6">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-semibold text-[#1A4D2E]">{review.user_name}</p>
                      <p className="text-sm text-[#4A6B5A]">{formatDate(review.timestamp)}</p>
                    </div>
                    <StarRating value={review.rating} readOnly size={18} />
                  </div>
                  <p className="text-[#4A6B5A] leading-relaxed">{review.comment}</p>
                  {review.product_name && (
                    <p className="text-sm text-[#FF6B00] mt-2">Ürün: {review.product_name}</p>
                  )}
                </div>
              ))}
            </div>
          )}

          {compact && total > 3 && (
            <div className="text-center mt-6">
              <Link to="/yorumlar" className="btn-secondary">Tüm Yorumları Gör ({total})</Link>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default ReviewsSection;
