# TazeMarket Veritabani Raporu

Bu projede veritabani MongoDB uzerinden entegre calismaktadir. Koleksiyonlar, API katmani tarafinda `backend/server.py` ile aktif olarak kullanilir.

## Koleksiyonlar ve Alan Tipleri

### 1) `users`
- `id` (string, PK benzeri benzersiz anahtar)
- `email` (string, benzersiz)
- `name` (string)
- `password` (string, hash)
- `is_admin` (bool)
- `timestamp` (datetime string)

### 2) `products`
- `id` (string, PK benzeri benzersiz anahtar)
- `name` (string)
- `price` (float)
- `unit` (string)
- `image` (string, URL)
- `category` (string: `fruit` veya `vegetable`)
- `description` (string, opsiyonel)
- `in_stock` (bool)

### 3) `carts`
- `user_id` (string, FK -> `users.id`)
- `items` (array)
  - `product_id` (string, FK -> `products.id`)
  - `quantity` (int)
- `updated_at` (datetime string)

### 4) `favorites`
- `user_id` (string, FK -> `users.id`)
- `product_id` (string, FK -> `products.id`)
- `timestamp` (datetime string)

### 5) `orders`
- `id` (string, PK benzeri benzersiz anahtar)
- `user_id` (string, FK -> `users.id`)
- `items` (array)
  - `product_id` (string, FK -> `products.id`)
  - `name` (string)
  - `price` (float)
  - `quantity` (int)
  - `subtotal` (float)
- `total` (float)
- `status` (string: `pending`, `paid`, `cancelled`)
- `payment_session_id` (string)
- `payment_method` (string)
- `timestamp` (datetime string)

### 6) `payment_transactions`
- `id` (string, PK benzeri benzersiz anahtar)
- `session_id` (string, FK -> `orders.payment_session_id`)
- `user_id` (string, FK -> `users.id`)
- `amount` (float)
- `currency` (string)
- `payment_status` (string: `pending`, `paid`, `failed`, `expired`)
- `metadata.order_id` (string, FK -> `orders.id`)
- `metadata.payment_method` (string)
- `timestamp` (datetime string)
- `updated_timestamp` (datetime string)

## Iliski Diyagrami

```text
users (id) 1 ------ n carts (user_id)
users (id) 1 ------ n favorites (user_id)
users (id) 1 ------ n orders (user_id)
users (id) 1 ------ n payment_transactions (user_id)

products (id) 1 --- n carts.items.product_id
products (id) 1 --- n favorites.product_id
products (id) 1 --- n orders.items.product_id

orders (id) 1 ----- n payment_transactions.metadata.order_id
orders.payment_session_id 1 -- 1 payment_transactions.session_id
```

## Sahte Veri Uretim Sinifi

Sahte veriler `backend/fake_data_generator.py` icindeki `MarketFakeDataGenerator` sinifi ile uretilir.

### Sinif Ozellikleri
- Rastgele ama tekrarlanabilir veri icin `seed` destekler.
- Birbirleriyle uyumlu kayitlar uretir (ornegin `order.user_id` mutlaka mevcut bir user id olur).
- Urettigi veri tipleri alan ihtiyaclariyla uyumludur (string, float, bool, datetime string, array object).

### Temel Metotlar
- `generate_users(count=10)`: Anlamli isim ve e-posta ile kullanici listesi uretir.
- `generate_carts(user_ids, product_ids, count=10)`: Kullanici ve urunleri iliskisel cart kayitlarina donusturur.
- `generate_favorites(user_ids, product_ids, count=20)`: Favori iliskilerini uretir.
- `generate_orders_and_payments(user_ids, products, count=10)`: Siparis + odeme kayitlarini birlikte uretir.

### Kullanim Kilavuzu
1. `backend/.env` dosyasinda `MONGO_URL` ve `DB_NAME` degerlerini kontrol edin.
2. Backend klasorunde:
   - `python seed_products.py`
3. Komut calistiginda tum koleksiyonlar temizlenir ve tekrar doldurulur.
4. Her ana koleksiyonda en az 10 kayit olusur:
   - `products`: 20
   - `users`: 11 (10 sahte + 1 admin)
   - `carts`: 10
   - `favorites`: 20
   - `orders`: 12
   - `payment_transactions`: 12
