import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import axios from 'axios';
import { CreditCard, Building2, Lock, ArrowLeft, Copy, CheckCircle } from 'lucide-react';

const BACKEND_URL = (process.env.REACT_APP_BACKEND_URL || window.location.origin).replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;

const Payment = () => {
  const navigate = useNavigate();
  const { cart, getCartTotal, fetchCart } = useCart();
  const { token } = useAuth();
  const [method, setMethod] = useState('card');
  const [loading, setLoading] = useState(false);
  const [bankInfo, setBankInfo] = useState(null);
  const [cardForm, setCardForm] = useState({
    card_holder: '',
    card_number: '',
    expiry: '',
    cvv: '',
  });

  const formatMoney = (value) => {
    const n = typeof value === 'string' ? Number(value) : value;
    return Number.isFinite(n) ? n.toFixed(2) : '—';
  };

  const formatCardNumber = (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 16);
    return digits.replace(/(.{4})/g, '$1 ').trim();
  };

  const formatExpiry = (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 4);
    if (digits.length <= 2) return digits;
    return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  };

  const handleCardChange = (field, value) => {
    if (field === 'card_number') {
      setCardForm({ ...cardForm, card_number: formatCardNumber(value) });
    } else if (field === 'expiry') {
      setCardForm({ ...cardForm, expiry: formatExpiry(value) });
    } else if (field === 'cvv') {
      setCardForm({ ...cardForm, cvv: value.replace(/\D/g, '').slice(0, 4) });
    } else {
      setCardForm({ ...cardForm, [field]: value });
    }
  };

  const handleCardPayment = async (e) => {
    e.preventDefault();
    if (cart.items.length === 0) {
      toast.error('Sepetiniz boş');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(
        `${API}/checkout/pay-card`,
        cardForm,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      await fetchCart();
      toast.success('Ödeme başarılı!');
      navigate(`/checkout/success?session_id=${response.data.session_id}`);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Ödeme işlemi başarısız');
    } finally {
      setLoading(false);
    }
  };

  const handleBankTransfer = async () => {
    if (cart.items.length === 0) {
      toast.error('Sepetiniz boş');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(
        `${API}/checkout/bank-transfer`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );
      await fetchCart();
      setBankInfo(response.data);
      toast.success('Sipariş oluşturuldu. Havale bilgilerini not alın.');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Sipariş oluşturulamadı');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text.replace(/\s/g, ''));
    toast.success('Kopyalandı');
  };

  if (cart.items.length === 0 && !bankInfo) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-[#1A4D2E] mb-4" style={{ fontFamily: 'Playfair Display' }}>
            Sepetiniz Boş
          </h2>
          <p className="text-[#4A6B5A] mb-6">Ödeme yapmak için sepetinize ürün ekleyin.</p>
          <Link to="/products" className="btn-primary">Alışverişe Başla</Link>
        </div>
      </div>
    );
  }

  if (bankInfo) {
    return (
      <div className="min-h-screen py-12 px-4" data-testid="bank-transfer-info">
        <div className="max-w-lg mx-auto card p-8">
          <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-[#1A4D2E] mb-2 text-center" style={{ fontFamily: 'Playfair Display' }}>
            Havale / EFT Talimatı
          </h2>
          <p className="text-[#4A6B5A] mb-6 text-center">
            Aşağıdaki hesaba <strong>{formatMoney(bankInfo.total)} ₺</strong> tutarında ödeme yapın.
          </p>
          <div className="space-y-4 bg-[#F9F7F2] rounded-lg p-4">
            <div>
              <p className="text-sm text-[#4A6B5A]">Banka</p>
              <p className="font-semibold text-[#1A4D2E]">{bankInfo.bank_name}</p>
            </div>
            <div>
              <p className="text-sm text-[#4A6B5A]">Hesap Sahibi</p>
              <p className="font-semibold text-[#1A4D2E]">{bankInfo.account_holder}</p>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[#4A6B5A]">IBAN</p>
                <p className="font-semibold text-[#1A4D2E]">{bankInfo.iban}</p>
              </div>
              <button
                type="button"
                onClick={() => copyToClipboard(bankInfo.iban)}
                className="p-2 text-[#FF6B00] hover:bg-orange-50 rounded"
              >
                <Copy className="h-5 w-5" />
              </button>
            </div>
            <div>
              <p className="text-sm text-[#4A6B5A]">Açıklama</p>
              <p className="font-semibold text-[#1A4D2E]">{bankInfo.description}</p>
            </div>
          </div>
          <p className="text-sm text-[#4A6B5A] mt-4 text-center">
            Ödemeniz onaylandıktan sonra siparişiniz hazırlanacaktır.
          </p>
          <button onClick={() => navigate('/orders')} className="w-full btn-primary mt-6">
            Siparişlerime Git
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12" data-testid="payment-page">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link
          to="/checkout"
          className="inline-flex items-center text-[#4A6B5A] hover:text-[#FF6B00] mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Sipariş özetine dön
        </Link>

        <h1 className="text-4xl font-bold text-[#1A4D2E] mb-8" style={{ fontFamily: 'Playfair Display' }}>
          Ödeme
        </h1>

        <div className="grid lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3">
            <div className="card p-6">
              <div className="flex gap-2 mb-6">
                <button
                  type="button"
                  onClick={() => setMethod('card')}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-semibold transition ${
                    method === 'card'
                      ? 'bg-[#FF6B00] text-white'
                      : 'bg-[#F9F7F2] text-[#1A4D2E] hover:bg-orange-50'
                  }`}
                >
                  <CreditCard className="h-5 w-5" />
                  Kredi / Banka Kartı
                </button>
                <button
                  type="button"
                  onClick={() => setMethod('bank')}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-semibold transition ${
                    method === 'bank'
                      ? 'bg-[#FF6B00] text-white'
                      : 'bg-[#F9F7F2] text-[#1A4D2E] hover:bg-orange-50'
                  }`}
                >
                  <Building2 className="h-5 w-5" />
                  Havale / EFT
                </button>
              </div>

              {method === 'card' ? (
                <form onSubmit={handleCardPayment} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-[#1A4D2E] mb-1">
                      Kart Üzerindeki İsim
                    </label>
                    <input
                      type="text"
                      required
                      value={cardForm.card_holder}
                      onChange={(e) => handleCardChange('card_holder', e.target.value)}
                      placeholder="Ad Soyad"
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00]"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#1A4D2E] mb-1">
                      Kart Numarası
                    </label>
                    <input
                      type="text"
                      required
                      inputMode="numeric"
                      value={cardForm.card_number}
                      onChange={(e) => handleCardChange('card_number', e.target.value)}
                      placeholder="0000 0000 0000 0000"
                      className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00] font-mono"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-[#1A4D2E] mb-1">
                        Son Kullanma
                      </label>
                      <input
                        type="text"
                        required
                        inputMode="numeric"
                        value={cardForm.expiry}
                        onChange={(e) => handleCardChange('expiry', e.target.value)}
                        placeholder="AA/YY"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00] font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-[#1A4D2E] mb-1">
                        CVV
                      </label>
                      <input
                        type="password"
                        required
                        inputMode="numeric"
                        value={cardForm.cvv}
                        onChange={(e) => handleCardChange('cvv', e.target.value)}
                        placeholder="•••"
                        className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00] font-mono"
                      />
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-[#4A6B5A] pt-2">
                    <Lock className="h-4 w-4" />
                    Ödeme bilgileriniz güvenli bağlantı ile işlenir.
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full btn-primary disabled:opacity-50 mt-4"
                    data-testid="pay-button"
                  >
                    {loading ? 'İşleniyor...' : `${formatMoney(getCartTotal())} ₺ Öde`}
                  </button>
                </form>
              ) : (
                <div className="space-y-4">
                  <p className="text-[#4A6B5A]">
                    Havale veya EFT ile ödeme yapabilirsiniz. Sipariş oluşturulduktan sonra
                    banka hesap bilgileri gösterilecektir.
                  </p>
                  <ul className="text-sm text-[#4A6B5A] space-y-2 list-disc list-inside">
                    <li>Ödeme onayı 1-2 iş günü içinde yapılır</li>
                    <li>Açıklama kısmına sipariş numaranızı yazın</li>
                    <li>Ödeme yapılmadan sipariş iptal edilebilir</li>
                  </ul>
                  <button
                    type="button"
                    onClick={handleBankTransfer}
                    disabled={loading}
                    className="w-full btn-primary disabled:opacity-50"
                    data-testid="bank-transfer-button"
                  >
                    {loading ? 'Oluşturuluyor...' : 'Havale ile Sipariş Oluştur'}
                  </button>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="card p-6 sticky top-24">
              <h2 className="text-xl font-bold text-[#1A4D2E] mb-4" style={{ fontFamily: 'Playfair Display' }}>
                Sipariş Özeti
              </h2>
              <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
                {cart.items.map((item) => (
                  <div key={item.product.id} className="flex justify-between text-sm">
                    <span className="text-[#4A6B5A]">
                      {item.product.name} × {item.quantity}
                    </span>
                    <span className="font-semibold text-[#1A4D2E]">
                      {formatMoney(Number(item.product.price) * item.quantity)} ₺
                    </span>
                  </div>
                ))}
              </div>
              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#4A6B5A]">Ara Toplam</span>
                  <span>{formatMoney(getCartTotal())} ₺</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#4A6B5A]">Kargo</span>
                  <span className="text-green-600">Ücretsiz</span>
                </div>
                <div className="flex justify-between text-lg font-bold pt-2">
                  <span className="text-[#1A4D2E]">Toplam</span>
                  <span className="text-[#FF6B00]">{formatMoney(getCartTotal())} ₺</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;
