import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'sonner';
import {
  Package, Users, ShoppingBag, TrendingUp, Plus, Pencil, Trash2, LogOut, Store, ClipboardList, Star, CheckCircle
} from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '../../components/ui/dialog';

const BACKEND_URL = (process.env.REACT_APP_BACKEND_URL || window.location.origin).replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;

const EMPTY_PRODUCT = {
  name: '',
  category: 'fruit',
  unit: 'kg',
  price: '',
  in_stock: true,
  stock_quantity: 0,
  image: '',
  description: '',
};

const AdminPanel = () => {
  const { token, logout, user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('products');
  const [stats, setStats] = useState(null);
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [users, setUsers] = useState([]);
  const [surveys, setSurveys] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [form, setForm] = useState(EMPTY_PRODUCT);
  const [saving, setSaving] = useState(false);
  const [approvingOrderId, setApprovingOrderId] = useState(null);

  const authHeaders = { Authorization: `Bearer ${token}` };

  const formatPrice = (value) => {
    const n = typeof value === 'string' ? Number(value) : value;
    return Number.isFinite(n) ? n.toFixed(2) : '—';
  };

  const formatDate = (value) => {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('tr-TR', {
      year: 'numeric', month: 'long', day: 'numeric',
    });
  };

  const formatDateTime = (value) => {
    if (!value) return '-';
    return new Date(value).toLocaleString('tr-TR', {
      year: 'numeric', month: 'long', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  };

  const getStatusLabel = (status) => {
    if (status === 'paid') return { text: 'Ödendi', cls: 'bg-green-100 text-green-800' };
    if (status === 'cancelled') return { text: 'İptal', cls: 'bg-red-100 text-red-800' };
    return { text: 'Bekliyor', cls: 'bg-yellow-100 text-yellow-800' };
  };

  const getPaymentMethodLabel = (method) => {
    if (method === 'bank_transfer') return 'Havale / EFT';
    if (method === 'card') return 'Kart';
    return method || '-';
  };

  const handleApproveOrder = async (orderId) => {
    if (!window.confirm('Bu siparişi onaylamak istediğinize emin misiniz? Ödeme alındı olarak işaretlenecek.')) return;
    setApprovingOrderId(orderId);
    try {
      const res = await axios.post(`${API}/admin/orders/${orderId}/approve`, {}, { headers: authHeaders });
      setOrders((prev) => prev.map((o) => (o.id === orderId ? res.data : o)));
      toast.success('Sipariş onaylandı');
      await loadStats();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Onaylama başarısız');
    } finally {
      setApprovingOrderId(null);
    }
  };

  const loadStats = useCallback(async () => {
    const res = await axios.get(`${API}/admin/stats`, { headers: authHeaders });
    setStats(res.data);
  }, [token]);

  const loadProducts = useCallback(async () => {
    const res = await axios.get(`${API}/admin/products`, { headers: authHeaders });
    setProducts(res.data);
  }, [token]);

  const loadOrders = useCallback(async () => {
    const res = await axios.get(`${API}/admin/orders`, { headers: authHeaders });
    setOrders(res.data);
  }, [token]);

  const loadUsers = useCallback(async () => {
    const res = await axios.get(`${API}/admin/users`, { headers: authHeaders });
    setUsers(res.data);
  }, [token]);

  const loadSurveys = useCallback(async () => {
    const res = await axios.get(`${API}/admin/surveys`, { headers: authHeaders });
    setSurveys(res.data);
  }, [token]);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      await Promise.all([loadStats(), loadProducts(), loadOrders(), loadUsers(), loadSurveys()]);
    } catch (error) {
      toast.error('Veriler yüklenemedi');
    } finally {
      setLoading(false);
    }
  }, [loadStats, loadProducts, loadOrders, loadUsers, loadSurveys]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const openAddModal = () => {
    setEditingProduct(null);
    setForm(EMPTY_PRODUCT);
    setModalOpen(true);
  };

  const openEditModal = (product) => {
    setEditingProduct(product);
    setForm({
      name: product.name,
      category: product.category,
      unit: product.unit,
      price: product.price,
      in_stock: product.in_stock,
      stock_quantity: product.stock_quantity ?? 0,
      image: product.image,
      description: product.description || '',
    });
    setModalOpen(true);
  };

  const handleSaveProduct = async (e) => {
    e.preventDefault();
    setSaving(true);
    const qty = parseInt(form.stock_quantity, 10) || 0;
    const payload = {
      id: editingProduct?.id || `p${Date.now()}`,
      name: form.name,
      category: form.category,
      unit: form.unit,
      price: parseFloat(form.price),
      stock_quantity: qty,
      in_stock: qty > 0,
      image: form.image,
      description: form.description,
    };

    try {
      if (editingProduct) {
        await axios.put(`${API}/admin/products/${editingProduct.id}`, payload, { headers: authHeaders });
        toast.success('Ürün güncellendi');
      } else {
        await axios.post(`${API}/admin/products`, payload, { headers: authHeaders });
        toast.success('Ürün eklendi');
      }
      setModalOpen(false);
      await Promise.all([loadProducts(), loadStats()]);
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Kayıt başarısız');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteProduct = async (productId) => {
    if (!window.confirm('Bu ürünü silmek istediğinize emin misiniz?')) return;
    try {
      await axios.delete(`${API}/admin/products/${productId}`, { headers: authHeaders });
      toast.success('Ürün silindi');
      await Promise.all([loadProducts(), loadStats()]);
    } catch (error) {
      toast.error('Silme başarısız');
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  const tabs = [
    { id: 'products', label: 'Ürünler', icon: Package },
    { id: 'orders', label: 'Siparişler', icon: ShoppingBag },
    { id: 'surveys', label: 'Memnuniyet Anketleri', icon: ClipboardList },
    { id: 'users', label: 'Kullanıcılar', icon: Users },
  ];

  const renderStars = (rating) => (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          size={14}
          className={star <= rating ? 'text-[#FF6B00] fill-[#FF6B00]' : 'text-gray-300'}
        />
      ))}
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F9F7F2]">
        <div className="text-2xl text-[#1A4D2E]">Yükleniyor...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9F7F2]">
      <header className="bg-[#1A4D2E] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: 'Playfair Display' }}>
              Taze Market Admin
            </h1>
            <p className="text-green-100 text-sm">Hoş geldin, {user?.name || user?.username}</p>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/" className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 transition">
              <Store size={18} />
              <span className="hidden sm:inline">Siteye Dön</span>
            </Link>
            <button onClick={handleLogout} className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#FF6B00] hover:bg-[#E65100] transition">
              <LogOut size={18} />
              <span className="hidden sm:inline">Çıkış</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {stats && (
          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
            {[
              { label: 'Toplam Ürün', value: stats.total_products, icon: Package, color: 'text-[#1A4D2E]' },
              { label: 'Kayıtlı Kullanıcı', value: stats.total_users, icon: Users, color: 'text-blue-600' },
              { label: 'Toplam Sipariş', value: stats.total_orders, icon: ShoppingBag, color: 'text-purple-600' },
              { label: 'Toplam Gelir', value: `${formatPrice(stats.total_revenue)} ₺`, icon: TrendingUp, color: 'text-[#FF6B00]' },
              { label: 'Anket Sayısı', value: stats.total_surveys ?? 0, icon: ClipboardList, color: 'text-teal-600' },
              { label: 'Ort. Memnuniyet', value: `${stats.avg_satisfaction ?? 0}/5`, icon: Star, color: 'text-yellow-600' },
            ].map((item) => (
              <div key={item.label} className="card p-5">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-[#4A6B5A]">{item.label}</span>
                  <item.icon size={20} className={item.color} />
                </div>
                <div className={`text-2xl font-bold ${item.color}`}>{item.value}</div>
              </div>
            ))}
          </div>
        )}

        <div className="flex flex-wrap gap-2 mb-6 border-b border-gray-200 pb-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-5 py-3 font-medium rounded-t-lg transition ${
                activeTab === tab.id
                  ? 'text-[#FF6B00] border-b-2 border-[#FF6B00] -mb-[1px]'
                  : 'text-[#4A6B5A] hover:text-[#1A4D2E]'
              }`}
            >
              <tab.icon size={18} />
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === 'products' && (
          <div>
            <div className="mb-4">
              <button onClick={openAddModal} className="btn-primary flex items-center gap-2 !px-6 !py-2">
                <Plus size={18} />
                Yeni Ürün Ekle
              </button>
            </div>
            <div className="card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="p-4 font-semibold text-[#1A4D2E]">Fotoğraf</th>
                      <th className="p-4 font-semibold text-[#1A4D2E]">Ürün</th>
                      <th className="p-4 font-semibold text-[#1A4D2E]">Kategori</th>
                      <th className="p-4 font-semibold text-[#1A4D2E]">Fiyat</th>
                      <th className="p-4 font-semibold text-[#1A4D2E]">Stok Adedi</th>
                      <th className="p-4 font-semibold text-[#1A4D2E]">Durum</th>
                      <th className="p-4 font-semibold text-[#1A4D2E]">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr key={product.id} className="border-b last:border-0 hover:bg-gray-50">
                        <td className="p-4">
                          <img src={product.image} alt={product.name} className="w-14 h-14 object-cover rounded-lg" />
                        </td>
                        <td className="p-4 font-medium">{product.name}</td>
                        <td className="p-4">{product.category === 'fruit' ? 'Meyve' : 'Sebze'}</td>
                        <td className="p-4 text-[#FF6B00] font-semibold">{formatPrice(product.price)} ₺ / {product.unit}</td>
                        <td className="p-4">
                          <span className="font-bold text-[#1A4D2E] text-lg">
                            {product.stock_quantity ?? 0}
                          </span>
                          <span className="text-sm text-[#4A6B5A] ml-1">{product.unit}</span>
                        </td>
                        <td className="p-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            (product.stock_quantity ?? 0) > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {(product.stock_quantity ?? 0) > 0 ? 'Stokta' : 'Tükendi'}
                          </span>
                        </td>
                        <td className="p-4">
                          <div className="flex gap-2">
                            <button onClick={() => openEditModal(product)} className="p-2 rounded-lg bg-blue-100 text-blue-700 hover:bg-blue-200">
                              <Pencil size={16} />
                            </button>
                            <button onClick={() => handleDeleteProduct(product.id)} className="p-2 rounded-lg bg-red-100 text-red-700 hover:bg-red-200">
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Sipariş No</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Müşteri</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Ürünler</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Tutar</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Ödeme</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Durum</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Tarih</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">İşlem</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.length === 0 ? (
                    <tr><td colSpan={8} className="p-8 text-center text-[#4A6B5A]">Henüz sipariş yok</td></tr>
                  ) : orders.map((order) => {
                    const status = getStatusLabel(order.status);
                    const isPending = order.status === 'pending';
                    return (
                      <tr key={order.id} className="border-b last:border-0 hover:bg-gray-50">
                        <td className="p-4 font-mono text-sm">#{order.id.substring(0, 8)}</td>
                        <td className="p-4">
                          <div className="font-medium">{order.customer_name}</div>
                          <div className="text-sm text-[#4A6B5A]">{order.customer_email}</div>
                        </td>
                        <td className="p-4 text-sm text-[#4A6B5A]">
                          {order.items?.map((item) => `${item.name} x${item.quantity}`).join(', ')}
                        </td>
                        <td className="p-4 font-semibold text-[#FF6B00]">{formatPrice(order.total)} ₺</td>
                        <td className="p-4 text-sm text-[#4A6B5A]">{getPaymentMethodLabel(order.payment_method)}</td>
                        <td className="p-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${status.cls}`}>{status.text}</span>
                        </td>
                        <td className="p-4 text-sm whitespace-nowrap">{formatDateTime(order.timestamp)}</td>
                        <td className="p-4">
                          {isPending ? (
                            <button
                              type="button"
                              onClick={() => handleApproveOrder(order.id)}
                              disabled={approvingOrderId === order.id}
                              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-600 text-white text-sm font-medium hover:bg-green-700 disabled:opacity-50"
                            >
                              <CheckCircle className="h-4 w-4" />
                              {approvingOrderId === order.id ? 'Onaylanıyor...' : 'Onayla'}
                            </button>
                          ) : (
                            <span className="text-sm text-[#4A6B5A]">—</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'surveys' && (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Müşteri</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Sipariş No</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Genel</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Teslimat</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Ürün Kalitesi</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Tavsiye</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Yorum</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Tarih</th>
                  </tr>
                </thead>
                <tbody>
                  {surveys.length === 0 ? (
                    <tr><td colSpan={8} className="p-8 text-center text-[#4A6B5A]">Henüz anket yok</td></tr>
                  ) : surveys.map((survey) => (
                    <tr key={survey.id} className="border-b last:border-0 hover:bg-gray-50">
                      <td className="p-4">
                        <div className="font-medium">{survey.customer_name}</div>
                        <div className="text-sm text-[#4A6B5A]">{survey.customer_email}</div>
                      </td>
                      <td className="p-4 font-mono text-sm">#{survey.order_id?.substring(0, 8)}</td>
                      <td className="p-4">{renderStars(survey.overall_rating)}</td>
                      <td className="p-4">{renderStars(survey.delivery_rating)}</td>
                      <td className="p-4">{renderStars(survey.product_quality_rating)}</td>
                      <td className="p-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          survey.would_recommend ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {survey.would_recommend ? 'Evet' : 'Hayır'}
                        </span>
                      </td>
                      <td className="p-4 text-sm text-[#4A6B5A] max-w-xs">
                        {survey.feedback || '-'}
                      </td>
                      <td className="p-4 text-sm whitespace-nowrap">{formatDate(survey.timestamp)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Ad Soyad</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">E-posta</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Kullanıcı Adı</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Rol</th>
                    <th className="p-4 font-semibold text-[#1A4D2E]">Kayıt Tarihi</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((u) => (
                    <tr key={u.id} className="border-b last:border-0 hover:bg-gray-50">
                      <td className="p-4 font-medium">{u.name || '-'}</td>
                      <td className="p-4">{u.email || '-'}</td>
                      <td className="p-4">{u.username || '-'}</td>
                      <td className="p-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${u.is_admin ? 'bg-[#1A4D2E] text-white' : 'bg-gray-100 text-gray-700'}`}>
                          {u.is_admin ? 'Admin' : 'Müşteri'}
                        </span>
                      </td>
                      <td className="p-4 text-sm">{formatDate(u.timestamp)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingProduct ? 'Ürünü Düzenle' : 'Yeni Ürün Ekle'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSaveProduct} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Ürün Adı</label>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00]" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Kategori</label>
                <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200">
                  <option value="fruit">Meyve</option>
                  <option value="vegetable">Sebze</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Birim</label>
                <input required value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })}
                  placeholder="kg, adet, paket"
                  className="w-full px-3 py-2 rounded-lg border border-gray-200" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Fiyat (₺)</label>
                <input required type="number" step="0.01" min="0" value={form.price}
                  onChange={(e) => setForm({ ...form, price: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Stok Adedi</label>
                <input
                  required
                  type="number"
                  min="0"
                  value={form.stock_quantity}
                  onChange={(e) => setForm({ ...form, stock_quantity: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200"
                />
              </div>
            </div>
            <div className="text-sm text-[#4A6B5A] px-1">
              Durum: {(parseInt(form.stock_quantity, 10) || 0) > 0 ? 'Stokta' : 'Tükendi'} (stok adedine göre otomatik belirlenir)
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Fotoğraf URL</label>
              <input required type="url" value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })}
                placeholder="https://..."
                className="w-full px-3 py-2 rounded-lg border border-gray-200" />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Açıklama</label>
              <textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-gray-200" />
            </div>
            <DialogFooter className="gap-2 sm:gap-0">
              <button type="button" onClick={() => setModalOpen(false)} className="btn-secondary !px-6 !py-2">İptal</button>
              <button type="submit" disabled={saving} className="btn-primary !px-6 !py-2 disabled:opacity-50">
                {saving ? 'Kaydediliyor...' : 'Kaydet'}
              </button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminPanel;
