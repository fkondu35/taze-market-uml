import React from 'react';
import InfoPageLayout from '../components/InfoPageLayout';
import { Target, Eye } from 'lucide-react';

const VisionMission = () => (
  <InfoPageLayout title="Vizyon & Misyon">
    <div className="space-y-8 not-prose">
      <div className="p-6 bg-[#F9F7F2] rounded-xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-[#1A4D2E] flex items-center justify-center">
            <Eye className="text-white" size={24} />
          </div>
          <h2 className="text-2xl font-bold text-[#1A4D2E]" style={{ fontFamily: 'Playfair Display' }}>
            Vizyonumuz
          </h2>
        </div>
        <p className="text-[#4A6B5A] leading-relaxed">
          Türkiye&apos;nin en güvenilir, erişilebilir ve sürdürülebilir online taze gıda platformu
          olmak. Her hanenin sofrasında taze ve sağlıklı ürünlere kolayca ulaşılmasını sağlamak;
          teknoloji ve genç girişimcilik ruhuyla gıda tedarik zincirini dönüştürmek.
        </p>
      </div>

      <div className="p-6 bg-[#F9F7F2] rounded-xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-full bg-[#FF6B00] flex items-center justify-center">
            <Target className="text-white" size={24} />
          </div>
          <h2 className="text-2xl font-bold text-[#1A4D2E]" style={{ fontFamily: 'Playfair Display' }}>
            Misyonumuz
          </h2>
        </div>
        <p className="text-[#4A6B5A] leading-relaxed">
          İki üniversite öğrencisi olarak, çiftçiden sofraya en taze meyve ve sebzeleri
          uygun fiyatla ulaştırmak. Müşteri memnuniyetini her şeyin üstünde tutmak;
          kaliteli ürün, hızlı teslimat ve şeffaf hizmet anlayışıyla güven inşa etmek.
        </p>
      </div>
    </div>
  </InfoPageLayout>
);

export default VisionMission;
