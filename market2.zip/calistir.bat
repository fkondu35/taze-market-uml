@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo  TAZE MARKET - BASLATILIYOR
echo ========================================
echo.

if not exist "build\index.html" (
  echo Build bulunamadi. Once ilk-kurulum.bat calistirin.
  pause
  exit /b 1
)

if not exist "backend\venv\Scripts\uvicorn.exe" (
  echo Backend hazir degil. Once ilk-kurulum.bat calistirin.
  pause
  exit /b 1
)

echo [1/3] MongoDB kontrol ediliyor...
sc query MongoDB | find "RUNNING" >nul
if errorlevel 1 (
  net start MongoDB >nul 2>&1
  if errorlevel 1 (
    echo HATA: MongoDB baslatilamadi. ilk-kurulum.bat ile kurulumu yapin.
    pause
    exit /b 1
  )
)

echo [2/3] Backend baslatiliyor (http://localhost:8001)...
start "Taze Market - Backend" cmd /k "cd /d "%~dp0backend" && venv\Scripts\uvicorn.exe server:app --host 127.0.0.1 --port 8001 --reload"

timeout /t 3 /nobreak >nul

echo [3/3] Frontend baslatiliyor (http://localhost:4173)...
start "Taze Market - Frontend" cmd /k "cd /d "%~dp0" && npx --yes serve -s build -l 4173"

timeout /t 2 /nobreak >nul
start http://localhost:4173

echo.
echo ========================================
echo  SITE ACILDI
echo ========================================
echo  Frontend : http://localhost:4173
echo  Backend  : http://localhost:8001/api
echo.
echo  Kapatmak icin acilan 2 siyah pencereyi kapatin.
echo ========================================
echo.
pause
