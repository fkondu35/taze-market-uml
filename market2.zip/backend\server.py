from fastapi import FastAPI, APIRouter, HTTPException, Depends, Header, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone, timedelta
import asyncio
import json
import jwt
import stripe
from passlib.context import CryptContext
from support_assistant import get_support_reply

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT and password hashing
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_DAYS = 30
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Stripe
STRIPE_API_KEY = os.environ.get('STRIPE_API_KEY')
STRIPE_WEBHOOK_SECRET = os.environ.get('STRIPE_WEBHOOK_SECRET', '')


class CheckoutSessionRequest(BaseModel):
    amount: float
    currency: str
    success_url: str
    cancel_url: str
    metadata: Dict[str, str] = Field(default_factory=dict)


class CheckoutSessionResponse(BaseModel):
    session_id: str
    url: str


class CheckoutStatusResponse(BaseModel):
    payment_status: str


class WebhookCheckoutResponse(BaseModel):
    event_type: str
    session_id: str
    payment_status: str


class StripeCheckout:
    def __init__(self, api_key: Optional[str], webhook_url: str):
        self.api_key = api_key
        self.webhook_url = webhook_url
        if self.api_key:
            stripe.api_key = self.api_key

    async def create_checkout_session(self, checkout_request: CheckoutSessionRequest) -> CheckoutSessionResponse:
        if not self.api_key:
            raise HTTPException(status_code=500, detail="Stripe API key is not configured")

        session = await asyncio.to_thread(
            stripe.checkout.Session.create,
            mode="payment",
            line_items=[
                {
                    "price_data": {
                        "currency": checkout_request.currency,
                        "product_data": {"name": "TazeMarket Siparişi"},
                        "unit_amount": int(round(checkout_request.amount * 100)),
                    },
                    "quantity": 1,
                }
            ],
            success_url=checkout_request.success_url,
            cancel_url=checkout_request.cancel_url,
            metadata=checkout_request.metadata,
        )
        return CheckoutSessionResponse(session_id=session.id, url=session.url)

    async def get_checkout_status(self, session_id: str) -> CheckoutStatusResponse:
        if not self.api_key:
            raise HTTPException(status_code=500, detail="Stripe API key is not configured")
        session = await asyncio.to_thread(stripe.checkout.Session.retrieve, session_id)
        payment_status = "paid" if getattr(session, "payment_status", "") == "paid" else "pending"
        return CheckoutStatusResponse(payment_status=payment_status)

    async def handle_webhook(self, body: bytes, signature: Optional[str]) -> WebhookCheckoutResponse:
        if self.api_key and STRIPE_WEBHOOK_SECRET and signature:
            event = await asyncio.to_thread(
                stripe.Webhook.construct_event,
                payload=body,
                sig_header=signature,
                secret=STRIPE_WEBHOOK_SECRET,
            )
            event_type = event.get("type", "")
            event_object = event.get("data", {}).get("object", {})
            return WebhookCheckoutResponse(
                event_type=event_type,
                session_id=event_object.get("id", ""),
                payment_status=event_object.get("payment_status", "pending"),
            )

        # Local/dev fallback: parse webhook payload without signature verification.
        payload = json.loads(body.decode("utf-8"))
        event_type = payload.get("type", "")
        event_object = payload.get("data", {}).get("object", {})
        return WebhookCheckoutResponse(
            event_type=event_type,
            session_id=event_object.get("id", ""),
            payment_status=event_object.get("payment_status", "pending"),
        )

app = FastAPI()
api_router = APIRouter(prefix="/api")

# Models
class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    email: EmailStr
    name: str
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Product(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    price: float
    unit: str
    image: str
    category: str  # "fruit" or "vegetable"
    description: Optional[str] = None
    in_stock: bool = True
    stock_quantity: int = Field(default=0, ge=0)

class CartItem(BaseModel):
    product_id: str
    quantity: int

class Cart(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    items: List[CartItem] = []
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Favorite(BaseModel):
    model_config = ConfigDict(extra="ignore")
    user_id: str
    product_id: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Order(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    items: List[Dict[str, Any]]
    total: float
    status: str  # "pending", "paid", "cancelled"
    payment_session_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PaymentTransaction(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    session_id: str
    user_id: Optional[str] = None
    amount: float
    currency: str
    payment_status: str  # "pending", "paid", "failed", "expired"
    metadata: Optional[Dict[str, str]] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SurveyCreate(BaseModel):
    order_id: str
    overall_rating: int = Field(ge=1, le=5)
    delivery_rating: int = Field(ge=1, le=5)
    product_quality_rating: int = Field(ge=1, le=5)
    would_recommend: bool
    feedback: Optional[str] = None

class ReviewCreate(BaseModel):
    rating: int = Field(ge=1, le=5)
    comment: str = Field(min_length=3, max_length=1000)
    product_id: Optional[str] = None

class SupportChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)
    history: List[Dict[str, str]] = Field(default_factory=list)

class CardPaymentRequest(BaseModel):
    card_holder: str = Field(min_length=3, max_length=100)
    card_number: str = Field(min_length=13, max_length=19)
    expiry: str = Field(min_length=4, max_length=7)
    cvv: str = Field(min_length=3, max_length=4)

# Helper functions
def create_access_token(user_id: str, email: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(days=JWT_EXPIRATION_DAYS)
    payload = {
        "user_id": user_id,
        "email": email,
        "exp": expire
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def get_current_user(authorization: Optional[str] = Header(None)) -> Optional[dict]:
    if not authorization or not authorization.startswith("Bearer "):
        return None
    token = authorization.replace("Bearer ", "")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def require_auth(authorization: Optional[str] = Header(None)) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    token = authorization.replace("Bearer ", "")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")

async def require_admin(authorization: Optional[str] = Header(None)) -> dict:
    user = await require_auth(authorization)
    # Check if user is admin
    user_doc = await db.users.find_one({"id": user['user_id']}, {"_id": 0})
    if not user_doc or not user_doc.get('is_admin', False):
        raise HTTPException(status_code=403, detail="Admin access required")
    return user

# Auth endpoints
@api_router.post("/auth/register")
async def register(user_data: UserCreate):
    # Check if user exists
    existing = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Hash password
    hashed_password = pwd_context.hash(user_data.password)
    
    # Create user
    user = User(email=user_data.email, name=user_data.name)
    user_dict = user.model_dump()
    user_dict['timestamp'] = user_dict['created_at'].isoformat()
    user_dict['password'] = hashed_password
    user_dict['is_admin'] = False  # Normal user
    del user_dict['created_at']
    
    await db.users.insert_one(user_dict)
    
    # Create token
    token = create_access_token(user.id, user.email)
    
    return {"user": user.model_dump(), "token": token}

@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    # Find user
    user_doc = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user_doc:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Verify password
    if not pwd_context.verify(credentials.password, user_doc['password']):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    # Create token
    token = create_access_token(user_doc['id'], user_doc['email'])
    
    # Return user without password
    user_data = {k: v for k, v in user_doc.items() if k != 'password'}
    
    return {"user": user_data, "token": token}

@api_router.post("/auth/admin-login")
async def admin_login(request: Request):
    # Get JSON body
    body = await request.json()
    username = body.get('username')
    password = body.get('password')
    
    # Find admin user
    admin_doc = await db.users.find_one({"username": username, "is_admin": True}, {"_id": 0})
    if not admin_doc:
        raise HTTPException(status_code=401, detail="Invalid admin credentials")
    
    # Verify password
    if not pwd_context.verify(password, admin_doc['password']):
        raise HTTPException(status_code=401, detail="Invalid admin credentials")
    
    # Create token
    token = create_access_token(admin_doc['id'], admin_doc.get('email', username))
    
    # Return admin without password
    admin_data = {k: v for k, v in admin_doc.items() if k != 'password'}
    
    return {"user": admin_data, "token": token}

@api_router.get("/auth/me")
async def get_me(current_user: dict = Depends(require_auth)):
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0, "password": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")
    return user_doc

# Product endpoints
@api_router.get("/products")
async def get_products(category: Optional[str] = None, search: Optional[str] = None):
    query = {}
    if category:
        query['category'] = category
    if search:
        query['name'] = {"$regex": search, "$options": "i"}
    
    products = await db.products.find(query, {"_id": 0}).to_list(1000)
    return products

@api_router.get("/products/{product_id}")
async def get_product(product_id: str):
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

# Cart endpoints
@api_router.get("/cart")
async def get_cart(current_user: dict = Depends(require_auth)):
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart:
        return {"user_id": current_user['user_id'], "items": []}
    
    # Populate product details
    cart_items = []
    for item in cart.get('items', []):
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            cart_items.append({
                "product": product,
                "quantity": item['quantity']
            })
    
    return {"user_id": cart['user_id'], "items": cart_items}

@api_router.post("/cart/add")
async def add_to_cart(item: CartItem, current_user: dict = Depends(require_auth)):
    # Check if product exists
    product = await db.products.find_one({"id": item.product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Get or create cart
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    
    if not cart:
        cart = {"user_id": current_user['user_id'], "items": []}
    
    # Check if item already in cart
    existing_item = None
    for i, cart_item in enumerate(cart['items']):
        if cart_item['product_id'] == item.product_id:
            existing_item = i
            break
    
    if existing_item is not None:
        cart['items'][existing_item]['quantity'] += item.quantity
    else:
        cart['items'].append({"product_id": item.product_id, "quantity": item.quantity})
    
    cart['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": cart},
        upsert=True
    )
    
    return {"message": "Item added to cart"}

@api_router.post("/cart/update")
async def update_cart_item(item: CartItem, current_user: dict = Depends(require_auth)):
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart:
        raise HTTPException(status_code=404, detail="Cart not found")
    
    # Find and update item
    for i, cart_item in enumerate(cart['items']):
        if cart_item['product_id'] == item.product_id:
            if item.quantity <= 0:
                cart['items'].pop(i)
            else:
                cart['items'][i]['quantity'] = item.quantity
            break
    
    cart['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": cart}
    )
    
    return {"message": "Cart updated"}

@api_router.delete("/cart/clear")
async def clear_cart(current_user: dict = Depends(require_auth)):
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": {"items": [], "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    return {"message": "Cart cleared"}

# Favorites endpoints
@api_router.get("/favorites")
async def get_favorites(current_user: dict = Depends(require_auth)):
    favorites = await db.favorites.find({"user_id": current_user['user_id']}, {"_id": 0}).to_list(1000)
    
    # Populate product details
    favorite_products = []
    for fav in favorites:
        product = await db.products.find_one({"id": fav['product_id']}, {"_id": 0})
        if product:
            favorite_products.append(product)
    
    return favorite_products

@api_router.post("/favorites/{product_id}")
async def add_favorite(product_id: str, current_user: dict = Depends(require_auth)):
    # Check if product exists
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Check if already favorited
    existing = await db.favorites.find_one({"user_id": current_user['user_id'], "product_id": product_id})
    if existing:
        return {"message": "Already in favorites"}
    
    favorite = Favorite(user_id=current_user['user_id'], product_id=product_id)
    fav_dict = favorite.model_dump()
    fav_dict['timestamp'] = fav_dict['created_at'].isoformat()
    del fav_dict['created_at']
    
    await db.favorites.insert_one(fav_dict)
    return {"message": "Added to favorites"}

@api_router.delete("/favorites/{product_id}")
async def remove_favorite(product_id: str, current_user: dict = Depends(require_auth)):
    await db.favorites.delete_one({"user_id": current_user['user_id'], "product_id": product_id})
    return {"message": "Removed from favorites"}

# Payment endpoints
@api_router.post("/checkout/bank-transfer")
async def create_bank_transfer_order(current_user: dict = Depends(require_auth)):
    # Get cart
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart or not cart.get('items'):
        raise HTTPException(status_code=400, detail="Cart is empty")
    
    # Calculate total
    total = 0.0
    items = []
    for item in cart['items']:
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({
                "product_id": product['id'],
                "name": product['name'],
                "price": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })
    
    # Create order with bank transfer
    order = Order(
        user_id=current_user['user_id'],
        items=items,
        total=total,
        status="pending",
        payment_session_id="BANK_TRANSFER"
    )
    order_dict = order.model_dump()
    order_dict['timestamp'] = order_dict['created_at'].isoformat()
    order_dict['payment_method'] = 'bank_transfer'
    del order_dict['created_at']
    
    await db.orders.insert_one(order_dict)
    
    # Create payment transaction
    payment = PaymentTransaction(
        session_id=f"BANK_{order.id}",
        user_id=current_user['user_id'],
        amount=total,
        currency="TRY",
        payment_status="pending",
        metadata={"order_id": order.id, "payment_method": "bank_transfer"}
    )
    payment_dict = payment.model_dump()
    payment_dict['timestamp'] = payment_dict['created_at'].isoformat()
    payment_dict['updated_timestamp'] = payment_dict['updated_at'].isoformat()
    del payment_dict['created_at']
    del payment_dict['updated_at']
    
    await db.payment_transactions.insert_one(payment_dict)
    
    # Clear cart
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": {"items": []}}
    )
    
    return {
        "order_id": order.id,
        "total": total,
        "iban": "TR91 0001 0090 1008 0885 5050 02",
        "account_holder": "Muhammet Ali Aslan",
        "bank_name": "Ziraat Bankası",
        "description": f"Sipariş No: {order.id[:8]}"
    }

@api_router.post("/checkout/pay-card")
async def pay_with_card(body: CardPaymentRequest, current_user: dict = Depends(require_auth)):
    card_digits = "".join(c for c in body.card_number if c.isdigit())
    if len(card_digits) < 13 or len(card_digits) > 19:
        raise HTTPException(status_code=400, detail="Geçersiz kart numarası")
    if not body.cvv.isdigit() or len(body.cvv) not in (3, 4):
        raise HTTPException(status_code=400, detail="Geçersiz CVV")
    expiry_clean = body.expiry.replace(" ", "")
    if "/" in expiry_clean:
        parts = expiry_clean.split("/")
    elif len(expiry_clean) == 4:
        parts = [expiry_clean[:2], expiry_clean[2:]]
    else:
        raise HTTPException(status_code=400, detail="Geçersiz son kullanma tarihi")
    if len(parts) != 2 or not parts[0].isdigit() or not parts[1].isdigit():
        raise HTTPException(status_code=400, detail="Geçersiz son kullanma tarihi")
    month, year = int(parts[0]), int(parts[1])
    if month < 1 or month > 12:
        raise HTTPException(status_code=400, detail="Geçersiz son kullanma tarihi")

    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart or not cart.get('items'):
        raise HTTPException(status_code=400, detail="Cart is empty")

    total = 0.0
    items = []
    for item in cart['items']:
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({
                "product_id": product['id'],
                "name": product['name'],
                "price": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })

    session_id = f"CARD_{uuid.uuid4()}"
    order = Order(
        user_id=current_user['user_id'],
        items=items,
        total=total,
        status="paid",
        payment_session_id=session_id
    )
    order_dict = order.model_dump()
    order_dict['timestamp'] = order_dict['created_at'].isoformat()
    order_dict['payment_method'] = 'card'
    del order_dict['created_at']

    await db.orders.insert_one(order_dict)

    payment = PaymentTransaction(
        session_id=session_id,
        user_id=current_user['user_id'],
        amount=total,
        currency="TRY",
        payment_status="paid",
        metadata={"order_id": order.id, "payment_method": "card", "card_last4": card_digits[-4:]}
    )
    payment_dict = payment.model_dump()
    payment_dict['timestamp'] = payment_dict['created_at'].isoformat()
    payment_dict['updated_timestamp'] = payment_dict['updated_at'].isoformat()
    del payment_dict['created_at']
    del payment_dict['updated_at']

    await db.payment_transactions.insert_one(payment_dict)

    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": {"items": []}}
    )

    return {"order_id": order.id, "session_id": session_id, "payment_status": "paid"}

@api_router.post("/checkout/create")
async def create_checkout(request: Request, origin_url: str, current_user: dict = Depends(require_auth)):
    # Get cart
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart or not cart.get('items'):
        raise HTTPException(status_code=400, detail="Cart is empty")
    
    # Calculate total
    total = 0.0
    items = []
    for item in cart['items']:
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({
                "product_id": product['id'],
                "name": product['name'],
                "price": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })
    
    # Create order
    order = Order(
        user_id=current_user['user_id'],
        items=items,
        total=total,
        status="pending"
    )
    order_dict = order.model_dump()
    order_dict['timestamp'] = order_dict['created_at'].isoformat()
    del order_dict['created_at']
    
    await db.orders.insert_one(order_dict)
    
    # Create Stripe checkout session
    host_url = origin_url
    webhook_url = f"{host_url}/api/webhook/stripe"
    stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=webhook_url)
    
    success_url = f"{origin_url}/checkout/success?session_id={{{{CHECKOUT_SESSION_ID}}}}"
    cancel_url = f"{origin_url}/cart"
    
    checkout_request = CheckoutSessionRequest(
        amount=total,
        currency="usd",
        success_url=success_url,
        cancel_url=cancel_url,
        metadata={
            "user_id": current_user['user_id'],
            "order_id": order.id
        }
    )
    
    session = await stripe_checkout.create_checkout_session(checkout_request)
    
    # Create payment transaction
    payment = PaymentTransaction(
        session_id=session.session_id,
        user_id=current_user['user_id'],
        amount=total,
        currency="usd",
        payment_status="pending",
        metadata={"order_id": order.id}
    )
    payment_dict = payment.model_dump()
    payment_dict['timestamp'] = payment_dict['created_at'].isoformat()
    payment_dict['updated_timestamp'] = payment_dict['updated_at'].isoformat()
    del payment_dict['created_at']
    del payment_dict['updated_at']
    
    await db.payment_transactions.insert_one(payment_dict)
    
    # Update order with session_id
    await db.orders.update_one(
        {"id": order.id},
        {"$set": {"payment_session_id": session.session_id}}
    )
    
    return {"url": session.url, "session_id": session.session_id}

@api_router.get("/checkout/status/{session_id}")
async def get_checkout_status(session_id: str, current_user: dict = Depends(require_auth)):
    # Check if already processed
    payment = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    
    # If already paid, return immediately
    if payment['payment_status'] == 'paid':
        return payment

    # Local card/bank sessions — Stripe kullanılmaz
    if session_id.startswith("CARD_") or session_id.startswith("BANK_"):
        return payment
    
    # Check with Stripe
    webhook_url = "http://localhost/api/webhook/stripe"
    stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=webhook_url)
    
    status: CheckoutStatusResponse = await stripe_checkout.get_checkout_status(session_id)
    
    # Update payment transaction
    if status.payment_status == 'paid' and payment['payment_status'] != 'paid':
        await db.payment_transactions.update_one(
            {"session_id": session_id},
            {"$set": {
                "payment_status": "paid",
                "updated_timestamp": datetime.now(timezone.utc).isoformat()
            }}
        )
        
        # Update order status
        order_id = payment['metadata'].get('order_id')
        if order_id:
            await db.orders.update_one(
                {"id": order_id},
                {"$set": {"status": "paid"}}
            )
        
        # Clear cart
        await db.carts.update_one(
            {"user_id": payment['user_id']},
            {"$set": {"items": []}}
        )
    
    # Get updated payment
    updated_payment = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
    return updated_payment

@api_router.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    body = await request.body()
    signature = request.headers.get("Stripe-Signature")
    
    host_url = str(request.base_url).rstrip('/')
    webhook_url = f"{host_url}/api/webhook/stripe"
    stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=webhook_url)
    
    try:
        webhook_response = await stripe_checkout.handle_webhook(body, signature)
        
        if webhook_response.event_type == "checkout.session.completed":
            # Update payment status
            await db.payment_transactions.update_one(
                {"session_id": webhook_response.session_id},
                {"$set": {
                    "payment_status": webhook_response.payment_status,
                    "updated_timestamp": datetime.now(timezone.utc).isoformat()
                }}
            )
        
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Orders endpoints
@api_router.get("/orders")
async def get_orders(current_user: dict = Depends(require_auth)):
    orders = await db.orders.find({"user_id": current_user['user_id']}, {"_id": 0}).to_list(1000)
    return orders

@api_router.get("/orders/{order_id}")
async def get_order(order_id: str, current_user: dict = Depends(require_auth)):
    order = await db.orders.find_one({"id": order_id, "user_id": current_user['user_id']}, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    return order

# Survey endpoints
@api_router.post("/surveys")
async def create_survey(survey: SurveyCreate, current_user: dict = Depends(require_auth)):
    order = await db.orders.find_one(
        {"id": survey.order_id, "user_id": current_user['user_id']},
        {"_id": 0}
    )
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    existing = await db.surveys.find_one({"order_id": survey.order_id}, {"_id": 0})
    if existing:
        raise HTTPException(status_code=400, detail="Survey already submitted for this order")

    survey_doc = {
        "id": str(uuid.uuid4()),
        "order_id": survey.order_id,
        "user_id": current_user['user_id'],
        "overall_rating": survey.overall_rating,
        "delivery_rating": survey.delivery_rating,
        "product_quality_rating": survey.product_quality_rating,
        "would_recommend": survey.would_recommend,
        "feedback": survey.feedback or "",
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    await db.surveys.insert_one(survey_doc)
    survey_doc.pop("_id", None)
    return {"message": "Survey submitted", "survey": survey_doc}

@api_router.get("/surveys/order/{order_id}")
async def get_order_survey(order_id: str, current_user: dict = Depends(require_auth)):
    order = await db.orders.find_one(
        {"id": order_id, "user_id": current_user['user_id']},
        {"_id": 0}
    )
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    survey = await db.surveys.find_one({"order_id": order_id}, {"_id": 0})
    return {"submitted": survey is not None, "survey": survey}

# Review endpoints
@api_router.get("/reviews")
async def get_reviews(limit: int = 50):
    reviews = await db.reviews.find({}, {"_id": 0}).to_list(limit)
    reviews.sort(key=lambda r: r.get("timestamp", ""), reverse=True)

    enriched = []
    for review in reviews:
        product_name = None
        if review.get("product_id"):
            product = await db.products.find_one({"id": review["product_id"]}, {"_id": 0, "name": 1})
            product_name = product.get("name") if product else None
        enriched.append({**review, "product_name": product_name})

    avg_rating = 0
    if enriched:
        avg_rating = round(sum(r.get("rating", 0) for r in enriched) / len(enriched), 1)

    return {"reviews": enriched, "average_rating": avg_rating, "total": len(enriched)}

@api_router.post("/reviews")
async def create_review(review: ReviewCreate, current_user: dict = Depends(require_auth)):
    user_doc = await db.users.find_one({"id": current_user['user_id']}, {"_id": 0, "password": 0})
    if not user_doc:
        raise HTTPException(status_code=404, detail="User not found")

    if review.product_id:
        product = await db.products.find_one({"id": review.product_id}, {"_id": 0})
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")

    review_doc = {
        "id": str(uuid.uuid4()),
        "user_id": current_user['user_id'],
        "user_name": user_doc.get("name", "Anonim"),
        "rating": review.rating,
        "comment": review.comment.strip(),
        "product_id": review.product_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    await db.reviews.insert_one(review_doc)
    review_doc.pop("_id", None)
    return {"message": "Review created", "review": review_doc}

# Support chat
@api_router.post("/support/chat")
async def support_chat(body: SupportChatRequest):
    reply = await get_support_reply(body.message, body.history, db)
    return {"reply": reply}

# ADMIN ENDPOINTS
@api_router.get("/admin/products")
async def admin_get_products(current_user: dict = Depends(require_admin)):
    """Admin: Get all products"""
    products = await db.products.find({}, {"_id": 0}).to_list(1000)
    return products

@api_router.post("/admin/products")
async def admin_create_product(product: Product, current_user: dict = Depends(require_admin)):
    """Admin: Create new product"""
    product_dict = product.model_dump()
    await db.products.insert_one(product_dict)
    # Remove MongoDB _id before returning
    product_dict.pop('_id', None)
    return {"message": "Product created", "product": product_dict}

@api_router.put("/admin/products/{product_id}")
async def admin_update_product(product_id: str, product: Product, current_user: dict = Depends(require_admin)):
    """Admin: Update product"""
    product_dict = product.model_dump()
    result = await db.products.update_one(
        {"id": product_id},
        {"$set": product_dict}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"message": "Product updated", "product": product_dict}

@api_router.delete("/admin/products/{product_id}")
async def admin_delete_product(product_id: str, current_user: dict = Depends(require_admin)):
    """Admin: Delete product"""
    result = await db.products.delete_one({"id": product_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"message": "Product deleted"}

@api_router.get("/admin/stats")
async def admin_get_stats(current_user: dict = Depends(require_admin)):
    """Admin: Get statistics"""
    total_products = await db.products.count_documents({})
    total_users = await db.users.count_documents({"is_admin": {"$ne": True}})
    total_orders = await db.orders.count_documents({})
    total_surveys = await db.surveys.count_documents({})
    
    # Revenue
    orders = await db.orders.find({"status": "paid"}, {"_id": 0}).to_list(1000)
    total_revenue = sum(order.get('total', 0) for order in orders)

    surveys = await db.surveys.find({}, {"_id": 0}).to_list(1000)
    avg_satisfaction = 0
    if surveys:
        avg_satisfaction = round(
            sum(s.get("overall_rating", 0) for s in surveys) / len(surveys), 1
        )
    
    return {
        "total_products": total_products,
        "total_users": total_users,
        "total_orders": total_orders,
        "total_revenue": total_revenue,
        "total_surveys": total_surveys,
        "avg_satisfaction": avg_satisfaction,
    }

@api_router.get("/admin/orders")
async def admin_get_orders(current_user: dict = Depends(require_admin)):
    """Admin: Get all orders with customer info"""
    orders = await db.orders.find({}, {"_id": 0}).to_list(1000)
    user_ids = list({order.get("user_id") for order in orders if order.get("user_id")})
    users = await db.users.find({"id": {"$in": user_ids}}, {"_id": 0, "password": 0}).to_list(1000)
    users_by_id = {user["id"]: user for user in users}

    enriched = []
    for order in orders:
        user = users_by_id.get(order.get("user_id"), {})
        enriched.append({
            **order,
            "customer_name": user.get("name", "Bilinmiyor"),
            "customer_email": user.get("email", "-"),
        })

    enriched.sort(key=lambda o: o.get("timestamp", ""), reverse=True)
    return enriched

@api_router.post("/admin/orders/{order_id}/approve")
async def admin_approve_order(order_id: str, current_user: dict = Depends(require_admin)):
    """Admin: Bekleyen siparişi onayla (ödendi olarak işaretle)"""
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(status_code=404, detail="Sipariş bulunamadı")
    if order.get("status") != "pending":
        raise HTTPException(status_code=400, detail="Sadece bekleyen siparişler onaylanabilir")

    now = datetime.now(timezone.utc).isoformat()
    await db.orders.update_one(
        {"id": order_id},
        {"$set": {"status": "paid", "approved_at": now}}
    )

    await db.payment_transactions.update_many(
        {"metadata.order_id": order_id},
        {"$set": {"payment_status": "paid", "updated_timestamp": now}}
    )
    await db.payment_transactions.update_one(
        {"session_id": f"BANK_{order_id}"},
        {"$set": {"payment_status": "paid", "updated_timestamp": now}}
    )

    updated = await db.orders.find_one({"id": order_id}, {"_id": 0})
    user = await db.users.find_one({"id": updated.get("user_id")}, {"_id": 0, "password": 0})
    return {
        **updated,
        "customer_name": user.get("name", "Bilinmiyor") if user else "Bilinmiyor",
        "customer_email": user.get("email", "-") if user else "-",
    }

@api_router.get("/admin/users")
async def admin_get_users(current_user: dict = Depends(require_admin)):
    """Admin: Get all registered users"""
    users = await db.users.find({}, {"_id": 0, "password": 0}).to_list(1000)
    users.sort(key=lambda u: u.get("timestamp", ""), reverse=True)
    return users

@api_router.get("/admin/surveys")
async def admin_get_surveys(current_user: dict = Depends(require_admin)):
    """Admin: Get all satisfaction surveys with customer info"""
    surveys = await db.surveys.find({}, {"_id": 0}).to_list(1000)
    user_ids = list({s.get("user_id") for s in surveys if s.get("user_id")})
    users = await db.users.find({"id": {"$in": user_ids}}, {"_id": 0, "password": 0}).to_list(1000)
    users_by_id = {user["id"]: user for user in users}

    enriched = []
    for survey in surveys:
        user = users_by_id.get(survey.get("user_id"), {})
        enriched.append({
            **survey,
            "customer_name": user.get("name", "Bilinmiyor"),
            "customer_email": user.get("email", "-"),
        })

    enriched.sort(key=lambda s: s.get("timestamp", ""), reverse=True)
    return enriched

app.include_router(api_router)

raw_origins = os.environ.get(
    'CORS_ORIGINS',
    'https://tazemarket.it.com,http://localhost:3000,http://127.0.0.1:3000'
)
allowed_origins = [origin.strip() for origin in raw_origins.split(',') if origin.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=allowed_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
