import React from 'react';
import InfoPageLayout from '../components/InfoPageLayout';

const Kvkk = () => (
  <InfoPageLayout
    title="KVKK Aydınlatma Metni"
    subtitle="6698 Sayılı Kişisel Verilerin Korunması Kanunu kapsamında"
  >
    <h2 className="text-xl font-bold text-[#1A4D2E]">1. Veri Sorumlusu</h2>
    <p>
      Taze Market olarak, 6698 sayılı Kişisel Verilerin Korunması Kanunu (&quot;KVKK&quot;) kapsamında
      veri sorumlusu sıfatıyla kişisel verilerinizi aşağıda açıklanan çerçevede işlemekteyiz.
    </p>
    <ul className="list-none space-y-1 not-prose text-[#4A6B5A]">
      <li><strong>Unvan:</strong> Taze Market</li>
      <li><strong>E-posta:</strong> aliaslann277@gmail.com</li>
      <li><strong>Web sitesi:</strong> Taze Market Online Platform</li>
    </ul>

    <h2 className="text-xl font-bold text-[#1A4D2E]">2. İşlenen Kişisel Veriler</h2>
    <ul className="list-disc pl-6 space-y-1">
      <li>Kimlik bilgileri (ad, soyad)</li>
      <li>İletişim bilgileri (e-posta adresi)</li>
      <li>Müşteri işlem bilgileri (sipariş geçmişi, sepet, favoriler)</li>
      <li>İşlem güvenliği bilgileri (IP adresi, oturum kayıtları)</li>
      <li>Ödeme işlem bilgileri (ödeme durumu — kart bilgileri tarafımızca saklanmaz)</li>
      <li>Müşteri memnuniyet anketi ve yorum verileri</li>
    </ul>

    <h2 className="text-xl font-bold text-[#1A4D2E]">3. Kişisel Verilerin İşlenme Amaçları</h2>
    <ul className="list-disc pl-6 space-y-1">
      <li>Üyelik ve hesap yönetimi</li>
      <li>Sipariş ve teslimat süreçlerinin yürütülmesi</li>
      <li>Ödeme işlemlerinin gerçekleştirilmesi</li>
      <li>Müşteri destek hizmetlerinin sunulması</li>
      <li>Yasal yükümlülüklerin yerine getirilmesi</li>
      <li>Hizmet kalitesinin artırılması ve müşteri memnuniyetinin ölçülmesi</li>
    </ul>

    <h2 className="text-xl font-bold text-[#1A4D2E]">4. Kişisel Verilerin Aktarılması</h2>
    <p>
      Kişisel verileriniz; ödeme altyapı sağlayıcıları (Stripe), barındırma hizmeti sağlayıcıları
      ve yasal zorunluluk halinde yetkili kamu kurumları ile KVKK&apos;nın 8. ve 9. maddelerine
      uygun olarak paylaşılabilir.
    </p>

    <h2 className="text-xl font-bold text-[#1A4D2E]">5. Kişisel Veri Toplamanın Yöntemi ve Hukuki Sebebi</h2>
    <p>
      Kişisel verileriniz; web sitemiz, mobil uygulama, e-posta ve destek kanalları aracılığıyla
      elektronik ortamda toplanmaktadır. Hukuki sebepler: sözleşmenin kurulması ve ifası,
      hukuki yükümlülük, meşru menfaat ve açık rızanızdır.
    </p>

    <h2 className="text-xl font-bold text-[#1A4D2E]">6. KVKK Kapsamındaki Haklarınız (Madde 11)</h2>
    <p>KVKK&apos;nın 11. maddesi uyarınca aşağıdaki haklara sahipsiniz:</p>
    <ul className="list-disc pl-6 space-y-1">
      <li>Kişisel verilerinizin işlenip işlenmediğini öğrenme</li>
      <li>İşlenmişse buna ilişkin bilgi talep etme</li>
      <li>İşlenme amacını ve amaca uygun kullanılıp kullanılmadığını öğrenme</li>
      <li>Yurt içinde veya yurt dışında aktarıldığı üçüncü kişileri bilme</li>
      <li>Eksik veya yanlış işlenmişse düzeltilmesini isteme</li>
      <li>KVKK&apos;nın 7. maddesi çerçevesinde silinmesini veya yok edilmesini isteme</li>
      <li>Otomatik sistemler ile analiz edilmesi suretiyle aleyhinize bir sonucun ortaya çıkmasına itiraz etme</li>
      <li>Kanuna aykırı işlenmesi sebebiyle zarara uğramanız hâlinde zararın giderilmesini talep etme</li>
    </ul>

    <h2 className="text-xl font-bold text-[#1A4D2E]">7. Başvuru</h2>
    <p>
      Haklarınıza ilişkin taleplerinizi <strong>aliaslann277@gmail.com</strong> adresine
      iletebilirsiniz. Başvurularınız en geç 30 gün içinde sonuçlandırılır.
    </p>

    <p className="text-sm text-[#4A6B5A] pt-4">
      Son güncelleme: Haziran 2024
    </p>
  </InfoPageLayout>
);

export default Kvkk;
