import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'sonner';
import StarRating from './StarRating';

const BACKEND_URL = (process.env.REACT_APP_BACKEND_URL || window.location.origin).replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;

const SatisfactionSurvey = ({ orderId, token, onComplete, onSkip }) => {
  const [form, setForm] = useState({
    overall_rating: 0,
    delivery_rating: 0,
    product_quality_rating: 0,
    would_recommend: null,
    feedback: '',
  });
  const [loading, setLoading] = useState(false);

  const canSubmit =
    form.overall_rating > 0 &&
    form.delivery_rating > 0 &&
    form.product_quality_rating > 0 &&
    form.would_recommend !== null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!canSubmit) {
      toast.error('Lütfen tüm soruları cevaplayın');
      return;
    }

    setLoading(true);
    try {
      await axios.post(
        `${API}/surveys`,
        { order_id: orderId, ...form },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Anketiniz için teşekkürler!');
      onComplete?.();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Anket gönderilemedi');
    } finally {
      setLoading(false);
    }
  };

  const RatingQuestion = ({ label, field }) => (
    <div className="mb-6">
      <p className="font-medium text-[#1A4D2E] mb-2">{label}</p>
      <StarRating
        value={form[field]}
        onChange={(val) => setForm({ ...form, [field]: val })}
      />
    </div>
  );

  return (
    <div className="card p-8 max-w-xl mx-auto">
      <h2 className="text-2xl font-bold text-[#1A4D2E] mb-2" style={{ fontFamily: 'Playfair Display' }}>
        Memnuniyet Anketi
      </h2>
      <p className="text-[#4A6B5A] mb-6">
        Alışveriş deneyiminizi değerlendirin — birkaç saniyenizi ayırmanız yeterli.
      </p>

      <form onSubmit={handleSubmit}>
        <RatingQuestion label="Genel memnuniyetiniz?" field="overall_rating" />
        <RatingQuestion label="Teslimat hızından memnun musunuz?" field="delivery_rating" />
        <RatingQuestion label="Ürün kalitesini nasıl buldunuz?" field="product_quality_rating" />

        <div className="mb-6">
          <p className="font-medium text-[#1A4D2E] mb-3">Bizi arkadaşlarınıza tavsiye eder misiniz?</p>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => setForm({ ...form, would_recommend: true })}
              className={`px-6 py-2 rounded-full font-medium transition ${
                form.would_recommend === true
                  ? 'bg-[#1A4D2E] text-white'
                  : 'bg-gray-100 text-[#4A6B5A] hover:bg-gray-200'
              }`}
            >
              Evet
            </button>
            <button
              type="button"
              onClick={() => setForm({ ...form, would_recommend: false })}
              className={`px-6 py-2 rounded-full font-medium transition ${
                form.would_recommend === false
                  ? 'bg-[#1A4D2E] text-white'
                  : 'bg-gray-100 text-[#4A6B5A] hover:bg-gray-200'
              }`}
            >
              Hayır
            </button>
          </div>
        </div>

        <div className="mb-6">
          <label className="block font-medium text-[#1A4D2E] mb-2">
            Ek yorumunuz (isteğe bağlı)
          </label>
          <textarea
            rows={3}
            value={form.feedback}
            onChange={(e) => setForm({ ...form, feedback: e.target.value })}
            placeholder="Deneyiminizi kısaca anlatın..."
            className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00]"
          />
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="submit"
            disabled={loading || !canSubmit}
            className="flex-1 btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Gönderiliyor...' : 'Anketi Gönder'}
          </button>
          {onSkip && (
            <button type="button" onClick={onSkip} className="flex-1 btn-secondary">
              Şimdilik Atla
            </button>
          )}
        </div>
      </form>
    </div>
  );
};

export default SatisfactionSurvey;
