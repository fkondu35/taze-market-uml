# 🍎 TAZE MARKET - SUNUM KODLARI

## 📋 Proje Özeti

Meyve ve sebze satışı için geliştirilmiş tam özellikli e-ticaret sitesi.
- **Dil:** Türkçe
- **Frontend:** Vanilla HTML/CSS/JavaScript (Framework yok!)
- **Backend:** Python FastAPI
- **Veritabanı:** MongoDB
- **Ödeme:** Stripe + Banka Havalesi

---

## 🎨 1. FRONTEND KODLARI

### 1.1. Ana Sayfa (index.html)

**Özellikler:**
- Hero section (Ana başlık alanı)
- Kategori kartları (Meyveler & Sebzeler)
- Öne çıkan 6 rastgele ürün
- GitHub reklam banner'ı
- Responsive tasarım

**Önemli Kod Parçaları:**

```html
<!-- Hero Section - Dikkat Çeken Ana Bölüm -->
<section class="hero">
  <div class="container">
    <h1>En Taze Meyve ve Sebzeler</h1>
    <p>Doğrudan çiftçiden sofraya! Organik ve taze ürünler</p>
    <div class="buttons">
      <a href="products.html?category=fruit" class="btn-primary">Meyveleri Keşfet</a>
      <a href="products.html?category=vegetable" class="btn-secondary">Sebzeleri Keşfet</a>
    </div>
  </div>
</section>
```

```javascript
// Ürünleri Backend'den Çekme
async function loadFeaturedProducts() {
  const products = await apiCall('/products');
  const shuffled = products.sort(() => 0.5 - Math.random());
  const featured = shuffled.slice(0, 6);
  // Ürünleri ekranda göster
}
```

---

### 1.2. Ürünler Sayfası (products.html)

**Özellikler:**
- Kategori filtresi (Meyve/Sebze)
- Arama fonksiyonu
- Favorilere ekleme
- Sepete ekleme

**Önemli Kod:**

```javascript
// URL Parametrelerini Okuma
const urlParams = new URLSearchParams(window.location.search);
const category = urlParams.get('category'); // fruit veya vegetable
const search = urlParams.get('search'); // arama terimi

// Ürünleri Filtreleme
let url = '/products';
if (category) url += `?category=${category}`;
if (search) url += `?search=${search}`;

const products = await apiCall(url);
```

```javascript
// Sepete Ekleme Fonksiyonu
async function addToCart(productId) {
  if (!isLoggedIn()) {
    showToast('Lütfen önce giriş yapın', 'error');
    return;
  }
  
  await apiCall('/cart/add', {
    method: 'POST',
    body: JSON.stringify({ 
      product_id: productId, 
      quantity: 1 
    })
  });
  showToast('Ürün sepete eklendi!');
  updateCartBadge(); // Sepet sayısını güncelle
}
```

---

### 1.3. Giriş/Kayıt (auth.html)

**Özellikler:**
- Tek sayfada hem giriş hem kayıt
- Form validasyonu
- JWT token yönetimi

**Önemli Kod:**

```javascript
let isLoginMode = true;

// Mod Değiştirme (Giriş ↔ Kayıt)
function toggleMode() {
  isLoginMode = !isLoginMode;
  if (isLoginMode) {
    // Giriş moduna geç
    document.getElementById('name-group').style.display = 'none';
  } else {
    // Kayıt moduna geç
    document.getElementById('name-group').style.display = 'block';
  }
}

// Form Gönderme
document.getElementById('auth-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  if (isLoginMode) {
    const response = await apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
    setToken(response.token); // Token'ı kaydet
    setUser(response.user);   // Kullanıcı bilgisini kaydet
    window.location.href = 'index.html';
  }
});
```

---

### 1.4. Sepet Sayfası (cart.html)

**Özellikler:**
- Ürün listesi
- Miktar artırma/azaltma
- Ürün silme
- Toplam hesaplama

**Önemli Kod:**

```javascript
// Sepeti Yükleme
async function loadCart() {
  const cartData = await apiCall('/cart');
  
  if (cartData.items.length === 0) {
    // Boş sepet mesajı göster
    return;
  }
  
  // Toplam hesaplama
  const total = cartData.items.reduce((sum, item) => 
    sum + (item.product.price * item.quantity), 0
  );
}

// Miktar Güncelleme
async function updateQuantity(productId, newQuantity) {
  await apiCall('/cart/update', {
    method: 'POST',
    body: JSON.stringify({ 
      product_id: productId, 
      quantity: newQuantity 
    })
  });
  loadCart(); // Sepeti yeniden yükle
}
```

---

### 1.5. Ödeme Sayfası (checkout.html) - YENİ!

**Özellikler:**
- 2 ödeme seçeneği: Stripe veya Banka Havalesi
- Sipariş özeti
- Ödeme durumu takibi

**Önemli Kod:**

```javascript
let selectedPaymentMethod = 'stripe';

// Ödeme Yöntemi Seçimi
function updatePaymentMethod(method) {
  selectedPaymentMethod = method;
  const btn = document.getElementById('payment-btn');
  if (method === 'stripe') {
    btn.textContent = 'Stripe ile Öde';
  } else {
    btn.textContent = 'Banka Havalesi ile Sipariş Ver';
  }
}

// Banka Havalesi ile Sipariş
async function proceedWithBankTransfer() {
  const response = await apiCall('/checkout/bank-transfer', {
    method: 'POST'
  });
  
  // IBAN bilgilerini göster
  document.getElementById('checkout-content').innerHTML = `
    <div>
      <h2>Sipariş Oluşturuldu!</h2>
      <p>IBAN: ${response.iban}</p>
      <p>Hesap Sahibi: ${response.account_holder}</p>
      <p>Tutar: ${response.total.toFixed(2)} ₺</p>
      <p>Açıklama: ${response.description}</p>
    </div>
  `;
}

// Stripe ile Ödeme
async function proceedWithStripe() {
  const originUrl = window.location.origin;
  const response = await apiCall('/checkout/create', {
    method: 'POST',
    body: JSON.stringify({ origin_url: originUrl })
  });
  
  window.location.href = response.url; // Stripe sayfasına yönlendir
}
```

---

## 🎨 2. CSS TASARIM KODLARI

### 2.1. Renkler ve Fontlar

```css
/* Özel Fontlar */
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Manrope:wght@400;500;600&display=swap');

/* Ana Renkler */
:root {
  --primary: #1A4D2E;      /* Kale Green - Yeşil */
  --secondary: #FF6B00;     /* Zest Orange - Turuncu */
  --background: #F9F7F2;    /* Açık krem */
  --text: #1A4D2E;          /* Koyu yeşil */
}

body {
  font-family: 'Manrope', sans-serif;
  background-color: #F9F7F2;
  color: #1A4D2E;
}

h1, h2, h3, h4, h5, h6 {
  font-family: 'Playfair Display', serif;
}
```

### 2.2. Buton Stilleri

```css
/* Ana Buton (Turuncu) */
.btn-primary {
  background-color: #FF6B00;
  color: white;
  padding: 0.75rem 2rem;
  border-radius: 9999px; /* Yuvarlak köşeler */
  font-weight: 600;
  transition: all 0.3s;
  box-shadow: 0 4px 6px rgba(255, 107, 0, 0.2);
}

.btn-primary:hover {
  background-color: #E65100;
  transform: scale(1.05); /* Büyüme efekti */
}

/* İkincil Buton (Beyaz) */
.btn-secondary {
  background-color: white;
  color: #1A4D2E;
  border: 2px solid #1A4D2E;
  padding: 0.75rem 2rem;
  border-radius: 9999px;
}
```

### 2.3. Ürün Kartları

```css
.product-card {
  background: white;
  border-radius: 1rem;
  overflow: hidden;
  border: 1px solid #f3f4f6;
  transition: all 0.3s;
}

.product-card:hover {
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
  transform: translateY(-2px); /* Yukarı kalkma efekti */
}

.product-card .image img {
  transition: transform 0.3s;
}

.product-card:hover .image img {
  transform: scale(1.05); /* Resim yakınlaştırma */
}
```

### 2.4. Navbar (Sabit Üst Menü)

```css
.navbar {
  position: sticky;
  top: 0;
  z-index: 50;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(12px); /* Cam efekti */
  border-bottom: 1px solid #e5e7eb;
}
```

---

## 🔧 3. BACKEND KODLARI (Python FastAPI)

### 3.1. Veritabanı Bağlantısı

```python
from motor.motor_asyncio import AsyncIOMotorClient
import os

# MongoDB bağlantısı
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]
```

### 3.2. Kullanıcı Kayıt

```python
from passlib.context import CryptContext
import jwt

pwd_context = CryptContext(schemes=["bcrypt"])

@api_router.post("/auth/register")
async def register(user_data: UserCreate):
    # Email kontrolü
    existing = await db.users.find_one({"email": user_data.email})
    if existing:
        raise HTTPException(400, "Email zaten kayıtlı")
    
    # Şifreyi hashle
    hashed_password = pwd_context.hash(user_data.password)
    
    # Kullanıcıyı kaydet
    user = User(email=user_data.email, name=user_data.name)
    user_dict = user.model_dump()
    user_dict['password'] = hashed_password
    
    await db.users.insert_one(user_dict)
    
    # JWT token oluştur
    token = create_access_token(user.id, user.email)
    
    return {"user": user, "token": token}
```

### 3.3. Ürünleri Getirme

```python
@api_router.get("/products")
async def get_products(
    category: Optional[str] = None, 
    search: Optional[str] = None
):
    query = {}
    
    # Kategori filtresi
    if category:
        query['category'] = category
    
    # Arama filtresi (regex ile)
    if search:
        query['name'] = {"$regex": search, "$options": "i"}
    
    products = await db.products.find(query, {"_id": 0}).to_list(1000)
    return products
```

### 3.4. Sepete Ekleme

```python
@api_router.post("/cart/add")
async def add_to_cart(
    item: CartItem, 
    current_user: dict = Depends(require_auth)
):
    # Ürün kontrolü
    product = await db.products.find_one({"id": item.product_id})
    if not product:
        raise HTTPException(404, "Ürün bulunamadı")
    
    # Sepeti al veya oluştur
    cart = await db.carts.find_one({"user_id": current_user['user_id']})
    if not cart:
        cart = {"user_id": current_user['user_id'], "items": []}
    
    # Ürün zaten sepette mi?
    existing_item = None
    for i, cart_item in enumerate(cart['items']):
        if cart_item['product_id'] == item.product_id:
            existing_item = i
            break
    
    if existing_item is not None:
        # Miktarı artır
        cart['items'][existing_item]['quantity'] += item.quantity
    else:
        # Yeni ürün ekle
        cart['items'].append({
            "product_id": item.product_id, 
            "quantity": item.quantity
        })
    
    # Sepeti güncelle
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": cart},
        upsert=True
    )
    
    return {"message": "Ürün sepete eklendi"}
```

### 3.5. Banka Havalesi ile Sipariş (YENİ!)

```python
@api_router.post("/checkout/bank-transfer")
async def create_bank_transfer_order(
    current_user: dict = Depends(require_auth)
):
    # Sepeti al
    cart = await db.carts.find_one({"user_id": current_user['user_id']})
    if not cart or not cart.get('items'):
        raise HTTPException(400, "Sepet boş")
    
    # Toplam hesapla
    total = 0.0
    items = []
    for item in cart['items']:
        product = await db.products.find_one({"id": item['product_id']})
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({
                "product_id": product['id'],
                "name": product['name'],
                "price": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })
    
    # Sipariş oluştur
    order = Order(
        user_id=current_user['user_id'],
        items=items,
        total=total,
        status="pending",
        payment_session_id="BANK_TRANSFER"
    )
    
    await db.orders.insert_one(order.model_dump())
    
    # Sepeti temizle
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": {"items": []}}
    )
    
    # IBAN bilgilerini döndür
    return {
        "order_id": order.id,
        "total": total,
        "iban": "TR91 0001 0090 1008 0885 5050 02",
        "account_holder": "Muhammet Ali Aslan",
        "bank_name": "Ziraat Bankası",
        "description": f"Sipariş No: {order.id[:8]}"
    }
```

### 3.6. Stripe ile Ödeme

```python
import stripe

STRIPE_API_KEY = os.environ.get('STRIPE_API_KEY')

@api_router.post("/checkout/create")
async def create_checkout(
    request: Request, 
    origin_url: str, 
    current_user: dict = Depends(require_auth)
):
    # Sepeti al ve toplam hesapla
    cart = await db.carts.find_one({"user_id": current_user['user_id']})
    total = calculate_total(cart)
    
    # Sipariş oluştur
    order = Order(...)
    await db.orders.insert_one(order.model_dump())
    
    # Stripe checkout session oluştur
    stripe_checkout = StripeCheckout(
        api_key=STRIPE_API_KEY,
        webhook_url=f"{origin_url}/api/webhook/stripe"
    )
    
    checkout_request = CheckoutSessionRequest(
        amount=total,
        currency="usd",
        success_url=f"{origin_url}/checkout?session_id={{{{CHECKOUT_SESSION_ID}}}}",
        cancel_url=f"{origin_url}/cart",
        metadata={"order_id": order.id}
    )
    
    session = await stripe_checkout.create_checkout_session(checkout_request)
    
    return {"url": session.url, "session_id": session.session_id}
```

---

## 📊 4. VERİTABANI YAPISI (MongoDB)

### 4.1. Ürünler Koleksiyonu

```javascript
{
  "id": "f1",
  "name": "Kırmızı Elma",
  "price": 12.99,
  "unit": "kg",
  "category": "fruit", // veya "vegetable"
  "image": "https://...",
  "description": "Taze ve sulu kırmızı elmalar",
  "in_stock": true
}
```

### 4.2. Kullanıcılar Koleksiyonu

```javascript
{
  "id": "user123",
  "email": "ali@example.com",
  "name": "Ali Yılmaz",
  "password": "$2b$12$...", // Hashlenmış
  "timestamp": "2024-01-15T10:30:00Z"
}
```

### 4.3. Sepet Koleksiyonu

```javascript
{
  "user_id": "user123",
  "items": [
    {
      "product_id": "f1",
      "quantity": 3
    },
    {
      "product_id": "v2",
      "quantity": 2
    }
  ],
  "updated_at": "2024-01-15T11:00:00Z"
}
```

### 4.4. Siparişler Koleksiyonu

```javascript
{
  "id": "order789",
  "user_id": "user123",
  "items": [
    {
      "product_id": "f1",
      "name": "Kırmızı Elma",
      "price": 12.99,
      "quantity": 3,
      "subtotal": 38.97
    }
  ],
  "total": 58.96,
  "status": "pending", // veya "paid", "cancelled"
  "payment_session_id": "BANK_TRANSFER", // veya Stripe session ID
  "payment_method": "bank_transfer", // veya "stripe"
  "timestamp": "2024-01-15T11:05:00Z"
}
```

---

## 🔐 5. GÜVENLİK

### 5.1. Şifre Hashleme

```python
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"])

# Şifreyi hashle
hashed = pwd_context.hash("kullanici_sifresi")

# Şifreyi doğrula
is_valid = pwd_context.verify("girilen_sifre", hashed)
```

### 5.2. JWT Token

```python
import jwt
from datetime import datetime, timedelta

def create_access_token(user_id: str, email: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(days=30)
    payload = {
        "user_id": user_id,
        "email": email,
        "exp": expire
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")

def verify_token(token: str):
    payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    return payload
```

### 5.3. Korumalı Endpoint

```python
async def require_auth(authorization: str = Header(None)) -> dict:
    if not authorization:
        raise HTTPException(401, "Giriş gerekli")
    
    token = authorization.replace("Bearer ", "")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token süresi dolmuş")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Geçersiz token")

# Kullanım
@api_router.get("/cart")
async def get_cart(current_user: dict = Depends(require_auth)):
    # current_user içinde user_id ve email var
    ...
```

---

## 🎯 6. ÖNEMLİ ÖZELLİKLER

### 6.1. Toast Bildirimleri

```javascript
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span>${type === 'success' ? '✓' : '✗'}</span>
    <span>${message}</span>
  `;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// Kullanım
showToast('Ürün sepete eklendi!', 'success');
showToast('Bir hata oluştu', 'error');
```

### 6.2. LocalStorage Yönetimi

```javascript
// Token kaydet
function setToken(token) {
  localStorage.setItem('token', token);
}

// Token oku
function getToken() {
  return localStorage.getItem('token');
}

// Kullanıcı bilgisi kaydet
function setUser(user) {
  localStorage.setItem('user', JSON.stringify(user));
}

// Kullanıcı bilgisi oku
function getUser() {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}

// Giriş kontrolü
function isLoggedIn() {
  return !!getToken();
}
```

### 6.3. API Çağrıları

```javascript
const API_URL = 'https://api.tazemarket.com/api';

async function apiCall(endpoint, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  const response = await fetch(`${API_URL}${endpoint}`, {
    ...options,
    headers
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.detail || 'Bir hata oluştu');
  }
  
  return await response.json();
}

// Kullanım örnekleri
const products = await apiCall('/products');
const cart = await apiCall('/cart');
await apiCall('/cart/add', {
  method: 'POST',
  body: JSON.stringify({ product_id: 'f1', quantity: 2 })
});
```

---

## 📱 7. RESPONSIVE TASARIM

```css
/* Tablet ve küçük ekranlar */
@media (max-width: 768px) {
  .navbar .search-bar {
    display: none; /* Arama çubuğunu gizle */
  }
  
  .hero h1 {
    font-size: 2rem; /* Başlık küçült */
  }
  
  .cart-grid {
    grid-template-columns: 1fr; /* Tek sütun */
  }
  
  .products-grid {
    grid-template-columns: repeat(2, 1fr); /* 2 sütun */
  }
}

/* Mobil ekranlar */
@media (max-width: 480px) {
  .products-grid {
    grid-template-columns: 1fr; /* Tek sütun */
  }
}
```

---

## 🚀 8. PROJE YAPISI

```
/app/
├── static/                    # Frontend dosyaları
│   ├── index.html            # Ana sayfa
│   ├── products.html         # Ürünler sayfası
│   ├── auth.html             # Giriş/Kayıt
│   ├── cart.html             # Sepet
│   ├── checkout.html         # Ödeme (2 seçenek!)
│   ├── favorites.html        # Favoriler
│   ├── orders.html           # Siparişler
│   ├── profile.html          # Profil
│   ├── styles.css            # Ana stil dosyası
│   └── app.js                # JavaScript fonksiyonları
│
├── backend/                   # Backend dosyaları
│   ├── server.py             # FastAPI uygulaması
│   ├── seed_products.py      # Ürün verilerini yükleme
│   ├── requirements.txt      # Python paketleri
│   └── .env                  # Çevre değişkenleri
│
└── README.md
```

---

## 💡 9. ÖNEMLİ NOTLAR

### Test Kullanıcı Bilgileri:
- Email: test@example.com
- Şifre: test123

### Stripe Test Kartı:
- Kart No: 4242 4242 4242 4242
- Son Kullanma: Herhangi (örn: 12/34)
- CVC: Herhangi (örn: 123)

### Banka Havalesi Bilgileri:
- IBAN: TR91 0001 0090 1008 0885 5050 02
- Hesap Sahibi: Muhammet Ali Aslan
- Banka: Ziraat Bankası

### Veritabanı:
- 10 çeşit meyve
- 10 çeşit sebze
- Toplam 20 ürün

---

## 🎨 10. TASARIM PRENSİPLERİ

### Renk Paleti:
- **Birincil:** #1A4D2E (Koyu Yeşil) - Doğal, organik
- **İkincil:** #FF6B00 (Canlı Turuncu) - Enerji, dikkat çekici
- **Arka Plan:** #F9F7F2 (Açık Krem) - Temiz, modern
- **Metin:** #1A4D2E (Koyu Yeşil) - Okunabilir

### Tipografi:
- **Başlıklar:** Playfair Display (Serif) - Zarif, premium
- **Gövde:** Manrope (Sans-serif) - Modern, okunabilir

### Buton Tasarımı:
- Yuvarlak köşeler (border-radius: 9999px)
- Hover efektleri (scale, shadow)
- Belirgin renkler (#FF6B00)

### Kart Tasarımı:
- Yumuşak gölgeler
- Hover animasyonları
- Bol beyaz alan

---

## 📊 11. API ENDPOINTLERİ

### Auth:
- POST `/api/auth/register` - Kayıt ol
- POST `/api/auth/login` - Giriş yap
- GET `/api/auth/me` - Kullanıcı bilgisi

### Products:
- GET `/api/products` - Tüm ürünler
- GET `/api/products?category=fruit` - Sadece meyveler
- GET `/api/products?search=elma` - Arama

### Cart:
- GET `/api/cart` - Sepeti getir
- POST `/api/cart/add` - Sepete ekle
- POST `/api/cart/update` - Miktarı güncelle
- DELETE `/api/cart/clear` - Sepeti temizle

### Favorites:
- GET `/api/favorites` - Favorileri getir
- POST `/api/favorites/{product_id}` - Favoriye ekle
- DELETE `/api/favorites/{product_id}` - Favoriden çıkar

### Checkout:
- POST `/api/checkout/create` - Stripe ile ödeme
- POST `/api/checkout/bank-transfer` - Banka havalesi (YENİ!)
- GET `/api/checkout/status/{session_id}` - Ödeme durumu

### Orders:
- GET `/api/orders` - Siparişleri getir
- GET `/api/orders/{order_id}` - Sipariş detayı

---

## 🎓 SUNUM İÇİN İPUÇLARI

1. **Canlı Demo:** Siteyi canlı gösterin
2. **Kod Örnekleri:** Önemli kısımları ekranda gösterin
3. **Özellikler:** 2 ödeme seçeneğini vurgulayın
4. **Tasarım:** Renkli ve çekici tasarımı gösterin
5. **Responsive:** Mobil uyumluluğu gösterin
6. **Güvenlik:** JWT ve şifre hashleme'yi açıklayın

---

## 📞 İLETİŞİM

Proje: Taze Market E-Ticaret Sitesi
Geliştirici: AI Asistan
Tarih: 2024

---

## 🎉 SONUÇ

Bu proje, modern web teknolojileri kullanarak geliştirilmiş,
tam özellikli bir e-ticaret sitesidir. Vanilla JavaScript
kullanımı sayesinde herhangi bir framework bilgisine gerek
kalmadan kolayca özelleştirilebilir!

**Temel Özellikler:**
✅ 2 Ödeme Seçeneği (Stripe + Banka Havalesi)
✅ Kullanıcı Girişi
✅ Sepet Yönetimi
✅ Favori Ürünler
✅ Arama ve Filtreleme
✅ Sipariş Takibi
✅ Responsive Tasarım
✅ Modern ve Çekici Arayüz

**İyi Sunumlar! 🚀**
