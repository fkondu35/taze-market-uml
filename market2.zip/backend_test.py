import requests
import sys
import json
from datetime import datetime

class TazeMarketAPITester:
    def __init__(self, base_url="https://taze-market-shop.preview.tazemarket.sh/api"):
        self.base_url = base_url
        self.token = None
        self.user_id = None
        self.tests_run = 0
        self.tests_passed = 0
        self.test_products = []
        self.test_order_id = None

    def run_test(self, name, method, endpoint, expected_status, data=None, headers=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        test_headers = {'Content-Type': 'application/json'}
        
        if self.token:
            test_headers['Authorization'] = f'Bearer {self.token}'
        
        if headers:
            test_headers.update(headers)

        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=test_headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=test_headers, timeout=10)
            elif method == 'DELETE':
                response = requests.delete(url, headers=test_headers, timeout=10)

            print(f"   Status: {response.status_code}")
            
            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ Passed - Status: {response.status_code}")
                try:
                    return success, response.json() if response.text else {}
                except:
                    return success, {}
            else:
                print(f"❌ Failed - Expected {expected_status}, got {response.status_code}")
                try:
                    error_detail = response.json()
                    print(f"   Error: {error_detail}")
                except:
                    print(f"   Response: {response.text}")
                return False, {}

        except Exception as e:
            print(f"❌ Failed - Error: {str(e)}")
            return False, {}

    def test_auth_register(self):
        """Test user registration"""
        test_user_data = {
            "name": "Test User",
            "email": "test@example.com",
            "password": "test123"
        }
        
        success, response = self.run_test(
            "User Registration",
            "POST",
            "auth/register",
            200,
            data=test_user_data
        )
        
        if success and 'token' in response:
            self.token = response['token']
            self.user_id = response['user']['id']
            print(f"   Token received: {self.token[:20]}...")
            return True
        return False

    def test_auth_login(self):
        """Test user login"""
        login_data = {
            "email": "test@example.com",
            "password": "test123"
        }
        
        success, response = self.run_test(
            "User Login",
            "POST",
            "auth/login",
            200,
            data=login_data
        )
        
        if success and 'token' in response:
            self.token = response['token']
            self.user_id = response['user']['id']
            print(f"   Login successful for user: {response['user']['name']}")
            return True
        return False

    def test_auth_me(self):
        """Test get current user"""
        success, response = self.run_test(
            "Get Current User",
            "GET",
            "auth/me",
            200
        )
        
        if success:
            print(f"   User: {response.get('name')} ({response.get('email')})")
        return success

    def test_get_products(self):
        """Test get all products"""
        success, response = self.run_test(
            "Get All Products",
            "GET",
            "products",
            200
        )
        
        if success:
            self.test_products = response
            print(f"   Found {len(response)} products")
            if len(response) > 0:
                print(f"   Sample product: {response[0].get('name')} - {response[0].get('price')} ₺")
        return success

    def test_get_products_by_category(self):
        """Test get products by category"""
        # Test fruit category
        success1, response1 = self.run_test(
            "Get Fruit Products",
            "GET",
            "products?category=fruit",
            200
        )
        
        # Test vegetable category
        success2, response2 = self.run_test(
            "Get Vegetable Products",
            "GET",
            "products?category=vegetable",
            200
        )
        
        if success1:
            print(f"   Found {len(response1)} fruit products")
        if success2:
            print(f"   Found {len(response2)} vegetable products")
            
        return success1 and success2

    def test_search_products(self):
        """Test product search"""
        success, response = self.run_test(
            "Search Products (elma)",
            "GET",
            "products?search=elma",
            200
        )
        
        if success:
            print(f"   Found {len(response)} products matching 'elma'")
        return success

    def test_cart_operations(self):
        """Test cart operations"""
        if not self.test_products:
            print("❌ No products available for cart testing")
            return False
        
        # Get empty cart
        success1, response1 = self.run_test(
            "Get Empty Cart",
            "GET",
            "cart",
            200
        )
        
        # Add item to cart
        test_product = self.test_products[0]
        cart_item = {
            "product_id": test_product['id'],
            "quantity": 2
        }
        
        success2, response2 = self.run_test(
            "Add Item to Cart",
            "POST",
            "cart/add",
            200,
            data=cart_item
        )
        
        # Get cart with items
        success3, response3 = self.run_test(
            "Get Cart with Items",
            "GET",
            "cart",
            200
        )
        
        if success3:
            print(f"   Cart has {len(response3.get('items', []))} items")
        
        # Update cart item
        updated_item = {
            "product_id": test_product['id'],
            "quantity": 3
        }
        
        success4, response4 = self.run_test(
            "Update Cart Item",
            "POST",
            "cart/update",
            200,
            data=updated_item
        )
        
        return success1 and success2 and success3 and success4

    def test_favorites_operations(self):
        """Test favorites operations"""
        if not self.test_products:
            print("❌ No products available for favorites testing")
            return False
        
        test_product = self.test_products[0]
        
        # Add to favorites
        success1, response1 = self.run_test(
            "Add to Favorites",
            "POST",
            f"favorites/{test_product['id']}",
            200
        )
        
        # Get favorites
        success2, response2 = self.run_test(
            "Get Favorites",
            "GET",
            "favorites",
            200
        )
        
        if success2:
            print(f"   Found {len(response2)} favorite products")
        
        # Remove from favorites
        success3, response3 = self.run_test(
            "Remove from Favorites",
            "DELETE",
            f"favorites/{test_product['id']}",
            200
        )
        
        return success1 and success2 and success3

    def test_checkout_create(self):
        """Test checkout creation"""
        # First add item to cart
        if not self.test_products:
            print("❌ No products available for checkout testing")
            return False
        
        test_product = self.test_products[0]
        cart_item = {
            "product_id": test_product['id'],
            "quantity": 1
        }
        
        # Add item to cart first
        self.run_test(
            "Add Item for Checkout",
            "POST",
            "cart/add",
            200,
            data=cart_item
        )
        
        # Create checkout session
        success, response = self.run_test(
            "Create Checkout Session",
            "POST",
            "checkout/create?origin_url=https://taze-market-shop.preview.tazemarket.sh",
            200
        )
        
        if success:
            print(f"   Checkout URL: {response.get('url', 'N/A')}")
            print(f"   Session ID: {response.get('session_id', 'N/A')}")
            self.checkout_session_id = response.get('session_id')
        
        return success

    def test_orders(self):
        """Test orders endpoint"""
        success, response = self.run_test(
            "Get Orders",
            "GET",
            "orders",
            200
        )
        
        if success:
            print(f"   Found {len(response)} orders")
            if len(response) > 0:
                print(f"   Latest order: {response[0].get('id')} - Status: {response[0].get('status')}")
        
        return success

def main():
    print("🚀 Starting Taze Market API Tests")
    print("=" * 50)
    
    tester = TazeMarketAPITester()
    
    # Test sequence
    tests = [
        ("Authentication - Register", tester.test_auth_register),
        ("Authentication - Login", tester.test_auth_login),
        ("Authentication - Get Me", tester.test_auth_me),
        ("Products - Get All", tester.test_get_products),
        ("Products - By Category", tester.test_get_products_by_category),
        ("Products - Search", tester.test_search_products),
        ("Cart Operations", tester.test_cart_operations),
        ("Favorites Operations", tester.test_favorites_operations),
        ("Checkout Creation", tester.test_checkout_create),
        ("Orders", tester.test_orders),
    ]
    
    for test_name, test_func in tests:
        print(f"\n{'='*20} {test_name} {'='*20}")
        try:
            result = test_func()
            if not result:
                print(f"⚠️  {test_name} had issues")
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {str(e)}")
    
    # Print final results
    print(f"\n{'='*50}")
    print(f"📊 Final Results: {tester.tests_passed}/{tester.tests_run} tests passed")
    print(f"Success Rate: {(tester.tests_passed/tester.tests_run)*100:.1f}%")
    
    if tester.tests_passed == tester.tests_run:
        print("🎉 All tests passed!")
        return 0
    else:
        print("⚠️  Some tests failed - check logs above")
        return 1

if __name__ == "__main__":
    sys.exit(main())