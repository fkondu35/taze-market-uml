import React from 'react';
import InfoPageLayout from '../components/InfoPageLayout';

const RefundPolicy = () => (
  <InfoPageLayout
    title="İade Koşulları"
    subtitle="Müşteri memnuniyeti önceliğimizdir"
  >
    <h2 className="text-xl font-bold text-[#1A4D2E]">Genel İlkeler</h2>
    <p>
      Taze Market olarak müşterilerimizin memnuniyetini en üst düzeyde tutmayı hedefliyoruz.
      Hasarlı, bozuk veya yanlış gönderilen ürünlerde iade ve değişim hakkınız saklıdır.
    </p>

    <h2 className="text-xl font-bold text-[#1A4D2E]">İade Talebi Nasıl Yapılır?</h2>
    <ul className="list-disc pl-6 space-y-2">
      <li>Teslimattan sonra <strong>24 saat içinde</strong> sorunu bildirin.</li>
      <li>Ürünün fotoğrafını <strong>aliaslann277@gmail.com</strong> adresine gönderin.</li>
      <li>Sipariş numaranızı ve açıklamanızı e-postada belirtin.</li>
    </ul>

    <h2 className="text-xl font-bold text-[#1A4D2E]">İade Edilebilir Durumlar</h2>
    <ul className="list-disc pl-6 space-y-2">
      <li>Çürük, ezik veya bozuk ürün teslimi</li>
      <li>Sipariş edilenden farklı ürün gönderimi</li>
      <li>Eksik veya hasarlı paket teslimi</li>
    </ul>

    <h2 className="text-xl font-bold text-[#1A4D2E]">İade Süreci</h2>
    <p>
      Geçerli iade talepleri <strong>7 iş günü</strong> içinde değerlendirilir.
      Onaylanan taleplerde ücret iadesi veya ürün değişimi yapılır.
      İade tutarı, ödeme yönteminize göre 3-10 iş günü içinde hesabınıza yansır.
    </p>

    <h2 className="text-xl font-bold text-[#1A4D2E]">İade Edilemeyen Durumlar</h2>
    <ul className="list-disc pl-6 space-y-2">
      <li>Müşteri kaynaklı gecikmelerle bozulan taze ürünler</li>
      <li>24 saatten sonra bildirilen talepler (makul olmayan durumlar hariç)</li>
      <li>Kişisel hijyen ve gıda güvenliği nedeniyle açılmış ambalajlar</li>
    </ul>

    <p className="font-semibold text-[#1A4D2E] pt-4">
      Sorularınız için: aliaslann277@gmail.com
    </p>
  </InfoPageLayout>
);

export default RefundPolicy;
