import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")


async def verify() -> int:
    mongo_url = os.environ["MONGO_URL"]
    db_name = os.environ["DB_NAME"]

    client = AsyncIOMotorClient(mongo_url)
    db = client[db_name]

    minimum_counts = {
        "products": 10,
        "users": 10,
        "carts": 10,
        "favorites": 10,
        "orders": 10,
        "payment_transactions": 10,
    }

    print("=== Seed Verification Report ===")
    failed = False
    for collection_name, min_count in minimum_counts.items():
        count = await db[collection_name].count_documents({})
        status = "PASS" if count >= min_count else "FAIL"
        print(f"{collection_name}: {count} (min: {min_count}) -> {status}")
        if count < min_count:
            failed = True

    client.close()
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(verify()))
