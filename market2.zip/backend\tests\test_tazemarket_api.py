"""
TazeMarket API Tests
Tests for Turkish fresh fruit & vegetable e-commerce site
"""
import pytest
import requests
import os
import uuid

BASE_URL = os.environ.get('REACT_APP_BACKEND_URL', 'https://taze-market-shop.preview.tazemarket.sh').rstrip('/')

# Admin credentials
ADMIN_USERNAME = "mku123456"
ADMIN_PASSWORD = "1234567a"


class TestHealthAndProducts:
    """Test basic endpoints - products list"""
    
    def test_products_list(self):
        """GET /api/products - should return list of products"""
        response = requests.get(f"{BASE_URL}/api/products")
        assert response.status_code == 200
        products = response.json()
        assert isinstance(products, list)
        assert len(products) > 0
        # Verify product structure
        product = products[0]
        assert "id" in product
        assert "name" in product
        assert "price" in product
        assert "category" in product
        print(f"✓ Products list: {len(products)} products found")
    
    def test_products_filter_by_category_fruit(self):
        """GET /api/products?category=fruit - should filter fruits"""
        response = requests.get(f"{BASE_URL}/api/products?category=fruit")
        assert response.status_code == 200
        products = response.json()
        assert all(p['category'] == 'fruit' for p in products)
        print(f"✓ Fruit filter: {len(products)} fruits found")
    
    def test_products_filter_by_category_vegetable(self):
        """GET /api/products?category=vegetable - should filter vegetables"""
        response = requests.get(f"{BASE_URL}/api/products?category=vegetable")
        assert response.status_code == 200
        products = response.json()
        assert all(p['category'] == 'vegetable' for p in products)
        print(f"✓ Vegetable filter: {len(products)} vegetables found")
    
    def test_single_product(self):
        """GET /api/products/{id} - should return single product"""
        response = requests.get(f"{BASE_URL}/api/products/f1")
        assert response.status_code == 200
        product = response.json()
        assert product['id'] == 'f1'
        assert product['name'] == 'Kırmızı Elma'
        print(f"✓ Single product: {product['name']}")


class TestAdminAuth:
    """Test admin authentication"""
    
    def test_admin_login_success(self):
        """POST /api/auth/admin-login - should login admin"""
        response = requests.post(
            f"{BASE_URL}/api/auth/admin-login",
            json={"username": ADMIN_USERNAME, "password": ADMIN_PASSWORD}
        )
        assert response.status_code == 200
        data = response.json()
        assert "token" in data
        assert "user" in data
        assert data["user"]["is_admin"] == True
        assert data["user"]["username"] == ADMIN_USERNAME
        print(f"✓ Admin login successful: {data['user']['username']}")
    
    def test_admin_login_wrong_password(self):
        """POST /api/auth/admin-login - should fail with wrong password"""
        response = requests.post(
            f"{BASE_URL}/api/auth/admin-login",
            json={"username": ADMIN_USERNAME, "password": "wrongpassword"}
        )
        assert response.status_code == 401
        print("✓ Admin login rejected with wrong password")
    
    def test_admin_login_wrong_username(self):
        """POST /api/auth/admin-login - should fail with wrong username"""
        response = requests.post(
            f"{BASE_URL}/api/auth/admin-login",
            json={"username": "wronguser", "password": ADMIN_PASSWORD}
        )
        assert response.status_code == 401
        print("✓ Admin login rejected with wrong username")


class TestUserAuth:
    """Test user registration and login"""
    
    def test_user_registration(self):
        """POST /api/auth/register - should register new user"""
        unique_email = f"test_{uuid.uuid4().hex[:8]}@test.com"
        response = requests.post(
            f"{BASE_URL}/api/auth/register",
            json={
                "name": "Test User",
                "email": unique_email,
                "password": "testpass123"
            }
        )
        assert response.status_code == 200
        data = response.json()
        assert "token" in data
        assert "user" in data
        assert data["user"]["email"] == unique_email
        print(f"✓ User registration successful: {unique_email}")
        return data["token"]
    
    def test_user_login(self):
        """POST /api/auth/login - should login user"""
        # First register
        unique_email = f"test_{uuid.uuid4().hex[:8]}@test.com"
        reg_response = requests.post(
            f"{BASE_URL}/api/auth/register",
            json={
                "name": "Test User",
                "email": unique_email,
                "password": "testpass123"
            }
        )
        assert reg_response.status_code == 200
        
        # Then login
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": unique_email, "password": "testpass123"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "token" in data
        assert data["user"]["email"] == unique_email
        print(f"✓ User login successful: {unique_email}")
    
    def test_user_login_invalid_credentials(self):
        """POST /api/auth/login - should fail with invalid credentials"""
        response = requests.post(
            f"{BASE_URL}/api/auth/login",
            json={"email": "nonexistent@test.com", "password": "wrongpass"}
        )
        assert response.status_code == 401
        print("✓ User login rejected with invalid credentials")


class TestAdminStats:
    """Test admin stats endpoint"""
    
    @pytest.fixture
    def admin_token(self):
        """Get admin token"""
        response = requests.post(
            f"{BASE_URL}/api/auth/admin-login",
            json={"username": ADMIN_USERNAME, "password": ADMIN_PASSWORD}
        )
        return response.json()["token"]
    
    def test_admin_stats(self, admin_token):
        """GET /api/admin/stats - should return stats"""
        response = requests.get(
            f"{BASE_URL}/api/admin/stats",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == 200
        stats = response.json()
        assert "total_products" in stats
        assert "total_users" in stats
        assert "total_orders" in stats
        assert "total_revenue" in stats
        assert stats["total_products"] >= 20  # Seeded 20 products
        print(f"✓ Admin stats: {stats['total_products']} products, {stats['total_users']} users")
    
    def test_admin_stats_unauthorized(self):
        """GET /api/admin/stats - should fail without auth"""
        response = requests.get(f"{BASE_URL}/api/admin/stats")
        assert response.status_code == 401
        print("✓ Admin stats rejected without auth")


class TestAdminProductCRUD:
    """Test admin product CRUD operations"""
    
    @pytest.fixture
    def admin_token(self):
        """Get admin token"""
        response = requests.post(
            f"{BASE_URL}/api/auth/admin-login",
            json={"username": ADMIN_USERNAME, "password": ADMIN_PASSWORD}
        )
        return response.json()["token"]
    
    def test_admin_get_products(self, admin_token):
        """GET /api/admin/products - should return all products"""
        response = requests.get(
            f"{BASE_URL}/api/admin/products",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == 200
        products = response.json()
        assert len(products) >= 20
        print(f"✓ Admin products list: {len(products)} products")
    
    def test_admin_create_product(self, admin_token):
        """POST /api/admin/products - should create product"""
        new_product = {
            "id": f"test_{uuid.uuid4().hex[:8]}",
            "name": "TEST Ürün",
            "price": 99.99,
            "unit": "kg",
            "category": "fruit",
            "image": "https://example.com/test.jpg",
            "description": "Test ürün açıklaması",
            "in_stock": True
        }
        response = requests.post(
            f"{BASE_URL}/api/admin/products",
            json=new_product,
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["product"]["name"] == "TEST Ürün"
        print(f"✓ Admin created product: {new_product['id']}")
        
        # Cleanup - delete the test product
        requests.delete(
            f"{BASE_URL}/api/admin/products/{new_product['id']}",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
    
    def test_admin_update_product(self, admin_token):
        """PUT /api/admin/products/{id} - should update product"""
        # First create a test product
        test_id = f"test_{uuid.uuid4().hex[:8]}"
        new_product = {
            "id": test_id,
            "name": "TEST Ürün Original",
            "price": 50.00,
            "unit": "kg",
            "category": "fruit",
            "image": "https://example.com/test.jpg",
            "in_stock": True
        }
        requests.post(
            f"{BASE_URL}/api/admin/products",
            json=new_product,
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        
        # Update the product
        updated_product = {
            "id": test_id,
            "name": "TEST Ürün Updated",
            "price": 75.00,
            "unit": "kg",
            "category": "fruit",
            "image": "https://example.com/test.jpg",
            "in_stock": True
        }
        response = requests.put(
            f"{BASE_URL}/api/admin/products/{test_id}",
            json=updated_product,
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["product"]["price"] == 75.00
        print(f"✓ Admin updated product price: 50.00 -> 75.00")
        
        # Cleanup
        requests.delete(
            f"{BASE_URL}/api/admin/products/{test_id}",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
    
    def test_admin_delete_product(self, admin_token):
        """DELETE /api/admin/products/{id} - should delete product"""
        # First create a test product
        test_id = f"test_{uuid.uuid4().hex[:8]}"
        new_product = {
            "id": test_id,
            "name": "TEST Ürün To Delete",
            "price": 10.00,
            "unit": "adet",
            "category": "vegetable",
            "image": "https://example.com/test.jpg",
            "in_stock": True
        }
        requests.post(
            f"{BASE_URL}/api/admin/products",
            json=new_product,
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        
        # Delete the product
        response = requests.delete(
            f"{BASE_URL}/api/admin/products/{test_id}",
            headers={"Authorization": f"Bearer {admin_token}"}
        )
        assert response.status_code == 200
        
        # Verify deletion
        get_response = requests.get(f"{BASE_URL}/api/products/{test_id}")
        assert get_response.status_code == 404
        print(f"✓ Admin deleted product: {test_id}")


class TestCartFlow:
    """Test cart operations"""
    
    @pytest.fixture
    def user_token(self):
        """Get user token"""
        unique_email = f"test_{uuid.uuid4().hex[:8]}@test.com"
        response = requests.post(
            f"{BASE_URL}/api/auth/register",
            json={
                "name": "Cart Test User",
                "email": unique_email,
                "password": "testpass123"
            }
        )
        return response.json()["token"]
    
    def test_add_to_cart(self, user_token):
        """POST /api/cart/add - should add item to cart"""
        response = requests.post(
            f"{BASE_URL}/api/cart/add",
            json={"product_id": "f1", "quantity": 2},
            headers={"Authorization": f"Bearer {user_token}"}
        )
        assert response.status_code == 200
        print("✓ Added item to cart")
    
    def test_get_cart(self, user_token):
        """GET /api/cart - should return cart"""
        # First add item
        requests.post(
            f"{BASE_URL}/api/cart/add",
            json={"product_id": "f1", "quantity": 1},
            headers={"Authorization": f"Bearer {user_token}"}
        )
        
        # Get cart
        response = requests.get(
            f"{BASE_URL}/api/cart",
            headers={"Authorization": f"Bearer {user_token}"}
        )
        assert response.status_code == 200
        cart = response.json()
        assert "items" in cart
        print(f"✓ Cart retrieved: {len(cart['items'])} items")
    
    def test_cart_unauthorized(self):
        """GET /api/cart - should fail without auth"""
        response = requests.get(f"{BASE_URL}/api/cart")
        assert response.status_code == 401
        print("✓ Cart rejected without auth")


class TestBankTransferCheckout:
    """Test bank transfer checkout flow"""
    
    @pytest.fixture
    def user_token(self):
        """Get user token"""
        unique_email = f"test_{uuid.uuid4().hex[:8]}@test.com"
        response = requests.post(
            f"{BASE_URL}/api/auth/register",
            json={
                "name": "Checkout Test User",
                "email": unique_email,
                "password": "testpass123"
            }
        )
        return response.json()["token"]
    
    def test_bank_transfer_checkout(self, user_token):
        """POST /api/checkout/bank-transfer - should create order"""
        # First add item to cart
        requests.post(
            f"{BASE_URL}/api/cart/add",
            json={"product_id": "f1", "quantity": 2},
            headers={"Authorization": f"Bearer {user_token}"}
        )
        
        # Create bank transfer order
        response = requests.post(
            f"{BASE_URL}/api/checkout/bank-transfer",
            headers={"Authorization": f"Bearer {user_token}"}
        )
        assert response.status_code == 200
        data = response.json()
        assert "order_id" in data
        assert "iban" in data
        assert "total" in data
        print(f"✓ Bank transfer order created: {data['order_id'][:8]}, Total: {data['total']} TRY")
    
    def test_bank_transfer_empty_cart(self, user_token):
        """POST /api/checkout/bank-transfer - should fail with empty cart"""
        # Clear cart first
        requests.delete(
            f"{BASE_URL}/api/cart/clear",
            headers={"Authorization": f"Bearer {user_token}"}
        )
        
        response = requests.post(
            f"{BASE_URL}/api/checkout/bank-transfer",
            headers={"Authorization": f"Bearer {user_token}"}
        )
        assert response.status_code == 400
        print("✓ Bank transfer rejected with empty cart")


class TestOrders:
    """Test orders endpoints"""
    
    @pytest.fixture
    def user_with_order(self):
        """Create user with an order"""
        unique_email = f"test_{uuid.uuid4().hex[:8]}@test.com"
        reg_response = requests.post(
            f"{BASE_URL}/api/auth/register",
            json={
                "name": "Order Test User",
                "email": unique_email,
                "password": "testpass123"
            }
        )
        token = reg_response.json()["token"]
        
        # Add to cart and checkout
        requests.post(
            f"{BASE_URL}/api/cart/add",
            json={"product_id": "v1", "quantity": 3},
            headers={"Authorization": f"Bearer {token}"}
        )
        requests.post(
            f"{BASE_URL}/api/checkout/bank-transfer",
            headers={"Authorization": f"Bearer {token}"}
        )
        
        return token
    
    def test_get_orders(self, user_with_order):
        """GET /api/orders - should return user orders"""
        response = requests.get(
            f"{BASE_URL}/api/orders",
            headers={"Authorization": f"Bearer {user_with_order}"}
        )
        assert response.status_code == 200
        orders = response.json()
        assert isinstance(orders, list)
        assert len(orders) >= 1
        print(f"✓ Orders retrieved: {len(orders)} orders")


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
