import React from 'react';
import ReviewsSection from '../components/ReviewsSection';

const Reviews = () => {
  return (
    <div className="min-h-screen py-12" data-testid="reviews-page">
      <ReviewsSection showForm={true} compact={false} />
    </div>
  );
};

export default Reviews;
