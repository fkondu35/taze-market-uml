# 🔧 URL DEĞİŞTİRME REHBERİ

## Kendi URL'nizi Nasıl Kullanırsınız?

### Yöntem 1: config.js Dosyasını Düzenleyin (ÖNERİLEN)

1. `/app/static/config.js` dosyasını açın

2. `API_URL` değerini değiştirin:

```javascript
const CONFIG = {
  // ESKI (Ornek gelistirme URL'i):
  API_URL: 'https://api.tazemarket.com/api',
  
  // YENİ (Kendi URL'niz):
  API_URL: 'https://api.tazemarket.com/api',
  // veya
  API_URL: 'http://localhost:8001/api',  // Yerel geliştirme için
  
  SITE_NAME: 'Taze Market',
  SITE_DOMAIN: 'TazeMarket.com',
  ...
};
```

3. Dosyayı kaydedin
4. Tarayıcıyı yenileyin (Ctrl+F5 veya Cmd+Shift+R)

### Yöntem 2: Manuel Değiştirme

Eğer config.js kullanmak istemezseniz:

1. `/app/static/app.js` dosyasını açın
2. İlk satırdaki URL'i değiştirin:

```javascript
// Satır 1-2:
const API_URL = typeof CONFIG !== 'undefined' ? CONFIG.API_URL : 'https://api.tazemarket.com/api';
```

---

## 🌐 Kendi Domain'inizi Kullanma

### Adım 1: Backend'i Kendi Sunucunuza Deploy Edin

```bash
# Backend dosyalarını sunucunuza yükleyin
cd /app/backend
scp -r * kullanici@sunucunuz.com:/path/to/backend/

# Sunucunuzda:
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001
```

### Adım 2: Frontend'i Web Sunucunuza Yükleyin

```bash
# Static dosyaları yükleyin
cd /app/static
scp -r * kullanici@sunucunuz.com:/var/www/tazemarket.com/
```

### Adım 3: Domain Ayarları

**A) Nginx Konfigürasyonu (sunucunuzda):**

```nginx
# Frontend (tazemarket.com)
server {
    listen 80;
    server_name tazemarket.com www.tazemarket.com;
    root /var/www/tazemarket.com;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
}

# Backend (api.tazemarket.com)
server {
    listen 80;
    server_name api.tazemarket.com;
    
    location / {
        proxy_pass http://localhost:8001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

**B) DNS Ayarları:**

Domain sağlayıcınızda (GoDaddy, Namecheap, vb.):

```
Type    Name    Value                TTL
A       @       123.456.789.0        3600
A       www     123.456.789.0        3600
A       api     123.456.789.0        3600
```

### Adım 4: config.js'i Güncelleyin

```javascript
const CONFIG = {
  API_URL: 'https://api.tazemarket.com/api',  // Yeni backend URL
  SITE_NAME: 'Taze Market',
  SITE_DOMAIN: 'TazeMarket.com',
  ...
};
```

---

## 🔒 SSL/HTTPS Kurulumu (Güvenli Bağlantı)

```bash
# Sunucunuzda Let's Encrypt kurulumu
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d tazemarket.com -d www.tazemarket.com -d api.tazemarket.com
```

Artık URL'niz şöyle olacak:
- Frontend: `https://tazemarket.com`
- Backend: `https://api.tazemarket.com`

---

## 🧪 Test Etme

### Yerel Test (localhost):

```javascript
// config.js
const CONFIG = {
  API_URL: 'http://localhost:8001/api',
  ...
};
```

Terminal'de:
```bash
# Backend'i başlat
cd /app/backend
uvicorn server:app --reload

# Frontend'i başlat (başka terminal)
cd /app/static
python -m http.server 8000

# Tarayıcıda: http://localhost:8000
```

### Canlı Test:

```javascript
// config.js
const CONFIG = {
  API_URL: 'https://api.tazemarket.com/api',
  ...
};
```

---

## 📝 Önemli Notlar

1. **CORS Ayarları:** Backend'inizde frontend domain'inizin izinli olduğundan emin olun
   
2. **Environment Variables:** `.env` dosyasında CORS_ORIGINS'i güncelleyin:
   ```
   CORS_ORIGINS=https://tazemarket.com,https://www.tazemarket.com
   ```

3. **Cache Temizleme:** URL değiştirdikten sonra:
   - Ctrl+F5 (Windows/Linux)
   - Cmd+Shift+R (Mac)
   - Browser cache'i temizleyin

4. **MongoDB:** Kendi sunucunuzda MongoDB kurulu olmalı veya MongoDB Atlas kullanın

---

## 🚀 Hızlı Başlangıç Checklist

- [ ] Backend'i sunucuya yükledim
- [ ] Frontend dosyalarını sunucuya yükledim
- [ ] DNS ayarlarını yaptım
- [ ] SSL sertifikası kurdum
- [ ] config.js'teki API_URL'i güncelledim
- [ ] MongoDB bağlantısını kontrol ettim
- [ ] Tarayıcıda test ettim
- [ ] Ödeme sistemi çalışıyor

---

## 💡 Alternatif Hosting Seçenekleri

### 1. Vercel (Frontend için - ÜCRETSİZ)
```bash
npm i -g vercel
cd /app/static
vercel deploy
```

### 2. Heroku (Backend için)
```bash
heroku create tazemarket-api
git push heroku main
```

### 3. DigitalOcean App Platform
- GitHub repo bağlayın
- Otomatik deploy

### 4. AWS (Profesyonel)
- EC2: Sunucu
- S3: Static dosyalar
- RDS: Database

---

## ❓ Sorun Giderme

**Sorun:** API'ye erişilemiyor
- Backend çalışıyor mu kontrol edin
- CORS ayarlarını kontrol edin
- Firewall kurallarını kontrol edin

**Sorun:** "Mixed Content" hatası
- Hem frontend hem backend HTTPS olmalı
- veya ikisi de HTTP olmalı

**Sorun:** Ödeme çalışmıyor
- Stripe webhook URL'ini güncelleyin
- Backend URL'inin doğru olduğundan emin olun

---

## 📞 Yardım

Sorun yaşıyorsanız:
1. Browser Console'u açın (F12)
2. Network sekmesinde API çağrılarını kontrol edin
3. Backend loglarını kontrol edin

**İyi Şanslar! 🎉**
