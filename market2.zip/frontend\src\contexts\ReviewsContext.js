import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import axios from 'axios';

const ReviewsContext = createContext(null);

const BACKEND_URL = (process.env.REACT_APP_BACKEND_URL || window.location.origin).replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;

export const ReviewsProvider = ({ children }) => {
  const [reviews, setReviews] = useState([]);
  const [averageRating, setAverageRating] = useState(0);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchReviews = useCallback(async () => {
    try {
      const res = await axios.get(`${API}/reviews`);
      setReviews(res.data.reviews);
      setAverageRating(res.data.average_rating);
      setTotal(res.data.total);
    } catch (error) {
      console.error('Failed to fetch reviews:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchReviews();
  }, [fetchReviews]);

  const refreshReviews = useCallback(async () => {
    await fetchReviews();
  }, [fetchReviews]);

  return (
    <ReviewsContext.Provider value={{
      reviews,
      averageRating,
      total,
      loading,
      fetchReviews,
      refreshReviews,
    }}>
      {children}
    </ReviewsContext.Provider>
  );
};

export const useReviews = () => {
  const context = useContext(ReviewsContext);
  if (!context) {
    throw new Error('useReviews must be used within ReviewsProvider');
  }
  return context;
};
