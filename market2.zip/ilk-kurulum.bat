@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ========================================
echo  TAZE MARKET - ILK KURULUM
echo ========================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo HATA: Node.js bulunamadi. https://nodejs.org adresinden kurun.
  pause
  exit /b 1
)

where python >nul 2>&1
if errorlevel 1 (
  echo HATA: Python bulunamadi. https://python.org adresinden kurun.
  pause
  exit /b 1
)

echo [1/5] MongoDB kontrol ediliyor...
sc query MongoDB | find "RUNNING" >nul
if errorlevel 1 (
  echo MongoDB servisi baslatiliyor...
  net start MongoDB >nul 2>&1
  if errorlevel 1 (
    echo.
    echo HATA: MongoDB calismiyor.
    echo MongoDB Server kurulu degilse su komutu calistirin:
    echo   winget install MongoDB.Server
    echo.
    pause
    exit /b 1
  )
)
echo MongoDB hazir.

echo.
echo [2/5] Backend bagimliliklari kontrol ediliyor...
if not exist "backend\venv\Scripts\python.exe" (
  cd backend
  python -m venv venv
  venv\Scripts\python.exe -m pip install -r requirements.txt
  cd ..
)
echo Backend hazir.

echo.
echo [3/5] Veritabani dolduruluyor...
cd backend
venv\Scripts\python.exe seed_products.py
if errorlevel 1 (
  echo HATA: Veritabani doldurulamadi. MongoDB calisiyor mu kontrol edin.
  cd ..
  pause
  exit /b 1
)
cd ..

echo.
echo [4/5] Frontend derleniyor (API: http://localhost:8001)...
cd frontend
if not exist "node_modules" (
  call npm install
)
call npm run build
if errorlevel 1 (
  echo HATA: Frontend derlenemedi.
  cd ..
  pause
  exit /b 1
)
cd ..

echo.
echo [5/5] Build dosyalari kopyalaniyor...
if not exist "build" mkdir build
xcopy /E /Y /I "frontend\build\*" "build\" >nul

echo.
echo ========================================
echo  KURULUM TAMAMLANDI
echo ========================================
echo.
echo Simdi calistir.bat dosyasina cift tiklayin.
echo.
pause
