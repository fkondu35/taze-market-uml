import React from 'react';
import InfoPageLayout from '../components/InfoPageLayout';
import { Mail, MessageCircle } from 'lucide-react';

const CONTACT_EMAIL = 'aliaslann277@gmail.com';

const Contact = () => (
  <InfoPageLayout
    title="İletişim"
    subtitle="Sorularınız için bize ulaşın"
  >
    <p>
      Sipariş, iade, ürün veya iş birliği konularında bizimle iletişime geçebilirsiniz.
      En kısa sürede size dönüş yapıyoruz.
    </p>

    <div className="flex items-start gap-4 p-5 bg-[#F9F7F2] rounded-xl not-prose">
      <Mail className="text-[#FF6B00] shrink-0 mt-1" size={24} />
      <div>
        <p className="font-semibold text-[#1A4D2E] mb-1">E-posta</p>
        <a
          href={`mailto:${CONTACT_EMAIL}`}
          className="text-[#FF6B00] hover:text-[#E65100] font-medium text-lg"
        >
          {CONTACT_EMAIL}
        </a>
      </div>
    </div>

    <div className="flex items-start gap-4 p-5 bg-[#F9F7F2] rounded-xl not-prose">
      <MessageCircle className="text-[#FF6B00] shrink-0 mt-1" size={24} />
      <div>
        <p className="font-semibold text-[#1A4D2E] mb-1">Yapay Zeka Destek Asistanı</p>
        <p className="text-[#4A6B5A]">
          Hızlı yanıt için sağ alttaki yeşil sohbet balonuna tıklayarak yapay zeka
          asistanımızla anında konuşabilirsiniz.
        </p>
      </div>
    </div>

    <p className="text-sm">
      Çalışma saatlerimiz: Hafta içi 09:00 – 18:00. E-postalarınıza en geç 24 saat içinde yanıt verilir.
    </p>
  </InfoPageLayout>
);

export default Contact;
