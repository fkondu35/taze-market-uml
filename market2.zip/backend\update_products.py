import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

PEACH_IMAGE = "/urunler/seftali.png"

NEW_PRODUCTS = [
    {"id": "f11", "name": "Kiraz", "price": 54.99, "unit": "kg", "category": "fruit", "image": "/urunler/kiraz.png", "description": "Tatlı ve sulu taze kirazlar", "in_stock": True, "stock_quantity": 52},
    {"id": "f12", "name": "Armut", "price": 18.99, "unit": "kg", "category": "fruit", "image": "/urunler/armut.png", "description": "Olgunlaşmış sulu armutlar", "in_stock": True, "stock_quantity": 67},
    {"id": "f13", "name": "Kavun", "price": 12.99, "unit": "kg", "category": "fruit", "image": "/urunler/kavun.jpg", "description": "Tatlı ve aromatik kavun", "in_stock": True, "stock_quantity": 73},
    {"id": "v11", "name": "Kabak", "price": 10.49, "unit": "kg", "category": "vegetable", "image": "/urunler/kabak.png", "description": "Taze yeşil kabak", "in_stock": True, "stock_quantity": 58},
    {"id": "v12", "name": "Marul", "price": 8.99, "unit": "adet", "category": "vegetable", "image": "/urunler/marul.png", "description": "Çıtır çıtır taze marul", "in_stock": True, "stock_quantity": 48},
    {"id": "v13", "name": "Sarımsak", "price": 39.99, "unit": "kg", "category": "vegetable", "image": "/urunler/sarimsak.png", "description": "Kokulu ve taze sarımsak", "in_stock": True, "stock_quantity": 88},
    {"id": "v14", "name": "Soğan", "price": 6.99, "unit": "kg", "category": "vegetable", "image": "/urunler/sogan.png", "description": "Günlük kullanım için taze soğan", "in_stock": True, "stock_quantity": 130},
]

IMAGE_FIXES = {
    "f11": "/urunler/kiraz.png",
    "f12": "/urunler/armut.png",
    "f13": "/urunler/kavun.jpg",
    "v11": "/urunler/kabak.png",
    "v12": "/urunler/marul.png",
    "v13": "/urunler/sarimsak.png",
    "v14": "/urunler/sogan.png",
}


async def main():
    client = AsyncIOMotorClient(os.environ["MONGO_URL"])
    db = client[os.environ["DB_NAME"]]

    await db.products.update_one({"id": "f10"}, {"$set": {"image": PEACH_IMAGE}})
    print("[OK] Şeftali görseli güncellendi")

    for product_id, image in IMAGE_FIXES.items():
        result = await db.products.update_one({"id": product_id}, {"$set": {"image": image}})
        print(f"[OK] {product_id} -> {image} (matched={result.matched_count})")

    for product in NEW_PRODUCTS:
        existing = await db.products.find_one({"id": product["id"]})
        if existing:
            await db.products.update_one({"id": product["id"]}, {"$set": product})
        else:
            await db.products.insert_one(product)

    total = await db.products.count_documents({})
    print(f"Toplam ürün: {total}")


if __name__ == "__main__":
    asyncio.run(main())
