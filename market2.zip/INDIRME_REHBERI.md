# 📦 TAZE MARKET - TÜM KODLAR VE İNDİRME REHBERİ

## 🎯 PROJE YAPISI

```
taze-market/
│
├── 📁 FRONTEND (static/)
│   ├── index.html           # Ana sayfa
│   ├── products.html        # Ürünler sayfası
│   ├── auth.html            # Giriş/Kayıt
│   ├── cart.html            # Sepet
│   ├── checkout.html        # Ödeme (2 seçenek)
│   ├── favorites.html       # Favoriler
│   ├── orders.html          # Siparişler
│   ├── profile.html         # Profil
│   ├── styles.css           # CSS stilleri
│   └── app.js               # JavaScript kodları
│
├── 📁 BACKEND
│   ├── server.py            # FastAPI backend
│   ├── seed_products.py     # Ürün verilerini yükleme
│   └── requirements.txt     # Python paketleri
│
└── 📄 KODLAR_SUNUM.md      # Detaylı kod açıklamaları
```

---

## 💾 DESKTOP'A KAYDETME YÖNTEMLERİ

### Yöntem 1: ZIP İndirme (EN KOLAY) ✅

**Adım 1:** Aşağıdaki komutu terminal'de çalıştırın:
```bash
cd /app && ls -lh taze-market-FULL.zip
```

**Adım 2:** Dosyayı indirmek için:
- Proje klasorunden "Files" sekmesine gidin
- `/app/taze-market-FULL.zip` dosyasını bulun
- Sağ tıklayıp "Download" seçin

### Yöntem 2: Manuel Kopyalama

Her dosyayı tek tek kopyalayıp desktop'unuzda oluşturun.

---

## 📋 DOSYA İÇERİKLERİ

### 🎨 1. FRONTEND - HTML DOSYALARI

#### A) index.html (Ana Sayfa)
```html
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Taze Market</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <!-- Navbar -->
  <nav class="navbar">
    <div class="container">
      <a href="index.html" class="logo">Taze Market</a>
      <input type="text" placeholder="Ürün ara..." id="search-input">
      <ul class="nav-links" id="auth-links"></ul>
    </div>
  </nav>

  <!-- Hero Section -->
  <section class="hero">
    <h1>En Taze Meyve ve Sebzeler</h1>
    <p>Doğrudan çiftçiden sofraya!</p>
    <a href="products.html" class="btn-primary">Meyveleri Keşfet</a>
  </section>

  <!-- Kategoriler & Ürünler -->
  <section class="products">
    <div id="featured-products"></div>
  </section>

  <script src="app.js"></script>
  <script>
    // Ürünleri yükle
    async function loadFeaturedProducts() {
      const products = await apiCall('/products');
      // Ürünleri göster
    }
    loadFeaturedProducts();
  </script>
</body>
</html>
```

#### B) products.html (Ürünler Sayfası)
```html
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Ürünler - Taze Market</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <nav class="navbar">
    <a href="index.html" class="logo">Taze Market</a>
    <ul class="nav-links" id="auth-links"></ul>
  </nav>

  <section class="products">
    <h1 id="page-title">Tüm Ürünler</h1>
    <div class="products-grid" id="products-container"></div>
  </section>

  <script src="app.js"></script>
  <script>
    // URL parametrelerini al
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('category'); // fruit veya vegetable
    const search = urlParams.get('search');

    // Ürünleri filtrele ve göster
    async function loadProducts() {
      let url = '/products';
      if (category) url += `?category=${category}`;
      if (search) url += `?search=${search}`;
      
      const products = await apiCall(url);
      // Ürünleri ekranda göster
    }
    loadProducts();
  </script>
</body>
</html>
```

#### C) auth.html (Giriş/Kayıt)
```html
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Giriş Yap - Taze Market</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="auth-container">
    <div class="auth-card">
      <h2 id="auth-title">Giriş Yap</h2>
      
      <form id="auth-form">
        <div class="form-group" id="name-group" style="display: none;">
          <label>Ad Soyad</label>
          <input type="text" id="name">
        </div>
        
        <div class="form-group">
          <label>E-posta</label>
          <input type="email" id="email" required>
        </div>
        
        <div class="form-group">
          <label>Şifre</label>
          <input type="password" id="password" required>
        </div>
        
        <button type="submit" class="btn-primary">Giriş Yap</button>
      </form>
      
      <button onclick="toggleMode()">Hesabın yok mu? Kayıt ol</button>
    </div>
  </div>

  <script src="app.js"></script>
  <script>
    let isLoginMode = true;

    function toggleMode() {
      isLoginMode = !isLoginMode;
      // Mod değiştir (giriş ↔ kayıt)
    }

    document.getElementById('auth-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      
      if (isLoginMode) {
        // Giriş yap
        const response = await apiCall('/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            email: document.getElementById('email').value,
            password: document.getElementById('password').value
          })
        });
        setToken(response.token);
        window.location.href = 'index.html';
      } else {
        // Kayıt ol
        await apiCall('/auth/register', {...});
      }
    });
  </script>
</body>
</html>
```

#### D) cart.html (Sepet)
```html
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Sepetim - Taze Market</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <nav class="navbar">
    <a href="index.html" class="logo">Taze Market</a>
    <ul class="nav-links" id="auth-links"></ul>
  </nav>

  <div class="cart-container">
    <h1>Sepetim</h1>
    <div id="cart-content"></div>
  </div>

  <script src="app.js"></script>
  <script>
    async function loadCart() {
      const cartData = await apiCall('/cart');
      
      if (cartData.items.length === 0) {
        // Boş sepet mesajı
        return;
      }

      // Sepet ürünlerini göster
      const total = cartData.items.reduce((sum, item) => 
        sum + (item.product.price * item.quantity), 0
      );

      // Toplam ve ödeme butonu göster
    }

    async function updateQuantity(productId, newQuantity) {
      await apiCall('/cart/update', {
        method: 'POST',
        body: JSON.stringify({ product_id: productId, quantity: newQuantity })
      });
      loadCart();
    }

    loadCart();
  </script>
</body>
</html>
```

#### E) checkout.html (Ödeme - 2 Seçenek!)
```html
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <title>Ödeme - Taze Market</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <nav class="navbar">
    <a href="index.html" class="logo">Taze Market</a>
  </nav>

  <div class="cart-container">
    <h1>Ödeme</h1>
    <div id="checkout-content"></div>
  </div>

  <script src="app.js"></script>
  <script>
    let selectedPaymentMethod = 'stripe';

    async function loadCheckout() {
      const cart = await apiCall('/cart');
      const total = cart.items.reduce((sum, item) => 
        sum + (item.product.price * item.quantity), 0
      );

      // Sipariş özeti ve ödeme seçenekleri göster
      document.getElementById('checkout-content').innerHTML = `
        <div>
          <h2>Sipariş Özeti</h2>
          
          <!-- Ödeme Yöntemi Seçimi -->
          <div>
            <label>
              <input type="radio" name="payment" value="stripe" checked 
                     onchange="selectedPaymentMethod='stripe'">
              💳 Kredi Kartı (Stripe)
            </label>
            <label>
              <input type="radio" name="payment" value="bank" 
                     onchange="selectedPaymentMethod='bank'">
              🏦 Banka Havalesi
            </label>
          </div>

          <!-- Ürünler listesi -->
          ${cart.items.map(item => `
            <div>
              <p>${item.product.name} x ${item.quantity}</p>
              <p>${(item.product.price * item.quantity).toFixed(2)} ₺</p>
            </div>
          `).join('')}

          <p>Toplam: ${total.toFixed(2)} ₺</p>
          <button onclick="proceedToPayment()">Ödemeye Geç</button>
        </div>
      `;
    }

    async function proceedToPayment() {
      if (selectedPaymentMethod === 'bank') {
        await proceedWithBankTransfer();
      } else {
        await proceedWithStripe();
      }
    }

    async function proceedWithBankTransfer() {
      const response = await apiCall('/checkout/bank-transfer', {
        method: 'POST'
      });
      
      // IBAN bilgilerini göster
      document.getElementById('checkout-content').innerHTML = `
        <div>
          <h2>Sipariş Oluşturuldu!</h2>
          <p>Sipariş No: ${response.order_id}</p>
          <p><strong>IBAN:</strong> ${response.iban}</p>
          <p><strong>Hesap Sahibi:</strong> ${response.account_holder}</p>
          <p><strong>Banka:</strong> ${response.bank_name}</p>
          <p><strong>Tutar:</strong> ${response.total.toFixed(2)} ₺</p>
          <p><strong>Açıklama:</strong> ${response.description}</p>
        </div>
      `;
    }

    async function proceedWithStripe() {
      const response = await apiCall('/checkout/create', {
        method: 'POST',
        body: JSON.stringify({ origin_url: window.location.origin })
      });
      
      window.location.href = response.url; // Stripe'a yönlendir
    }

    loadCheckout();
  </script>
</body>
</html>
```

---

### 🎨 2. CSS DOSYASI

#### styles.css
```css
/* FONTLAR */
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Manrope:wght@400;500;600&display=swap');

/* TEMEL AYARLAR */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Manrope', sans-serif;
  background-color: #F9F7F2;
  color: #1A4D2E;
  line-height: 1.6;
}

h1, h2, h3, h4, h5, h6 {
  font-family: 'Playfair Display', serif;
  font-weight: 600;
}

.container {
  max-width: 1280px;
  margin: 0 auto;
  padding: 0 1rem;
}

/* NAVBAR */
.navbar {
  position: sticky;
  top: 0;
  z-index: 50;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid #e5e7eb;
  padding: 1rem 0;
}

.navbar .logo {
  font-size: 1.5rem;
  font-weight: bold;
  color: #1A4D2E;
  text-decoration: none;
  font-family: 'Playfair Display', serif;
}

/* BUTONLAR */
.btn-primary {
  background-color: #FF6B00;
  color: white;
  padding: 0.75rem 2rem;
  border-radius: 9999px;
  font-weight: 600;
  text-decoration: none;
  display: inline-block;
  transition: all 0.3s;
  border: none;
  cursor: pointer;
  box-shadow: 0 4px 6px rgba(255, 107, 0, 0.2);
}

.btn-primary:hover {
  background-color: #E65100;
  transform: scale(1.05);
  box-shadow: 0 6px 12px rgba(255, 107, 0, 0.3);
}

.btn-secondary {
  background-color: white;
  color: #1A4D2E;
  padding: 0.75rem 2rem;
  border: 2px solid #1A4D2E;
  border-radius: 9999px;
  font-weight: 600;
  text-decoration: none;
  display: inline-block;
  transition: all 0.3s;
  cursor: pointer;
}

/* HERO SECTION */
.hero {
  background: linear-gradient(135deg, rgba(26, 77, 46, 0.05) 0%, rgba(255, 107, 0, 0.05) 100%);
  padding: 6rem 0;
  text-align: center;
}

.hero h1 {
  font-size: 3.5rem;
  color: #1A4D2E;
  margin-bottom: 1.5rem;
}

/* ÜRÜN KARTLARI */
.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 1.5rem;
  margin-bottom: 3rem;
}

.product-card {
  background: white;
  border-radius: 1rem;
  overflow: hidden;
  border: 1px solid #f3f4f6;
  transition: all 0.3s;
}

.product-card:hover {
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
  transform: translateY(-2px);
}

.product-card .image {
  position: relative;
  height: 200px;
  overflow: hidden;
}

.product-card .image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.product-card:hover .image img {
  transform: scale(1.05);
}

.product-card .price {
  font-size: 1.5rem;
  font-weight: bold;
  color: #FF6B00;
}

.product-card .add-to-cart {
  background-color: #FF6B00;
  color: white;
  border: none;
  width: 2.5rem;
  height: 2.5rem;
  border-radius: 50%;
  cursor: pointer;
  transition: all 0.3s;
}

.product-card .add-to-cart:hover {
  background-color: #E65100;
  transform: scale(1.1);
}

/* TOAST NOTIFICATION */
.toast {
  position: fixed;
  top: 2rem;
  right: 2rem;
  background: white;
  padding: 1rem 1.5rem;
  border-radius: 0.5rem;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  z-index: 1000;
  animation: slideIn 0.3s ease;
}

@keyframes slideIn {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

.toast.success {
  border-left: 4px solid #10b981;
}

.toast.error {
  border-left: 4px solid #ef4444;
}

/* RESPONSIVE */
@media (max-width: 768px) {
  .hero h1 {
    font-size: 2rem;
  }
  
  .products-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 480px) {
  .products-grid {
    grid-template-columns: 1fr;
  }
}
```

---

### ⚙️ 3. JAVASCRIPT DOSYASI

#### app.js
```javascript
// API YAPILANDIRMASI
const API_URL = 'https://api.tazemarket.com/api';

// AUTH YARDIMCILARı
function getToken() {
  return localStorage.getItem('token');
}

function setToken(token) {
  localStorage.setItem('token', token);
}

function removeToken() {
  localStorage.removeItem('token');
}

function getUser() {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
}

function setUser(user) {
  localStorage.setItem('user', JSON.stringify(user));
}

function removeUser() {
  localStorage.removeItem('user');
}

function isLoggedIn() {
  return !!getToken();
}

// TOAST BİLDİRİMİ
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span>${type === 'success' ? '✓' : '✗'}</span>
    <span>${message}</span>
  `;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 3000);
}

// API ÇAĞRISI
async function apiCall(endpoint, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      ...options,
      headers
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.detail || 'Bir hata oluştu');
    }
    
    return await response.json();
  } catch (error) {
    throw error;
  }
}

// NAVBAR GÜNCELLEMESİ
function updateNavbar() {
  const user = getUser();
  const authLinks = document.getElementById('auth-links');
  
  if (user && authLinks) {
    authLinks.innerHTML = `
      <li><a href="products.html">Meyveler</a></li>
      <li><a href="products.html?category=vegetable">Sebzeler</a></li>
      <li><a href="favorites.html">❤️</a></li>
      <li class="cart-badge">
        <a href="cart.html">🛒</a>
        <span class="badge" id="cart-count" style="display: none;">0</span>
      </li>
      <li>
        <button onclick="toggleUserMenu()">👤</button>
        <div id="user-dropdown" style="display: none;">
          <a href="profile.html">Profilim</a>
          <a href="orders.html">Siparişlerim</a>
          <button onclick="logout()">Çıkış Yap</button>
        </div>
      </li>
    `;
    updateCartBadge();
  } else if (authLinks) {
    authLinks.innerHTML = `
      <li><a href="products.html">Meyveler</a></li>
      <li><a href="products.html?category=vegetable">Sebzeler</a></li>
      <li><a href="auth.html" class="btn-primary">Giriş Yap</a></li>
    `;
  }
}

// SEPET BADGE GÜNCELLEMESİ
async function updateCartBadge() {
  if (!isLoggedIn()) return;
  
  try {
    const cart = await apiCall('/cart');
    const count = cart.items.reduce((sum, item) => sum + item.quantity, 0);
    const badge = document.getElementById('cart-count');
    if (badge) {
      if (count > 0) {
        badge.textContent = count;
        badge.style.display = 'flex';
      } else {
        badge.style.display = 'none';
      }
    }
  } catch (error) {
    console.error('Failed to update cart badge:', error);
  }
}

// ÇIKIŞ YAP
function logout() {
  removeToken();
  removeUser();
  window.location.href = 'index.html';
}

// SAYFA YÜKLENDİĞİNDE
document.addEventListener('DOMContentLoaded', () => {
  updateNavbar();
});
```

---

### 🔧 4. BACKEND KODLARI

#### A) server.py (FastAPI Backend)
```python
from fastapi import FastAPI, APIRouter, HTTPException, Depends, Header, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
from pydantic import BaseModel, EmailStr
from typing import List, Optional
import uuid
from datetime import datetime, timezone, timedelta
import jwt
from passlib.context import CryptContext
import stripe
    StripeCheckout, CheckoutSessionResponse, CheckoutStatusResponse, 
    CheckoutSessionRequest
)

# Çevre değişkenlerini yükle
load_dotenv()

# MongoDB bağlantısı
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# JWT ve şifre hashleme
JWT_SECRET = os.environ.get('JWT_SECRET', 'your-secret-key')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_DAYS = 30
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Stripe
STRIPE_API_KEY = os.environ.get('STRIPE_API_KEY')

app = FastAPI()
api_router = APIRouter(prefix="/api")

# MODELLER
class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: EmailStr
    name: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    email: EmailStr
    name: str
    password: str

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class Product(BaseModel):
    id: str
    name: str
    price: float
    unit: str
    image: str
    category: str  # "fruit" or "vegetable"
    description: Optional[str] = None
    in_stock: bool = True

class CartItem(BaseModel):
    product_id: str
    quantity: int

# YARDIMCI FONKSİYONLAR
def create_access_token(user_id: str, email: str) -> str:
    expire = datetime.now(timezone.utc) + timedelta(days=JWT_EXPIRATION_DAYS)
    payload = {
        "user_id": user_id,
        "email": email,
        "exp": expire
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

async def require_auth(authorization: Optional[str] = Header(None)) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Authentication required")
    
    token = authorization.replace("Bearer ", "")
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")

# AUTH ENDPOINT'LERİ
@api_router.post("/auth/register")
async def register(user_data: UserCreate):
    # Email kontrolü
    existing = await db.users.find_one({"email": user_data.email}, {"_id": 0})
    if existing:
        raise HTTPException(400, "Email already registered")
    
    # Şifreyi hashle
    hashed_password = pwd_context.hash(user_data.password)
    
    # Kullanıcıyı kaydet
    user = User(email=user_data.email, name=user_data.name)
    user_dict = user.model_dump()
    user_dict['timestamp'] = user_dict['created_at'].isoformat()
    user_dict['password'] = hashed_password
    del user_dict['created_at']
    
    await db.users.insert_one(user_dict)
    
    # Token oluştur
    token = create_access_token(user.id, user.email)
    
    return {"user": user.model_dump(), "token": token}

@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    # Kullanıcıyı bul
    user_doc = await db.users.find_one({"email": credentials.email}, {"_id": 0})
    if not user_doc:
        raise HTTPException(401, "Invalid credentials")
    
    # Şifreyi doğrula
    if not pwd_context.verify(credentials.password, user_doc['password']):
        raise HTTPException(401, "Invalid credentials")
    
    # Token oluştur
    token = create_access_token(user_doc['id'], user_doc['email'])
    
    # Şifre olmadan kullanıcı bilgisi döndür
    user_data = {k: v for k, v in user_doc.items() if k != 'password'}
    
    return {"user": user_data, "token": token}

# ÜRÜN ENDPOINT'LERİ
@api_router.get("/products")
async def get_products(category: Optional[str] = None, search: Optional[str] = None):
    query = {}
    if category:
        query['category'] = category
    if search:
        query['name'] = {"$regex": search, "$options": "i"}
    
    products = await db.products.find(query, {"_id": 0}).to_list(1000)
    return products

# SEPET ENDPOINT'LERİ
@api_router.get("/cart")
async def get_cart(current_user: dict = Depends(require_auth)):
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart:
        return {"user_id": current_user['user_id'], "items": []}
    
    # Ürün detaylarını ekle
    cart_items = []
    for item in cart.get('items', []):
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            cart_items.append({
                "product": product,
                "quantity": item['quantity']
            })
    
    return {"user_id": cart['user_id'], "items": cart_items}

@api_router.post("/cart/add")
async def add_to_cart(item: CartItem, current_user: dict = Depends(require_auth)):
    # Ürün kontrolü
    product = await db.products.find_one({"id": item.product_id}, {"_id": 0})
    if not product:
        raise HTTPException(404, "Product not found")
    
    # Sepeti al veya oluştur
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart:
        cart = {"user_id": current_user['user_id'], "items": []}
    
    # Ürün zaten sepette mi?
    existing_item = None
    for i, cart_item in enumerate(cart['items']):
        if cart_item['product_id'] == item.product_id:
            existing_item = i
            break
    
    if existing_item is not None:
        cart['items'][existing_item]['quantity'] += item.quantity
    else:
        cart['items'].append({"product_id": item.product_id, "quantity": item.quantity})
    
    cart['updated_at'] = datetime.now(timezone.utc).isoformat()
    
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": cart},
        upsert=True
    )
    
    return {"message": "Item added to cart"}

# BANKA HAVALESİ İLE SİPARİŞ (YENİ!)
@api_router.post("/checkout/bank-transfer")
async def create_bank_transfer_order(current_user: dict = Depends(require_auth)):
    # Sepeti al
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart or not cart.get('items'):
        raise HTTPException(400, "Cart is empty")
    
    # Toplam hesapla
    total = 0.0
    items = []
    for item in cart['items']:
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({
                "product_id": product['id'],
                "name": product['name'],
                "price": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })
    
    # Sipariş oluştur
    order_id = str(uuid.uuid4())
    order = {
        "id": order_id,
        "user_id": current_user['user_id'],
        "items": items,
        "total": total,
        "status": "pending",
        "payment_session_id": "BANK_TRANSFER",
        "payment_method": "bank_transfer",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    
    await db.orders.insert_one(order)
    
    # Sepeti temizle
    await db.carts.update_one(
        {"user_id": current_user['user_id']},
        {"$set": {"items": []}}
    )
    
    # IBAN bilgilerini döndür
    return {
        "order_id": order_id,
        "total": total,
        "iban": "TR91 0001 0090 1008 0885 5050 02",
        "account_holder": "Muhammet Ali Aslan",
        "bank_name": "Ziraat Bankası",
        "description": f"Sipariş No: {order_id[:8]}"
    }

# STRIPE İLE ÖDEME
@api_router.post("/checkout/create")
async def create_checkout(
    request: Request, 
    origin_url: str, 
    current_user: dict = Depends(require_auth)
):
    # Sepeti al ve toplam hesapla
    cart = await db.carts.find_one({"user_id": current_user['user_id']}, {"_id": 0})
    if not cart or not cart.get('items'):
        raise HTTPException(400, "Cart is empty")
    
    # Toplam hesapla
    total = 0.0
    items = []
    for item in cart['items']:
        product = await db.products.find_one({"id": item['product_id']}, {"_id": 0})
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({
                "product_id": product['id'],
                "name": product['name'],
                "price": product['price'],
                "quantity": item['quantity'],
                "subtotal": subtotal
            })
    
    # Sipariş oluştur
    order_id = str(uuid.uuid4())
    order = {
        "id": order_id,
        "user_id": current_user['user_id'],
        "items": items,
        "total": total,
        "status": "pending",
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    
    await db.orders.insert_one(order)
    
    # Stripe checkout session oluştur
    stripe_checkout = StripeCheckout(
        api_key=STRIPE_API_KEY,
        webhook_url=f"{origin_url}/api/webhook/stripe"
    )
    
    success_url = f"{origin_url}/checkout.html?session_id={{{{CHECKOUT_SESSION_ID}}}}"
    cancel_url = f"{origin_url}/cart.html"
    
    checkout_request = CheckoutSessionRequest(
        amount=total,
        currency="usd",
        success_url=success_url,
        cancel_url=cancel_url,
        metadata={"order_id": order_id}
    )
    
    session = await stripe_checkout.create_checkout_session(checkout_request)
    
    return {"url": session.url, "session_id": session.session_id}

# FastAPI'yi başlat
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
```

#### B) seed_products.py (Ürün Verilerini Yükleme)
```python
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
import os
from dotenv import load_dotenv

load_dotenv()

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

fruits = [
    {"id": "f1", "name": "Kırmızı Elma", "price": 12.99, "unit": "kg", "category": "fruit", 
     "image": "https://images.unsplash.com/photo-1646794768446-048f9c285c69?w=400", 
     "description": "Taze ve sulu kırmızı elmalar", "in_stock": True},
    {"id": "f2", "name": "Muz", "price": 19.99, "unit": "kg", "category": "fruit",
     "image": "https://images.unsplash.com/photo-1711208224791-2cc390f53744?w=400",
     "description": "Tatlı ve enerji dolu muzlar", "in_stock": True},
    # ... 8 ürün daha
]

vegetables = [
    {"id": "v1", "name": "Domates", "price": 9.99, "unit": "kg", "category": "vegetable",
     "image": "https://images.unsplash.com/photo-1625494188687-7ee542a77d7c?w=400",
     "description": "Taze ve kırmızı domatesler", "in_stock": True},
    # ... 9 ürün daha
]

async def seed_database():
    # Eski ürünleri sil
    await db.products.delete_many({})
    
    # Yeni ürünleri ekle
    all_products = fruits + vegetables
    await db.products.insert_many(all_products)
    
    print(f"✓ {len(all_products)} ürün başarıyla eklendi!")
    client.close()

if __name__ == "__main__":
    asyncio.run(seed_database())
```

#### C) requirements.txt
```
fastapi>=0.104.0
uvicorn>=0.24.0
motor>=3.3.0
python-dotenv>=1.0.0
pydantic>=2.4.0
pydantic-settings>=2.0.0
passlib>=1.7.4
bcrypt>=4.0.1
python-jose[cryptography]>=3.3.0
PyJWT>=2.8.0
python-multipart>=0.0.6
stripe==14.4.0
```

---

## 📥 DESKTOP'A KAYDETME ADIM ADIM

### Yöntem 1: ZIP Dosyası İndirme (ÖNERİLEN)

1. **Terminal'de şu komutu çalıştırın:**
   ```bash
   ls -lh /app/taze-market-FULL.zip
   ```

2. **Dosya boyutunu kontrol edin** (yaklaşık 50-100 KB olmalı)

3. **İndirmek için:**
   - Sol panelde "Files" (Dosyalar) ikonuna tıklayın
   - `/app` klasörüne gidin
   - `taze-market-FULL.zip` dosyasını bulun
   - Dosyaya sağ tıklayın → "Download" seçin
   - Desktop'unuza kaydedin

4. **ZIP'i açın:**
   - Windows: Dosyaya çift tıklayın veya sağ tık → "Extract All"
   - Mac: Dosyaya çift tıklayın
   - Linux: `unzip taze-market-FULL.zip`

### Yöntem 2: Manuel Kopyalama

Her dosyayı tek tek kopyalayıp desktop'unuzda yeni dosyalar oluşturun:

1. Desktop'unuzda `taze-market` klasörü oluşturun

2. İçinde şu klasörleri oluşturun:
   - `frontend/` (HTML, CSS, JS dosyaları için)
   - `backend/` (Python dosyaları için)

3. Her dosyanın içeriğini kopyalayıp ilgili klasöre kaydedin

---

## 🚀 NASIL ÇALIŞTIRILIRIM?

### Frontend (HTML'leri Çalıştırma)

**Yöntem 1: Doğrudan Tarayıcıda**
```bash
# Herhangi bir web sunucusu ile
cd frontend
python -m http.server 8000
# Tarayıcıda: http://localhost:8000
```

**Yöntem 2: VS Code Live Server**
- VS Code'da `index.html`'i açın
- Sağ tıklayın → "Open with Live Server"

### Backend (Python'u Çalıştırma)

```bash
# 1. Sanal ortam oluştur
cd backend
python -m venv venv

# 2. Aktifleştir
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 3. Paketleri yükle
pip install -r requirements.txt

# 4. .env dosyasını oluştur
# MongoDB URL'ini ekleyin

# 5. Ürünleri yükle
python seed_products.py

# 6. Backend'i başlat
uvicorn server:app --reload
```

---

## 📌 ÖNEMLİ NOTLAR

1. **API URL'ini değiştirin:**
   - `app.js` dosyasında `API_URL` değişkenini kendi backend URL'nize göre değiştirin

2. **MongoDB Gerekli:**
   - Backend çalışması için MongoDB kurulumu gerekli
   - Ücretsiz: MongoDB Atlas (cloud)

3. **Stripe Entegrasyonu:**
   - Test key zaten kodda var
   - Gerçek kullanım için kendi Stripe hesabınızdan key alın

4. **Banka Havalesi:**
   - IBAN bilgileri `server.py` dosyasında
   - İsterseniz değiştirebilirsiniz

---

## 🎓 SUNUM İÇİN İPUÇLARI

1. **Canlı Demo:**
   - Siteyi canlı gösterin
   - Ürün ekleme, sepete atma, ödeme akışını gösterin

2. **Kod Gösterimi:**
   - Önemli fonksiyonları ekranda gösterin
   - Örnek: `addToCart()`, `proceedWithBankTransfer()`

3. **Öne Çıkan Özellikler:**
   - 2 ödeme seçeneği (Stripe + Banka Havalesi)
   - Responsive tasarım
   - Güvenlik (JWT, şifre hashleme)

4. **Teknik Detaylar:**
   - Vanilla JS (framework yok)
   - FastAPI (modern Python framework)
   - MongoDB (NoSQL veritabanı)

---

## 📞 YARDIM

Sorun yaşarsanız:
1. `console.log()` kullanarak hata ayıklayın
2glar. Backend loını kontrol edin
3. Browser Developer Tools'u açın (F12)

**İyi Sunumlar! 🚀**
