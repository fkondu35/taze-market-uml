import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import axios from 'axios';
import { CheckCircle, XCircle, Loader } from 'lucide-react';
import SatisfactionSurvey from '../components/SatisfactionSurvey';
import StarRating from '../components/StarRating';
import { useReviews } from '../contexts/ReviewsContext';

const BACKEND_URL = (process.env.REACT_APP_BACKEND_URL || window.location.origin).replace(/\/$/, '');
const API = `${BACKEND_URL}/api`;

const Checkout = () => {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const navigate = useNavigate();
  const { cart, getCartTotal } = useCart();
  const { token } = useAuth();
  const { refreshReviews } = useReviews();
  const [loading, setLoading] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [pollingAttempts, setPollingAttempts] = useState(0);
  const [orderId, setOrderId] = useState(null);
  const [step, setStep] = useState('success'); // success | survey | review | done
  const [reviewForm, setReviewForm] = useState({ rating: 0, comment: '' });
  const [reviewSubmitting, setReviewSubmitting] = useState(false);

  const formatMoney = (value) => {
    const n = typeof value === 'string' ? Number(value) : value;
    return Number.isFinite(n) ? n.toFixed(2) : '—';
  };

  useEffect(() => {
    if (sessionId) {
      pollPaymentStatus(sessionId);
    }
  }, [sessionId]);

  const checkSurveyStatus = async (oid) => {
    try {
      const res = await axios.get(`${API}/surveys/order/${oid}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setStep(res.data.submitted ? 'review' : 'survey');
    } catch {
      setStep('survey');
    }
  };

  const pollPaymentStatus = async (sid, attempts = 0) => {
    const maxAttempts = 5;
    const pollInterval = 2000;

    if (attempts >= maxAttempts) {
      setPaymentStatus('timeout');
      toast.error('Ödeme durumu kontrol edilemedi. Lütfen siparişlerinizi kontrol edin.');
      return;
    }

    try {
      setLoading(true);
      const response = await axios.get(`${API}/checkout/status/${sid}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.data.payment_status === 'paid') {
        setPaymentStatus('success');
        const oid = response.data.metadata?.order_id;
        if (oid) {
          setOrderId(oid);
          await checkSurveyStatus(oid);
        }
        toast.success('Ödeme başarılı! Siparişiniz oluşturuldu.');
        setLoading(false);
        return;
      }
      if (response.data.payment_status === 'failed') {
        setPaymentStatus('failed');
        toast.error('Ödeme başarısız oldu.');
        setLoading(false);
        return;
      }

      setPollingAttempts(attempts + 1);
      setTimeout(() => pollPaymentStatus(sid, attempts + 1), pollInterval);
    } catch (error) {
      console.error('Error checking payment status:', error);
      setPaymentStatus('error');
      setLoading(false);
    }
  };

  const handleProceedToPayment = () => {
    if (cart.items.length === 0) {
      toast.error('Sepetiniz boş');
      return;
    }
    navigate('/odeme');
  };

  const handleReviewSubmit = async (e) => {
    e.preventDefault();
    if (reviewForm.rating === 0) {
      toast.error('Lütfen puan verin');
      return;
    }
    if (reviewForm.comment.trim().length < 3) {
      toast.error('Yorum en az 3 karakter olmalı');
      return;
    }

    setReviewSubmitting(true);
    try {
      await axios.post(
        `${API}/reviews`,
        { rating: reviewForm.rating, comment: reviewForm.comment.trim() },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      await refreshReviews();
      toast.success('Yorumunuz yayınlandı!');
      setStep('done');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Yorum gönderilemedi');
    } finally {
      setReviewSubmitting(false);
    }
  };

  if (sessionId) {
    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center" data-testid="payment-processing">
          <div className="text-center">
            <Loader className="animate-spin h-16 w-16 text-[#FF6B00] mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-[#1A4D2E] mb-2" style={{ fontFamily: 'Playfair Display' }}>
              Ödeme durumu kontrol ediliyor...
            </h2>
            <p className="text-[#4A6B5A]">Lütfen bekleyin ({pollingAttempts + 1}/5)</p>
          </div>
        </div>
      );
    }

    if (paymentStatus === 'success') {
      if (step === 'survey' && orderId) {
        return (
          <div className="min-h-screen py-12 px-4" data-testid="satisfaction-survey">
            <div className="text-center mb-8">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-[#1A4D2E] mb-2" style={{ fontFamily: 'Playfair Display' }}>
                Siparişiniz Alındı!
              </h2>
              <p className="text-[#4A6B5A]">Deneyiminizi bizimle paylaşır mısınız?</p>
            </div>
            <SatisfactionSurvey
              orderId={orderId}
              token={token}
              onComplete={() => setStep('review')}
              onSkip={() => setStep('review')}
            />
          </div>
        );
      }

      if (step === 'review') {
        return (
          <div className="min-h-screen flex items-center justify-center py-12 px-4" data-testid="post-order-review">
            <div className="card p-8 max-w-md w-full">
              <h2 className="text-2xl font-bold text-[#1A4D2E] mb-2 text-center" style={{ fontFamily: 'Playfair Display' }}>
                Yorumunuzu Paylaşın
              </h2>
              <p className="text-[#4A6B5A] mb-6 text-center">
                Diğer müşterilere yardımcı olmak için kısa bir yorum bırakabilirsiniz.
              </p>
              <form onSubmit={handleReviewSubmit} className="space-y-4">
                <div className="flex justify-center">
                  <StarRating
                    value={reviewForm.rating}
                    onChange={(val) => setReviewForm({ ...reviewForm, rating: val })}
                  />
                </div>
                <textarea
                  rows={4}
                  value={reviewForm.comment}
                  onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                  placeholder="Deneyiminizi anlatın..."
                  className="w-full px-4 py-3 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-[#FF6B00]"
                />
                <button
                  type="submit"
                  disabled={reviewSubmitting}
                  className="w-full btn-primary disabled:opacity-50"
                >
                  {reviewSubmitting ? 'Gönderiliyor...' : 'Yorumu Gönder'}
                </button>
                <button
                  type="button"
                  onClick={() => setStep('done')}
                  className="w-full btn-secondary"
                >
                  Şimdilik Atla
                </button>
              </form>
            </div>
          </div>
        );
      }

      return (
        <div className="min-h-screen flex items-center justify-center" data-testid="payment-success">
          <div className="card p-12 text-center max-w-md">
            <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-[#1A4D2E] mb-4" style={{ fontFamily: 'Playfair Display' }}>
              Teşekkürler!
            </h2>
            <p className="text-[#4A6B5A] mb-6">
              Siparişiniz başarıyla oluşturuldu. Geri bildiriminiz için teşekkür ederiz.
            </p>
            <div className="flex flex-col gap-3">
              <button onClick={() => navigate('/orders')} className="btn-primary" data-testid="view-orders-button">
                Siparişlerime Git
              </button>
              <Link to="/yorumlar" className="btn-secondary">Yorumları Gör</Link>
            </div>
          </div>
        </div>
      );
    }

    if (paymentStatus === 'failed' || paymentStatus === 'error' || paymentStatus === 'timeout') {
      return (
        <div className="min-h-screen flex items-center justify-center" data-testid="payment-failed">
          <div className="card p-12 text-center max-w-md">
            <XCircle className="h-20 w-20 text-red-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-[#1A4D2E] mb-4" style={{ fontFamily: 'Playfair Display' }}>
              Ödeme Başarısız
            </h2>
            <p className="text-[#4A6B5A] mb-6">
              Ödeme işlemi tamamlanamadı. Lütfen tekrar deneyin.
            </p>
            <button onClick={() => navigate('/cart')} className="btn-primary" data-testid="back-to-cart-button">
              Sepete Dön
            </button>
          </div>
        </div>
      );
    }
  }

  return (
    <div className="min-h-screen py-12" data-testid="checkout-page">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-[#1A4D2E] mb-8" style={{ fontFamily: 'Playfair Display' }}>
          Ödeme
        </h1>

        <div className="card p-8">
          <h2 className="text-2xl font-bold text-[#1A4D2E] mb-6" style={{ fontFamily: 'Playfair Display' }}>
            Sipariş Özeti
          </h2>

          <div className="space-y-4 mb-6">
            {cart.items.map((item) => (
              <div key={item.product.id} className="flex justify-between items-center py-3 border-b">
                <div className="flex items-center space-x-4">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div>
                    <p className="font-semibold text-[#1A4D2E]">{item.product.name}</p>
                    <p className="text-sm text-[#4A6B5A]">Miktar: {item.quantity}</p>
                  </div>
                </div>
                <p className="font-bold text-[#FF6B00]">
                  {formatMoney(Number(item.product.price) * item.quantity)} ₺
                </p>
              </div>
            ))}
          </div>

          <div className="border-t pt-4 space-y-2 mb-6">
            <div className="flex justify-between">
              <span className="text-[#4A6B5A]">Ara Toplam</span>
              <span className="font-semibold">{formatMoney(getCartTotal())} ₺</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#4A6B5A]">Kargo</span>
              <span className="font-semibold text-green-600">Ücretsiz</span>
            </div>
            <div className="flex justify-between text-xl font-bold pt-2">
              <span className="text-[#1A4D2E]">Toplam</span>
              <span className="text-[#FF6B00]" data-testid="checkout-total">{formatMoney(getCartTotal())} ₺</span>
            </div>
          </div>

          <button
            onClick={handleProceedToPayment}
            disabled={loading}
            className="w-full btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
            data-testid="proceed-to-payment-button"
          >
            Ödemeye Devam Et
          </button>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
