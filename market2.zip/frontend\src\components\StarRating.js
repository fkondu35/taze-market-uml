import React from 'react';
import { Star } from 'lucide-react';

const StarRating = ({ value, onChange, size = 28, readOnly = false }) => {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={readOnly}
          onClick={() => !readOnly && onChange?.(star)}
          className={`transition ${readOnly ? 'cursor-default' : 'cursor-pointer hover:scale-110'}`}
        >
          <Star
            size={size}
            className={star <= value ? 'text-[#FF6B00] fill-[#FF6B00]' : 'text-gray-300'}
          />
        </button>
      ))}
    </div>
  );
};

export default StarRating;
