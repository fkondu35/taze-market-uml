import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient

load_dotenv(Path(__file__).parent / ".env")

FIXES = {
    "f10": "/urunler/seftali.png",
    "f11": "/urunler/kiraz.png",
    "f12": "/urunler/armut.png",
    "v11": "/urunler/kabak.png",
    "v12": "/urunler/marul.png",
    "v13": "/urunler/sarimsak.png",
    "v14": "/urunler/sogan.png",
}


async def main():
    db = AsyncIOMotorClient(os.environ["MONGO_URL"])[os.environ["DB_NAME"]]
    for product_id, image in FIXES.items():
        await db.products.update_one({"id": product_id}, {"$set": {"image": image}})
        product = await db.products.find_one({"id": product_id}, {"_id": 0, "name": 1, "image": 1})
        print(f"[OK] {product['name']} -> {product['image']}")


if __name__ == "__main__":
    asyncio.run(main())
