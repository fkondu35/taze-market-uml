@echo off
cd /d "%~dp0"
echo Starting production build on http://localhost:4173
npx --yes serve -s build -l 4173
